@echo off
REM expor.bat — Gera link público para Marcelo via localtunnel
set PORT=%1
if "%PORT%"=="" set PORT=3000
echo === Expor porta %PORT% publicamente via localtunnel ===
echo Link sera gerado abaixo, compartilhe com Marcelo
npx --yes localtunnel --port %PORT%
pause
