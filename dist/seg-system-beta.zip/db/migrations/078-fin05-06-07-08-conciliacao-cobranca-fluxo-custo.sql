-- FIN-05/06/07/08 conciliação cobrança fluxo caixa custo por cliente/contrato/posto
-- FIN-05 conciliação por importação/extrato ou provedor sugestão e confirmação evitar duplicar transações
-- FIN-06 cobrança com responsável lembretes histórico política aprovada sem mensagens reais ou bloqueio portal automático
-- FIN-07 fluxo caixa previsto/realizado vencidos próximos pagamentos aging recebíveis
-- FIN-08 custo por cliente/contrato/posto importação custos pessoal equipamentos materiais supervisão rateio documentado

DO $$ BEGIN CREATE TYPE fin_conciliation_source AS ENUM ('importacao','extrato','provedor','manual'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE fin_conciliation_status AS ENUM ('pendente','sugerida','conciliada','divergente','ignorada'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE fin_collection_status AS ENUM ('pendente','lembrete_enviado','em_negociacao','acordado','cancelado'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE fin_cashflow_type AS ENUM ('previsto','realizado'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE fin_cost_source AS ENUM ('pessoal','equipamento','material','supervisao','outro'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE fin_aging_bucket AS ENUM ('a_vencer','vencido_0_30','vencido_31_60','vencido_61_90','vencido_90_plus'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE fin_reminder_type AS ENUM ('email','whatsapp','ligacao','notificacao_portal','outro'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- FIN-05 conciliação
CREATE TABLE IF NOT EXISTS fin_bank_statements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  protocol TEXT NOT NULL UNIQUE CHECK (protocol ~ '^EXT-FIN-[0-9]{8}-[A-Z0-9]{4}$'),
  source fin_conciliation_source NOT NULL DEFAULT 'extrato',
  file_name TEXT NOT NULL CHECK (char_length(file_name) BETWEEN 1 AND 500),
  file_url TEXT NOT NULL CHECK (char_length(file_url) BETWEEN 5 AND 1000),
  storage_key TEXT NOT NULL UNIQUE CHECK (char_length(storage_key) BETWEEN 5 AND 500),
  import_date DATE NOT NULL DEFAULT CURRENT_DATE,
  total_transactions INT NOT NULL DEFAULT 0 CHECK (total_transactions >=0),
  total_amount_cents BIGINT NOT NULL DEFAULT 0,
  created_by_identity UUID REFERENCES auth_identities(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS fin_bank_statements_protocol_idx ON fin_bank_statements(protocol);

CREATE TABLE IF NOT EXISTS fin_bank_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  statement_id UUID NOT NULL REFERENCES fin_bank_statements(id) ON DELETE CASCADE,
  transaction_date DATE NOT NULL,
  amount_cents BIGINT NOT NULL,
  description TEXT NOT NULL CHECK (char_length(description) BETWEEN 3 AND 500),
  bank_ref TEXT NOT NULL UNIQUE CHECK (char_length(bank_ref) BETWEEN 3 AND 200),
  is_conciliated BOOLEAN NOT NULL DEFAULT false,
  conciliated_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_conciliated_requires_date CHECK ((is_conciliated = false AND conciliated_at IS NULL) OR (is_conciliated = true AND conciliated_at IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS fin_bank_transactions_statement_idx ON fin_bank_transactions(statement_id);
CREATE INDEX IF NOT EXISTS fin_bank_transactions_bank_ref_idx ON fin_bank_transactions(bank_ref);
CREATE INDEX IF NOT EXISTS fin_bank_transactions_date_idx ON fin_bank_transactions(transaction_date);

CREATE TABLE IF NOT EXISTS fin_conciliations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  receivable_id UUID REFERENCES fin_accounts_receivable(id) ON DELETE SET NULL,
  payable_id UUID REFERENCES fin_accounts_payable(id) ON DELETE SET NULL,
  bank_transaction_id UUID REFERENCES fin_bank_transactions(id) ON DELETE SET NULL,
  source fin_conciliation_source NOT NULL DEFAULT 'extrato',
  status fin_conciliation_status NOT NULL DEFAULT 'pendente',
  suggested_by_identity UUID REFERENCES auth_identities(id),
  suggested_at TIMESTAMPTZ,
  confirmed_by_identity UUID REFERENCES auth_identities(id),
  confirmed_at TIMESTAMPTZ,
  suggestion_reason TEXT CHECK (suggestion_reason IS NULL OR char_length(suggestion_reason) BETWEEN 10 AND 1000),
  divergence_reason TEXT CHECK (divergence_reason IS NULL OR char_length(divergence_reason) BETWEEN 10 AND 1000),
  amount_matched_cents BIGINT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_account_ref_conciliation CHECK ((receivable_id IS NOT NULL AND payable_id IS NULL) OR (payable_id IS NOT NULL AND receivable_id IS NULL) OR (receivable_id IS NULL AND payable_id IS NULL)),
  CONSTRAINT chk_suggested_requires_reason CHECK ((status != 'sugerida') OR (suggestion_reason IS NOT NULL)),
  CONSTRAINT chk_divergent_requires_reason CHECK ((status != 'divergente') OR (divergence_reason IS NOT NULL)),
  UNIQUE(receivable_id, bank_transaction_id),
  UNIQUE(payable_id, bank_transaction_id)
);
CREATE INDEX IF NOT EXISTS fin_conciliations_receivable_idx ON fin_conciliations(receivable_id) WHERE receivable_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS fin_conciliations_payable_idx ON fin_conciliations(payable_id) WHERE payable_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS fin_conciliations_bank_idx ON fin_conciliations(bank_transaction_id) WHERE bank_transaction_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS fin_conciliations_status_idx ON fin_conciliations(status);

-- FIN-06 cobrança responsável lembretes histórico política aprovada sem mensagens reais ou bloqueio portal automático
CREATE TABLE IF NOT EXISTS fin_collection_policies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE CHECK (char_length(name) BETWEEN 3 AND 200),
  description TEXT CHECK (description IS NULL OR char_length(description) BETWEEN 10 AND 1000),
  is_approved BOOLEAN NOT NULL DEFAULT false,
  approved_by_identity UUID REFERENCES auth_identities(id),
  approved_at TIMESTAMPTZ,
  rules JSONB,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_approved_requires_approver_coll CHECK ((is_approved = false) OR (is_approved = true AND approved_by_identity IS NOT NULL AND approved_at IS NOT NULL))
);
INSERT INTO fin_collection_policies (name, description, is_approved, is_active, rules) VALUES
  ('Política Padrão Cobrança', 'Lembretes com responsável histórico política aprovada sem mensagens reais ou bloqueio portal automático', true, true, '{"lembretes": ["email","notificacao_portal"], "sem_bloqueio_automatico": true, "sem_mensagens_reais": true}'::jsonb)
ON CONFLICT (name) DO NOTHING;

CREATE TABLE IF NOT EXISTS fin_collection_reminders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  receivable_id UUID NOT NULL REFERENCES fin_accounts_receivable(id) ON DELETE CASCADE,
  policy_id UUID REFERENCES fin_collection_policies(id) ON DELETE SET NULL,
  responsible_name TEXT NOT NULL CHECK (char_length(responsible_name) BETWEEN 2 AND 200),
  due_date DATE NOT NULL,
  reminder_type fin_reminder_type NOT NULL DEFAULT 'notificacao_portal',
  status fin_collection_status NOT NULL DEFAULT 'pendente',
  content TEXT NOT NULL CHECK (char_length(content) BETWEEN 20 AND 2000),
  sent_at TIMESTAMPTZ,
  is_real_message BOOLEAN NOT NULL DEFAULT false CHECK (is_real_message = false),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_sent_requires_status CHECK ((sent_at IS NULL) OR (status = 'lembrete_enviado'))
);
CREATE INDEX IF NOT EXISTS fin_collection_reminders_receivable_idx ON fin_collection_reminders(receivable_id, due_date DESC);

CREATE TABLE IF NOT EXISTS fin_collection_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  receivable_id UUID NOT NULL REFERENCES fin_accounts_receivable(id) ON DELETE CASCADE,
  previous_status fin_collection_status,
  next_status fin_collection_status NOT NULL,
  changed_by_identity UUID REFERENCES auth_identities(id),
  reason TEXT NOT NULL CHECK (char_length(reason) BETWEEN 10 AND 1000),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS fin_collection_history_receivable_idx ON fin_collection_history(receivable_id, created_at DESC);

-- FIN-07 fluxo caixa previsto/realizado vencidos próximos pagamentos aging recebíveis
CREATE TABLE IF NOT EXISTS fin_cashflow_snapshots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  competence_date DATE NOT NULL,
  cashflow_type fin_cashflow_type NOT NULL DEFAULT 'previsto',
  total_receivable_cents BIGINT NOT NULL DEFAULT 0 CHECK (total_receivable_cents >=0),
  total_payable_cents BIGINT NOT NULL DEFAULT 0 CHECK (total_payable_cents >=0),
  balance_cents BIGINT GENERATED ALWAYS AS (total_receivable_cents - total_payable_cents) STORED,
  vencidos_cents BIGINT NOT NULL DEFAULT 0 CHECK (vencidos_cents >=0),
  proximos_pagamentos_cents BIGINT NOT NULL DEFAULT 0 CHECK (proximos_pagamentos_cents >=0),
  notes TEXT CHECK (notes IS NULL OR char_length(notes) BETWEEN 10 AND 1000),
  created_by_identity UUID REFERENCES auth_identities(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(competence_date, cashflow_type)
);
CREATE INDEX IF NOT EXISTS fin_cashflow_snapshots_date_idx ON fin_cashflow_snapshots(competence_date DESC);

CREATE TABLE IF NOT EXISTS fin_aging_receivables (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  receivable_id UUID NOT NULL REFERENCES fin_accounts_receivable(id) ON DELETE CASCADE,
  client_account_id UUID NOT NULL REFERENCES client_accounts(id) ON DELETE CASCADE,
  bucket fin_aging_bucket NOT NULL,
  days_overdue INT GENERATED ALWAYS AS (GREATEST(0, CURRENT_DATE - (SELECT due_date FROM fin_accounts_receivable WHERE id = receivable_id))) STORED,
  amount_cents BIGINT NOT NULL CHECK (amount_cents >=0),
  competence_date DATE NOT NULL,
  due_date DATE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(receivable_id)
);
CREATE INDEX IF NOT EXISTS fin_aging_receivables_bucket_idx ON fin_aging_receivables(bucket);
CREATE INDEX IF NOT EXISTS fin_aging_receivables_account_idx ON fin_aging_receivables(client_account_id);

-- FIN-08 custo por cliente/contrato/posto importação custos pessoal equipamentos materiais supervisão rateio documentado
CREATE TABLE IF NOT EXISTS fin_cost_imports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  protocol TEXT NOT NULL UNIQUE CHECK (protocol ~ '^COST-IMP-[0-9]{8}-[A-Z0-9]{4}$'),
  source fin_cost_source NOT NULL,
  file_name TEXT NOT NULL CHECK (char_length(file_name) BETWEEN 1 AND 500),
  file_url TEXT NOT NULL CHECK (char_length(file_url) BETWEEN 5 AND 1000),
  storage_key TEXT NOT NULL UNIQUE CHECK (char_length(storage_key) BETWEEN 5 AND 500),
  competence_date DATE NOT NULL,
  total_costs_cents BIGINT NOT NULL DEFAULT 0 CHECK (total_costs_cents >=0),
  total_records INT NOT NULL DEFAULT 0 CHECK (total_records >=0),
  created_by_identity UUID REFERENCES auth_identities(id),
  import_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS fin_cost_imports_protocol_idx ON fin_cost_imports(protocol);

CREATE TABLE IF NOT EXISTS fin_costs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  import_id UUID REFERENCES fin_cost_imports(id) ON DELETE SET NULL,
  client_account_id UUID REFERENCES client_accounts(id) ON DELETE SET NULL,
  contract_id UUID REFERENCES client_contracts(id) ON DELETE SET NULL,
  post_id UUID REFERENCES ops_posts(id) ON DELETE SET NULL,
  cost_source fin_cost_source NOT NULL,
  competence_date DATE NOT NULL,
  amount_cents BIGINT NOT NULL CHECK (amount_cents >=0),
  description TEXT NOT NULL CHECK (char_length(description) BETWEEN 10 AND 1000),
  source_employee_id UUID REFERENCES hr_employees(id) ON DELETE SET NULL,
  source_equipment_id UUID,
  source_material TEXT,
  supervision_id UUID,
  rateio_rule TEXT NOT NULL CHECK (char_length(rateio_rule) BETWEEN 10 AND 1000),
  rateio_percent NUMERIC(5,2) NOT NULL CHECK (rateio_percent BETWEEN 0 AND 100),
  rateio_documented BOOLEAN NOT NULL DEFAULT true,
  created_by_identity UUID REFERENCES auth_identities(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_rateio_documented CHECK (rateio_documented = true AND rateio_rule IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS fin_costs_account_idx ON fin_costs(client_account_id, competence_date DESC);
CREATE INDEX IF NOT EXISTS fin_costs_contract_idx ON fin_costs(contract_id, competence_date DESC);
CREATE INDEX IF NOT EXISTS fin_costs_post_idx ON fin_costs(post_id, competence_date DESC);
CREATE INDEX IF NOT EXISTS fin_costs_source_idx ON fin_costs(cost_source);
CREATE INDEX IF NOT EXISTS fin_costs_import_idx ON fin_costs(import_id) WHERE import_id IS NOT NULL;

-- Triggers updated_at
CREATE OR REPLACE FUNCTION update_fin_bank_statements_updated_at() RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_fin_bank_statements_updated_at ON fin_bank_statements;
-- bank_statements has no updated_at, skip

CREATE OR REPLACE FUNCTION update_fin_conciliations_updated_at() RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_fin_conciliations_updated_at ON fin_conciliations;
CREATE TRIGGER trg_fin_conciliations_updated_at BEFORE UPDATE ON fin_conciliations FOR EACH ROW EXECUTE FUNCTION update_fin_conciliations_updated_at();

CREATE OR REPLACE FUNCTION update_fin_collection_policies_updated_at() RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_fin_collection_policies_updated_at ON fin_collection_policies;
CREATE TRIGGER trg_fin_collection_policies_updated_at BEFORE UPDATE ON fin_collection_policies FOR EACH ROW EXECUTE FUNCTION update_fin_collection_policies_updated_at();

CREATE OR REPLACE FUNCTION update_fin_collection_reminders_updated_at() RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_fin_collection_reminders_updated_at ON fin_collection_reminders;
CREATE TRIGGER trg_fin_collection_reminders_updated_at BEFORE UPDATE ON fin_collection_reminders FOR EACH ROW EXECUTE FUNCTION update_fin_collection_reminders_updated_at();

CREATE OR REPLACE FUNCTION update_fin_costs_updated_at() RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_fin_costs_updated_at ON fin_costs;
CREATE TRIGGER trg_fin_costs_updated_at BEFORE UPDATE ON fin_costs FOR EACH ROW EXECUTE FUNCTION update_fin_costs_updated_at();

-- Immutable history
CREATE OR REPLACE FUNCTION prevent_fin_collection_history_update_delete() RETURNS TRIGGER AS $$ BEGIN RAISE EXCEPTION 'fin_collection_history is immutable'; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_fin_collection_history_immutable ON fin_collection_history;
CREATE TRIGGER trg_fin_collection_history_immutable BEFORE UPDATE OR DELETE ON fin_collection_history FOR EACH ROW EXECUTE FUNCTION prevent_fin_collection_history_update_delete();

-- Audit expansion
ALTER TABLE audit_log DROP CONSTRAINT IF EXISTS audit_log_action_check;
ALTER TABLE audit_log ADD CONSTRAINT audit_log_action_check CHECK (
  action IN (
    'staff_login','invite_create','invite_revoke','invite_accept','login','logout','mfa_challenge','mfa_verify','mfa_reset',
    'client_account_create','client_account_update','client_access_grant','client_access_revoke','client_contract_create','client_contract_update',
    'client_document_upload','client_document_download','client_ticket_open','client_ticket_status','client_ticket_message',
    'service_catalog_create','service_catalog_update','equipment_create','equipment_update','inspection_create','inspection_update',
    'labor_budget_create','labor_budget_update','technical_budget_create','technical_budget_update','cost_parameter_create','cost_parameter_update',
    'price_scenario_create','price_scenario_update','discount_tier_create','discount_tier_update','proposal_create','proposal_update','proposal_delivery_create','proposal_delivery_update','proposal_acceptance_create','proposal_acceptance_update','contract_create','contract_update','report_create','report_update','commission_create','commission_update','commercial_library_create','commercial_library_update','partnership_create','partnership_update','renewal_create','renewal_update',
    'contract_unit_create','contract_unit_update','contract_post_create','contract_post_update','contract_status_transition','contract_amendment_create','contract_amendment_update','contract_alert_create','contract_alert_update','contract_doc_obligation_create','contract_doc_obligation_update','contract_implantation_create','contract_implantation_update','contract_implantation_block_create','contract_closure_create','contract_closure_update','contract_fiscal_create','contract_fiscal_update','contract_management_diary_create','contract_management_diary_update',
    'notification_create','notification_update','notification_preference_update','observability_log','healthcheck','backup_create','backup_update','privacy_policy_update','lgpd_request_create','lgpd_request_update','retention_policy_create','retention_policy_update','incident_create','incident_update','config_flag_create','config_flag_update','dependency_create','dependency_update','integration_log_create','operational_budget_create','operational_budget_update','env_isolation_check','maintenance_doc_create','maintenance_doc_update',
    'hr_employee_create','hr_employee_update','hr_recruitment_create','hr_recruitment_update','hr_termination_create','hr_termination_update','hr_absence_create','hr_absence_update','hr_benefit_create','hr_benefit_update','hr_training_create','hr_training_update','hr_advanced_create','hr_advanced_update','emp_portal_access','emp_ops_access','emp_self_update','emp_advanced2_create','emp_pwa_config','ops_structure_create','ops_structure_update','ops_coverage_request_create','ops_coverage_request_update','ops_handover_create','ops_handover_update','ops_occurrence_create','ops_occurrence_update','ops_checklist_create','ops_checklist_update','ops_supervision_visit_create','ops_supervision_visit_update','ops_patrol_create','ops_patrol_update','ops_key_create','ops_key_update','ops_client_report_create','ops_client_report_update','ops_metrics_definition_create','ops_metrics_snapshot_create','ops_assisted_proposal_create','ops_assisted_proposal_publish','ops_cleaning_environment_create','ops_cleaning_routine_create','ops_cleaning_execution_create','ops_cleaning_nonconformity_create','ops_monitoring_connector_create','ops_monitoring_event_create','ops_monitoring_event_ack','ops_monitoring_event_escalate',
    'cli_entry_point_create','cli_entry_point_update','cli_old_route_create','cli_client_contact_create','cli_contact_scope_create','cli_contact_delegate','cli_contract_item_create','cli_contract_scope_create','cli_contract_vigencia_create','cli_document_category_create','cli_client_document_v2_create','cli_document_version_create','cli_document_download','cli_document_search',
    'cli_ticket_v2_create','cli_ticket_v2_status','cli_ticket_v2_reopen','cli_ticket_message_create','cli_ticket_attachment_create','cli_ticket_sla_pause','cli_ticket_sla_resume','cli_visit_create','cli_visit_status','cli_visit_confirm','cli_visit_reschedule','cli_report_v2_create','cli_report_v2_status','cli_report_v2_review',
    'cli_charge_v2_create','cli_charge_v2_status','cli_service_request_create','cli_service_request_crm','cli_satisfaction_survey_create','cli_satisfaction_response','cli_satisfaction_action_plan_create','cli_renewal_comm_create','cli_renewal_comm_send','cli_portal_mode_update','cli_portal_access_request_create','cli_portal_access_approve','cli_security_event','cli_email_change_request','cli_email_change_confirm','cli_session_revoke',
    'fin_supplier_create','fin_cost_center_create','fin_recurrence_rule_create','fin_recurrence_rule_approve','fin_receivable_create','fin_receivable_status','fin_payable_create','fin_payable_approve','fin_payable_status','fin_payment_create','fin_payment_estorno','fin_payment_renegotiation','fin_attachment_create',
    'fin_bank_statement_create','fin_bank_transaction_create','fin_conciliation_create','fin_conciliation_confirm','fin_collection_policy_create','fin_collection_policy_approve','fin_collection_reminder_create','fin_collection_reminder_send','fin_cashflow_snapshot_create','fin_aging_create','fin_cost_import_create','fin_cost_create'
  )
);
