-- CLI-05/06/07/08 chamados agenda relatórios
-- CLI-05 protocolo categoria prioridade responsável mensagens anexos SLA histórico
-- CLI-06 estados aberto/em atendimento/aguardando cliente/resolvido/encerrado reabertura motivo pausas SLA explicitamente definidas
-- CLI-07 agenda visita/manutenção confirmação reagendamento histórico
-- CLI-08 relatórios execução medição/aceite revisão

DO $$ BEGIN CREATE TYPE cli_ticket_category AS ENUM ('acesso_portal','contratos_documentos','atendimento_servico','financeiro','reclamacao','sugestao','outro'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE cli_ticket_priority AS ENUM ('baixa','media','alta','critica'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE cli_ticket_status AS ENUM ('aberto','em_atendimento','aguardando_cliente','resolvido','encerrado'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE cli_ticket_message_type AS ENUM ('mensagem','nota_interna','mudanca_status','reabertura'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE cli_sla_pause_reason AS ENUM ('aguardando_cliente','aguardando_terceiro','feriado','manutencao','outro'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE cli_visit_type AS ENUM ('visita_tecnica','manutencao_preventiva','manutencao_corretiva','vistoria','reuniao','outro'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE cli_visit_status AS ENUM ('agendada','confirmada','reagendada','realizada','cancelada','nao_compareceu'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE cli_report_type AS ENUM ('execucao','medicao','aceite','outro'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE cli_report_status AS ENUM ('rascunho','em_revisao','aprovado','rejeitado','enviado'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- CLI-05/06 tickets v2
CREATE TABLE IF NOT EXISTS cli_tickets_v2 (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  protocol TEXT NOT NULL UNIQUE CHECK (protocol ~ '^CLI-[0-9]{8}-[A-Z0-9]{4}$'),
  client_account_id UUID NOT NULL REFERENCES client_accounts(id) ON DELETE CASCADE,
  contact_id UUID REFERENCES cli_client_contacts(id) ON DELETE SET NULL,
  contract_id UUID REFERENCES client_contracts(id) ON DELETE SET NULL,
  category cli_ticket_category NOT NULL DEFAULT 'atendimento_servico',
  priority cli_ticket_priority NOT NULL DEFAULT 'media',
  title TEXT NOT NULL CHECK (char_length(title) BETWEEN 3 AND 200),
  description TEXT NOT NULL CHECK (char_length(description) BETWEEN 10 AND 5000),
  status cli_ticket_status NOT NULL DEFAULT 'aberto',
  responsible_identity_id UUID REFERENCES auth_identities(id) ON DELETE SET NULL,
  responsible_name TEXT CHECK (responsible_name IS NULL OR char_length(responsible_name) BETWEEN 2 AND 200),
  sla_due_at TIMESTAMPTZ,
  sla_paused_at TIMESTAMPTZ,
  sla_pause_reason cli_sla_pause_reason,
  sla_total_paused_seconds BIGINT NOT NULL DEFAULT 0 CHECK (sla_total_paused_seconds >=0),
  reopen_count INT NOT NULL DEFAULT 0 CHECK (reopen_count >=0),
  last_reopen_reason TEXT CHECK (last_reopen_reason IS NULL OR char_length(last_reopen_reason) BETWEEN 10 AND 1000),
  created_by_identity UUID REFERENCES auth_identities(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  resolved_at TIMESTAMPTZ,
  closed_at TIMESTAMPTZ,
  CONSTRAINT chk_sla_pause_reason_required CHECK ((sla_paused_at IS NULL AND sla_pause_reason IS NULL) OR (sla_paused_at IS NOT NULL AND sla_pause_reason IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS cli_tickets_v2_account_idx ON cli_tickets_v2(client_account_id, created_at DESC);
CREATE INDEX IF NOT EXISTS cli_tickets_v2_status_idx ON cli_tickets_v2(status, created_at DESC);
CREATE INDEX IF NOT EXISTS cli_tickets_v2_protocol_idx ON cli_tickets_v2(protocol);
CREATE INDEX IF NOT EXISTS cli_tickets_v2_contract_idx ON cli_tickets_v2(contract_id);

CREATE TABLE IF NOT EXISTS cli_ticket_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id UUID NOT NULL REFERENCES cli_tickets_v2(id) ON DELETE CASCADE,
  identity_id UUID REFERENCES auth_identities(id) ON DELETE SET NULL,
  contact_id UUID REFERENCES cli_client_contacts(id) ON DELETE SET NULL,
  message_type cli_ticket_message_type NOT NULL DEFAULT 'mensagem',
  content TEXT NOT NULL CHECK (char_length(content) BETWEEN 1 AND 5000),
  is_internal BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS cli_ticket_messages_ticket_idx ON cli_ticket_messages(ticket_id, created_at DESC);

CREATE TABLE IF NOT EXISTS cli_ticket_attachments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id UUID NOT NULL REFERENCES cli_tickets_v2(id) ON DELETE CASCADE,
  message_id UUID REFERENCES cli_ticket_messages(id) ON DELETE SET NULL,
  file_name TEXT NOT NULL CHECK (char_length(file_name) BETWEEN 1 AND 500),
  file_url TEXT NOT NULL CHECK (char_length(file_url) BETWEEN 5 AND 1000),
  storage_key TEXT NOT NULL UNIQUE CHECK (char_length(storage_key) BETWEEN 5 AND 500),
  uploaded_by_identity UUID REFERENCES auth_identities(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS cli_ticket_attachments_ticket_idx ON cli_ticket_attachments(ticket_id);

CREATE TABLE IF NOT EXISTS cli_ticket_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id UUID NOT NULL REFERENCES cli_tickets_v2(id) ON DELETE CASCADE,
  previous_status cli_ticket_status,
  next_status cli_ticket_status NOT NULL,
  changed_by_identity UUID REFERENCES auth_identities(id),
  changed_by_name TEXT CHECK (changed_by_name IS NULL OR char_length(changed_by_name) BETWEEN 2 AND 200),
  reason TEXT CHECK (reason IS NULL OR char_length(reason) BETWEEN 10 AND 1000),
  is_reopen BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS cli_ticket_history_ticket_idx ON cli_ticket_history(ticket_id, created_at DESC);

CREATE TABLE IF NOT EXISTS cli_ticket_sla_pauses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id UUID NOT NULL REFERENCES cli_tickets_v2(id) ON DELETE CASCADE,
  paused_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  resumed_at TIMESTAMPTZ,
  reason cli_sla_pause_reason NOT NULL,
  paused_by_identity UUID REFERENCES auth_identities(id),
  pause_duration_seconds BIGINT GENERATED ALWAYS AS (CASE WHEN resumed_at IS NOT NULL THEN EXTRACT(EPOCH FROM (resumed_at - paused_at))::BIGINT ELSE 0 END) STORED,
  notes TEXT CHECK (notes IS NULL OR char_length(notes) BETWEEN 10 AND 1000),
  CONSTRAINT chk_resumed_after_paused CHECK (resumed_at IS NULL OR resumed_at >= paused_at)
);
CREATE INDEX IF NOT EXISTS cli_ticket_sla_pauses_ticket_idx ON cli_ticket_sla_pauses(ticket_id, paused_at DESC);

-- CLI-07 visitas agenda
CREATE TABLE IF NOT EXISTS cli_visits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  protocol TEXT NOT NULL UNIQUE CHECK (protocol ~ '^VIS-CLI-[0-9]{8}-[A-Z0-9]{4}$'),
  client_account_id UUID NOT NULL REFERENCES client_accounts(id) ON DELETE CASCADE,
  contract_id UUID REFERENCES client_contracts(id) ON DELETE SET NULL,
  ticket_id UUID REFERENCES cli_tickets_v2(id) ON DELETE SET NULL,
  visit_type cli_visit_type NOT NULL DEFAULT 'visita_tecnica',
  title TEXT NOT NULL CHECK (char_length(title) BETWEEN 5 AND 200),
  description TEXT CHECK (description IS NULL OR char_length(description) BETWEEN 10 AND 2000),
  scheduled_at TIMESTAMPTZ NOT NULL,
  confirmed_at TIMESTAMPTZ,
  rescheduled_from TIMESTAMPTZ,
  rescheduled_to TIMESTAMPTZ,
  reschedule_reason TEXT CHECK (reschedule_reason IS NULL OR char_length(reschedule_reason) BETWEEN 10 AND 1000),
  status cli_visit_status NOT NULL DEFAULT 'agendada',
  responsible_name TEXT CHECK (responsible_name IS NULL OR char_length(responsible_name) BETWEEN 2 AND 200),
  location TEXT CHECK (location IS NULL OR char_length(location) BETWEEN 3 AND 500),
  created_by_identity UUID REFERENCES auth_identities(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_rescheduled_reason_required CHECK ((rescheduled_from IS NULL AND reschedule_reason IS NULL) OR (rescheduled_from IS NOT NULL AND reschedule_reason IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS cli_visits_account_idx ON cli_visits(client_account_id, scheduled_at DESC);
CREATE INDEX IF NOT EXISTS cli_visits_protocol_idx ON cli_visits(protocol);
CREATE INDEX IF NOT EXISTS cli_visits_status_idx ON cli_visits(status);

CREATE TABLE IF NOT EXISTS cli_visit_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  visit_id UUID NOT NULL REFERENCES cli_visits(id) ON DELETE CASCADE,
  previous_status cli_visit_status,
  next_status cli_visit_status NOT NULL,
  changed_by_identity UUID REFERENCES auth_identities(id),
  reason TEXT CHECK (reason IS NULL OR char_length(reason) BETWEEN 10 AND 1000),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS cli_visit_history_visit_idx ON cli_visit_history(visit_id, created_at DESC);

-- CLI-08 relatórios execução medição/aceite
CREATE TABLE IF NOT EXISTS cli_client_reports_v2 (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  protocol TEXT NOT NULL UNIQUE CHECK (protocol ~ '^REP-CLI-[0-9]{8}-[A-Z0-9]{4}$'),
  client_account_id UUID NOT NULL REFERENCES client_accounts(id) ON DELETE CASCADE,
  contract_id UUID REFERENCES client_contracts(id) ON DELETE SET NULL,
  visit_id UUID REFERENCES cli_visits(id) ON DELETE SET NULL,
  report_type cli_report_type NOT NULL DEFAULT 'execucao',
  title TEXT NOT NULL CHECK (char_length(title) BETWEEN 5 AND 200),
  content TEXT NOT NULL CHECK (char_length(content) BETWEEN 20 AND 10000),
  period_start DATE,
  period_end DATE,
  status cli_report_status NOT NULL DEFAULT 'rascunho',
  reviewed_by_identity UUID REFERENCES auth_identities(id),
  reviewed_at TIMESTAMPTZ,
  review_notes TEXT CHECK (review_notes IS NULL OR char_length(review_notes) BETWEEN 10 AND 2000),
  approved_by_identity UUID REFERENCES auth_identities(id),
  approved_at TIMESTAMPTZ,
  sent_at TIMESTAMPTZ,
  is_private BOOLEAN NOT NULL DEFAULT true,
  created_by_identity UUID REFERENCES auth_identities(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT chk_period_end_ge_start CHECK (period_end IS NULL OR period_start IS NULL OR period_end >= period_start)
);
CREATE INDEX IF NOT EXISTS cli_client_reports_v2_account_idx ON cli_client_reports_v2(client_account_id, created_at DESC);
CREATE INDEX IF NOT EXISTS cli_client_reports_v2_protocol_idx ON cli_client_reports_v2(protocol);

CREATE TABLE IF NOT EXISTS cli_client_report_history_v2 (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id UUID NOT NULL REFERENCES cli_client_reports_v2(id) ON DELETE CASCADE,
  previous_status cli_report_status,
  next_status cli_report_status NOT NULL,
  changed_by_identity UUID REFERENCES auth_identities(id),
  reason TEXT CHECK (reason IS NULL OR char_length(reason) BETWEEN 10 AND 1000),
  is_review BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS cli_client_report_history_v2_report_idx ON cli_client_report_history_v2(report_id, created_at DESC);

-- Triggers updated_at
CREATE OR REPLACE FUNCTION update_cli_tickets_v2_updated_at() RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_cli_tickets_v2_updated_at ON cli_tickets_v2;
CREATE TRIGGER trg_cli_tickets_v2_updated_at BEFORE UPDATE ON cli_tickets_v2 FOR EACH ROW EXECUTE FUNCTION update_cli_tickets_v2_updated_at();

CREATE OR REPLACE FUNCTION update_cli_visits_updated_at() RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_cli_visits_updated_at ON cli_visits;
CREATE TRIGGER trg_cli_visits_updated_at BEFORE UPDATE ON cli_visits FOR EACH ROW EXECUTE FUNCTION update_cli_visits_updated_at();

CREATE OR REPLACE FUNCTION update_cli_reports_v2_updated_at() RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_cli_reports_v2_updated_at ON cli_client_reports_v2;
CREATE TRIGGER trg_cli_reports_v2_updated_at BEFORE UPDATE ON cli_client_reports_v2 FOR EACH ROW EXECUTE FUNCTION update_cli_reports_v2_updated_at();

-- Immutable history triggers
CREATE OR REPLACE FUNCTION prevent_cli_ticket_history_update_delete() RETURNS TRIGGER AS $$ BEGIN RAISE EXCEPTION 'cli_ticket_history is immutable'; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_cli_ticket_history_immutable ON cli_ticket_history;
CREATE TRIGGER trg_cli_ticket_history_immutable BEFORE UPDATE OR DELETE ON cli_ticket_history FOR EACH ROW EXECUTE FUNCTION prevent_cli_ticket_history_update_delete();

CREATE OR REPLACE FUNCTION prevent_cli_visit_history_update_delete() RETURNS TRIGGER AS $$ BEGIN RAISE EXCEPTION 'cli_visit_history is immutable'; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_cli_visit_history_immutable ON cli_visit_history;
CREATE TRIGGER trg_cli_visit_history_immutable BEFORE UPDATE OR DELETE ON cli_visit_history FOR EACH ROW EXECUTE FUNCTION prevent_cli_visit_history_update_delete();

CREATE OR REPLACE FUNCTION prevent_cli_report_history_v2_update_delete() RETURNS TRIGGER AS $$ BEGIN RAISE EXCEPTION 'cli_client_report_history_v2 is immutable'; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trg_cli_report_history_v2_immutable ON cli_client_report_history_v2;
CREATE TRIGGER trg_cli_report_history_v2_immutable BEFORE UPDATE OR DELETE ON cli_client_report_history_v2 FOR EACH ROW EXECUTE FUNCTION prevent_cli_report_history_v2_update_delete();

-- Audit expansion
ALTER TABLE audit_log DROP CONSTRAINT IF EXISTS audit_log_action_check;
ALTER TABLE audit_log ADD CONSTRAINT audit_log_action_check CHECK (
  action IN (
    'staff_login','invite_create','invite_revoke','invite_accept','login','logout','mfa_challenge','mfa_verify','mfa_reset',
    'client_account_create','client_account_update','client_access_grant','client_access_revoke','client_contract_create','client_contract_update',
    'client_document_upload','client_document_download','client_ticket_open','client_ticket_status','client_ticket_message',
    'service_catalog_create','service_catalog_update','equipment_create','equipment_update','inspection_create','inspection_update',
    'labor_budget_create','labor_budget_update','technical_budget_create','technical_budget_update','cost_parameter_create','cost_parameter_update',
    'price_scenario_create','price_scenario_update','discount_tier_create','discount_tier_update','proposal_create','proposal_update','proposal_delivery_create','proposal_delivery_update','proposal_acceptance_create','proposal_acceptance_update','contract_create','contract_update','report_create','report_update','commission_create','commission_update','commercial_library_create','commercial_library_update','partnership_create','partnership_update','renewal_create','renewal_update',
    'contract_unit_create','contract_unit_update','contract_post_create','contract_post_update','contract_status_transition','contract_amendment_create','contract_amendment_update','contract_alert_create','contract_alert_update','contract_doc_obligation_create','contract_doc_obligation_update','contract_implantation_create','contract_implantation_update','contract_implantation_block_create','contract_closure_create','contract_closure_update','contract_fiscal_create','contract_fiscal_update','contract_management_diary_create','contract_management_diary_update',
    'notification_create','notification_update','notification_preference_update','observability_log','healthcheck','backup_create','backup_update','privacy_policy_update','lgpd_request_create','lgpd_request_update','retention_policy_create','retention_policy_update','incident_create','incident_update','config_flag_create','config_flag_update','dependency_create','dependency_update','integration_log_create','operational_budget_create','operational_budget_update','env_isolation_check','maintenance_doc_create','maintenance_doc_update',
    'hr_employee_create','hr_employee_update','hr_recruitment_create','hr_recruitment_update','hr_termination_create','hr_termination_update','hr_absence_create','hr_absence_update','hr_benefit_create','hr_benefit_update','hr_training_create','hr_training_update','hr_advanced_create','hr_advanced_update','emp_portal_access','emp_ops_access','emp_self_update','emp_advanced2_create','emp_pwa_config','ops_structure_create','ops_structure_update','ops_coverage_request_create','ops_coverage_request_update','ops_handover_create','ops_handover_update','ops_occurrence_create','ops_occurrence_update','ops_checklist_create','ops_checklist_update','ops_supervision_visit_create','ops_supervision_visit_update','ops_patrol_create','ops_patrol_update','ops_key_create','ops_key_update','ops_client_report_create','ops_client_report_update','ops_metrics_definition_create','ops_metrics_snapshot_create','ops_assisted_proposal_create','ops_assisted_proposal_publish','ops_cleaning_environment_create','ops_cleaning_routine_create','ops_cleaning_execution_create','ops_cleaning_nonconformity_create','ops_monitoring_connector_create','ops_monitoring_event_create','ops_monitoring_event_ack','ops_monitoring_event_escalate',
    'cli_entry_point_create','cli_entry_point_update','cli_old_route_create','cli_client_contact_create','cli_contact_scope_create','cli_contact_delegate','cli_contract_item_create','cli_contract_scope_create','cli_contract_vigencia_create','cli_document_category_create','cli_client_document_v2_create','cli_document_version_create','cli_document_download','cli_document_search',
    'cli_ticket_v2_create','cli_ticket_v2_status','cli_ticket_v2_reopen','cli_ticket_message_create','cli_ticket_attachment_create','cli_ticket_sla_pause','cli_ticket_sla_resume','cli_visit_create','cli_visit_status','cli_visit_confirm','cli_visit_reschedule','cli_report_v2_create','cli_report_v2_status','cli_report_v2_review'
  )
);
