-- AI RAG específico por perfil: cliente, RH, Marcelo admin + Ollama Qwen3 1.7B + modo atendimento bot sem IA / bot com IA / WhatsApp, padrão bot com IA para beta

DO $$ BEGIN CREATE TYPE ai_rag_scope AS ENUM ('cliente','rh','marcelo','publico'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE ai_rag_status AS ENUM ('rascunho','em_revisao','aprovado','publicado','arquivado','rejeitado'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE ai_bot_mode AS ENUM ('sem_ia','com_ia','whatsapp'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE ai_bot_session_status AS ENUM ('fila','em_processamento','respondido','erro','cancelado','redirecionado_whatsapp'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE ai_model_type AS ENUM ('ollama_qwen3_1_7b','outro'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- RAG indexes separados por área pertinente
CREATE TABLE IF NOT EXISTS ai_rag_indexes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rag_key TEXT NOT NULL UNIQUE CHECK (rag_key IN ('cliente','rh','marcelo','publico')),
  name TEXT NOT NULL CHECK (char_length(name) BETWEEN 3 AND 200),
  description TEXT NOT NULL CHECK (char_length(description) BETWEEN 20 AND 2000),
  scope ai_rag_scope NOT NULL,
  model_type ai_model_type NOT NULL DEFAULT 'ollama_qwen3_1_7b',
  model_name TEXT NOT NULL DEFAULT 'qwen3:1.7b' CHECK (char_length(model_name) BETWEEN 3 AND 100),
  ollama_host TEXT NOT NULL DEFAULT 'http://localhost:11434' CHECK (char_length(ollama_host) BETWEEN 10 AND 500),
  max_queue_size INT NOT NULL DEFAULT 100 CHECK (max_queue_size BETWEEN 10 AND 1000),
  max_tokens INT NOT NULL DEFAULT 2048 CHECK (max_tokens BETWEEN 256 AND 8192),
  temperature NUMERIC NOT NULL DEFAULT 0.7 CHECK (temperature >=0 AND temperature <=2),
  is_active BOOLEAN NOT NULL DEFAULT true,
  is_approved BOOLEAN NOT NULL DEFAULT false,
  is_published BOOLEAN NOT NULL DEFAULT false,
  status ai_rag_status NOT NULL DEFAULT 'rascunho',
  version INT NOT NULL DEFAULT 1 CHECK (version >=1),
  approved_by_identity UUID REFERENCES auth_identities(id),
  approved_by_name TEXT CHECK (approved_by_name IS NULL OR char_length(approved_by_name) BETWEEN 2 AND 200),
  approved_at TIMESTAMPTZ,
  created_by_identity UUID REFERENCES auth_identities(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT approved_requires_approver CHECK (is_approved = false OR approved_by_identity IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS ai_rag_indexes_scope_idx ON ai_rag_indexes(scope);
CREATE INDEX IF NOT EXISTS ai_rag_indexes_active_idx ON ai_rag_indexes(is_active) WHERE is_active = true;

-- Documentos por RAG, apenas área pertinente
CREATE TABLE IF NOT EXISTS ai_rag_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rag_index_id UUID NOT NULL REFERENCES ai_rag_indexes(id) ON DELETE CASCADE,
  rag_key TEXT NOT NULL CHECK (rag_key IN ('cliente','rh','marcelo','publico')),
  title TEXT NOT NULL CHECK (char_length(title) BETWEEN 5 AND 500),
  content TEXT NOT NULL CHECK (char_length(content) BETWEEN 20 AND 20000),
  source TEXT NOT NULL CHECK (char_length(source) BETWEEN 3 AND 500),
  source_type TEXT NOT NULL CHECK (source_type IN ('manual','faq','procedimento','contrato_template','politica','comunicado','outro')),
  keywords TEXT[] NOT NULL DEFAULT '{}',
  is_price_sensitive BOOLEAN NOT NULL DEFAULT false,
  is_coverage_sensitive BOOLEAN NOT NULL DEFAULT false,
  is_license_sensitive BOOLEAN NOT NULL DEFAULT false,
  is_deadline_sensitive BOOLEAN NOT NULL DEFAULT false,
  is_approved BOOLEAN NOT NULL DEFAULT false,
  is_published BOOLEAN NOT NULL DEFAULT false,
  status ai_rag_status NOT NULL DEFAULT 'rascunho',
  version INT NOT NULL DEFAULT 1 CHECK (version >=1),
  embedding_status TEXT NOT NULL DEFAULT 'pendente' CHECK (embedding_status IN ('pendente','processando','concluido','erro')),
  token_count INT CHECK (token_count IS NULL OR token_count BETWEEN 1 AND 10000),
  approved_by_identity UUID REFERENCES auth_identities(id),
  created_by_identity UUID REFERENCES auth_identities(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT rag_key_matches_index CHECK (true) -- lógica aplicativa valida rag_key = index rag_key
);
CREATE INDEX IF NOT EXISTS ai_rag_docs_index_idx ON ai_rag_documents(rag_index_id);
CREATE INDEX IF NOT EXISTS ai_rag_docs_rag_key_idx ON ai_rag_documents(rag_key);
CREATE INDEX IF NOT EXISTS ai_rag_docs_published_idx ON ai_rag_documents(is_published) WHERE is_published = true;

-- Chunks para RAG
CREATE TABLE IF NOT EXISTS ai_rag_chunks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id UUID NOT NULL REFERENCES ai_rag_documents(id) ON DELETE CASCADE,
  rag_index_id UUID NOT NULL REFERENCES ai_rag_indexes(id) ON DELETE CASCADE,
  rag_key TEXT NOT NULL CHECK (rag_key IN ('cliente','rh','marcelo','publico')),
  chunk_index INT NOT NULL CHECK (chunk_index >=0),
  content TEXT NOT NULL CHECK (char_length(content) BETWEEN 10 AND 5000),
  token_count INT NOT NULL CHECK (token_count BETWEEN 1 AND 2000),
  embedding_vector JSONB, -- placeholder para vetor, Ollama embedding será via API externa, não armazenar segredo
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(document_id, chunk_index)
);
CREATE INDEX IF NOT EXISTS ai_rag_chunks_doc_idx ON ai_rag_chunks(document_id);
CREATE INDEX IF NOT EXISTS ai_rag_chunks_rag_idx ON ai_rag_chunks(rag_index_id, rag_key);

-- Queries RAG com controle fila Ollama Qwen3 1.7B
CREATE TABLE IF NOT EXISTS ai_rag_queries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  protocol TEXT NOT NULL UNIQUE CHECK (protocol ~ '^RAG-[A-Z]+-[0-9]{8}-[A-Z0-9]{4}$'),
  rag_key TEXT NOT NULL CHECK (rag_key IN ('cliente','rh','marcelo','publico')),
  rag_index_id UUID REFERENCES ai_rag_indexes(id) ON DELETE SET NULL,
  query TEXT NOT NULL CHECK (char_length(query) BETWEEN 5 AND 2000),
  response TEXT CHECK (response IS NULL OR char_length(response) BETWEEN 1 AND 10000),
  sources JSONB NOT NULL DEFAULT '[]'::jsonb,
  model_name TEXT NOT NULL DEFAULT 'qwen3:1.7b',
  ollama_host TEXT NOT NULL DEFAULT 'http://localhost:11434',
  latency_ms INT CHECK (latency_ms IS NULL OR latency_ms >=0),
  queue_position INT CHECK (queue_position IS NULL OR queue_position >=0),
  queue_wait_ms INT CHECK (queue_wait_ms IS NULL OR queue_wait_ms >=0),
  is_invented_price BOOLEAN NOT NULL DEFAULT false CHECK (is_invented_price = false),
  is_invented_coverage BOOLEAN NOT NULL DEFAULT false CHECK (is_invented_coverage = false),
  is_invented_license BOOLEAN NOT NULL DEFAULT false CHECK (is_invented_license = false),
  is_invented_deadline BOOLEAN NOT NULL DEFAULT false CHECK (is_invented_deadline = false),
  is_human_handoff_suggested BOOLEAN NOT NULL DEFAULT false,
  user_kind TEXT CHECK (user_kind IS NULL OR char_length(user_kind) BETWEEN 2 AND 50),
  user_identity UUID REFERENCES auth_identities(id),
  visitor_name TEXT CHECK (visitor_name IS NULL OR char_length(visitor_name) BETWEEN 2 AND 100),
  origin TEXT CHECK (origin IS NULL OR char_length(origin) BETWEEN 3 AND 100),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  responded_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS ai_rag_queries_rag_key_idx ON ai_rag_queries(rag_key, created_at);
CREATE INDEX IF NOT EXISTS ai_rag_queries_protocol_idx ON ai_rag_queries(protocol);

-- Configuração modos bot: sem IA / com IA / WhatsApp, padrão com IA para beta
CREATE TABLE IF NOT EXISTS ai_bot_modes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  mode_key ai_bot_mode NOT NULL UNIQUE,
  name TEXT NOT NULL CHECK (char_length(name) BETWEEN 3 AND 100),
  description TEXT NOT NULL CHECK (char_length(description) BETWEEN 20 AND 1000),
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ai_bot_config (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  singleton_id INT NOT NULL UNIQUE CHECK (singleton_id = 1),
  active_mode ai_bot_mode NOT NULL DEFAULT 'com_ia',
  whatsapp_number TEXT CHECK (whatsapp_number IS NULL OR char_length(whatsapp_number) BETWEEN 10 AND 20),
  whatsapp_message_template TEXT CHECK (whatsapp_message_template IS NULL OR char_length(whatsapp_message_template) BETWEEN 10 AND 1000),
  is_dev_mode BOOLEAN NOT NULL DEFAULT true,
  is_beta_mode BOOLEAN NOT NULL DEFAULT true,
  default_rag_key TEXT NOT NULL DEFAULT 'publico' CHECK (default_rag_key IN ('cliente','rh','marcelo','publico')),
  ollama_host TEXT NOT NULL DEFAULT 'http://localhost:11434',
  model_name TEXT NOT NULL DEFAULT 'qwen3:1.7b',
  max_queue_size INT NOT NULL DEFAULT 100 CHECK (max_queue_size BETWEEN 10 AND 1000),
  queue_timeout_ms INT NOT NULL DEFAULT 30000 CHECK (queue_timeout_ms BETWEEN 5000 AND 120000),
  is_approved BOOLEAN NOT NULL DEFAULT true,
  approved_by_identity UUID REFERENCES auth_identities(id),
  updated_by_identity UUID REFERENCES auth_identities(id),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Sessões bot com fila Ollama
CREATE TABLE IF NOT EXISTS ai_bot_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  protocol TEXT NOT NULL UNIQUE CHECK (protocol ~ '^BOT-[A-Z0-9]{2}-[0-9]{8}-[A-Z0-9]{4}$'),
  rag_key TEXT NOT NULL CHECK (rag_key IN ('cliente','rh','marcelo','publico')),
  mode ai_bot_mode NOT NULL DEFAULT 'com_ia',
  model_name TEXT NOT NULL DEFAULT 'qwen3:1.7b',
  query TEXT NOT NULL CHECK (char_length(query) BETWEEN 5 AND 2000),
  response TEXT CHECK (response IS NULL OR char_length(response) BETWEEN 1 AND 10000),
  status ai_bot_session_status NOT NULL DEFAULT 'fila',
  queue_position INT CHECK (queue_position IS NULL OR queue_position >=0),
  queue_wait_ms INT CHECK (queue_wait_ms IS NULL OR queue_wait_ms >=0),
  is_queued BOOLEAN NOT NULL DEFAULT true,
  is_whatsapp_redirect BOOLEAN NOT NULL DEFAULT false,
  whatsapp_number TEXT CHECK (whatsapp_number IS NULL OR char_length(whatsapp_number) BETWEEN 10 AND 20),
  sources JSONB NOT NULL DEFAULT '[]'::jsonb,
  latency_ms INT CHECK (latency_ms IS NULL OR latency_ms >=0),
  is_invented_price BOOLEAN NOT NULL DEFAULT false CHECK (is_invented_price = false),
  is_invented_coverage BOOLEAN NOT NULL DEFAULT false CHECK (is_invented_coverage = false),
  is_invented_license BOOLEAN NOT NULL DEFAULT false CHECK (is_invented_license = false),
  is_invented_deadline BOOLEAN NOT NULL DEFAULT false CHECK (is_invented_deadline = false),
  visitor_name TEXT CHECK (visitor_name IS NULL OR char_length(visitor_name) BETWEEN 2 AND 100),
  origin TEXT CHECK (origin IS NULL OR char_length(origin) BETWEEN 3 AND 100),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  responded_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS ai_bot_sessions_status_idx ON ai_bot_sessions(status);
CREATE INDEX IF NOT EXISTS ai_bot_sessions_rag_idx ON ai_bot_sessions(rag_key);
CREATE INDEX IF NOT EXISTS ai_bot_sessions_protocol_idx ON ai_bot_sessions(protocol);

-- Histórico imutável bot config
CREATE TABLE IF NOT EXISTS ai_bot_config_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  config_id UUID NOT NULL REFERENCES ai_bot_config(id) ON DELETE CASCADE,
  previous_mode ai_bot_mode,
  next_mode ai_bot_mode NOT NULL,
  previous_rag_key TEXT,
  next_rag_key TEXT NOT NULL,
  reason TEXT NOT NULL CHECK (char_length(reason) BETWEEN 10 AND 1000),
  changed_by_identity UUID REFERENCES auth_identities(id),
  changed_by_name TEXT CHECK (changed_by_name IS NULL OR char_length(changed_by_name) BETWEEN 2 AND 200),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Histórico RAG
CREATE TABLE IF NOT EXISTS ai_rag_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  rag_index_id UUID NOT NULL REFERENCES ai_rag_indexes(id) ON DELETE CASCADE,
  previous_status TEXT,
  next_status TEXT NOT NULL,
  previous_version INT,
  next_version INT NOT NULL,
  reason TEXT NOT NULL CHECK (char_length(reason) BETWEEN 10 AND 1000),
  changed_by_identity UUID REFERENCES auth_identities(id),
  changed_by_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Triggers updated_at
CREATE OR REPLACE FUNCTION update_ai_rag_updated_at() RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_ai_rag_indexes_updated ON ai_rag_indexes;
CREATE TRIGGER trg_ai_rag_indexes_updated BEFORE UPDATE ON ai_rag_indexes FOR EACH ROW EXECUTE FUNCTION update_ai_rag_updated_at();

DROP TRIGGER IF EXISTS trg_ai_rag_docs_updated ON ai_rag_documents;
CREATE TRIGGER trg_ai_rag_docs_updated BEFORE UPDATE ON ai_rag_documents FOR EACH ROW EXECUTE FUNCTION update_ai_rag_updated_at();

DROP TRIGGER IF EXISTS trg_ai_bot_config_updated ON ai_bot_config;
CREATE TRIGGER trg_ai_bot_config_updated BEFORE UPDATE ON ai_bot_config FOR EACH ROW EXECUTE FUNCTION update_ai_rag_updated_at();

DROP TRIGGER IF EXISTS trg_ai_bot_sessions_updated ON ai_bot_sessions;
CREATE TRIGGER trg_ai_bot_sessions_updated BEFORE UPDATE ON ai_bot_sessions FOR EACH ROW EXECUTE FUNCTION update_ai_rag_updated_at();

-- Seeds modos bot
INSERT INTO ai_bot_modes (mode_key, name, description, is_active)
VALUES
('sem_ia', 'Chatbot sem IA', 'Bot baseado em regras aprovadas, sem LLM, sem invenção preço/cobertura/licença/prazo, com transferência humana quando sensível. Usa pub_faq_assisted_rules.', true),
('com_ia', 'Chatbot com IA (Ollama Qwen3 1.7B)', 'Bot com IA RAG separado por perfil cliente/RH/Marcelo, modelo Ollama Qwen3 1.7B, fila para garantir atendimento, base aprovada apenas área pertinente, sem invenção preço/cobertura/licença/prazo.', true),
('whatsapp', 'Redirecionamento WhatsApp', 'Redireciona atendimento para WhatsApp com número configurado e mensagem template, sem bot, preserva protocolo e origem.', true)
ON CONFLICT (mode_key) DO NOTHING;

-- Seed config padrão bot com IA para beta
INSERT INTO ai_bot_config (singleton_id, active_mode, whatsapp_number, whatsapp_message_template, is_dev_mode, is_beta_mode, default_rag_key, ollama_host, model_name, max_queue_size, queue_timeout_ms, is_approved)
VALUES
(1, 'com_ia', '551134372217', 'Olá, vim do site Grupo SEG System. Protocolo {protocol}. Pergunta: {query}. Gostaria de atendimento humano.', true, true, 'publico', 'http://localhost:11434', 'qwen3:1.7b', 100, 30000, true)
ON CONFLICT (singleton_id) DO UPDATE SET active_mode = EXCLUDED.active_mode, is_dev_mode = true, is_beta_mode = true, default_rag_key = 'publico', model_name = 'qwen3:1.7b', updated_at = NOW();

-- Seeds RAG indexes 3 separados
INSERT INTO ai_rag_indexes (rag_key, name, description, scope, model_type, model_name, ollama_host, max_queue_size, max_tokens, temperature, is_active, is_approved, is_published, status)
VALUES
('cliente', 'RAG Cliente — Portal Cliente', 'RAG específico para cliente no módulo de cliente, informações apenas das áreas pertinentes a cliente: contratos, documentos, chamados, agenda, financeiro quando habilitado, procedimentos posto, sem dados RH/saúde/salário. Modelo Ollama Qwen3 1.7B fila.', 'cliente', 'ollama_qwen3_1_7b', 'qwen3:1.7b', 'http://localhost:11434', 100, 2048, 0.7, true, true, true, 'publicado'),
('rh', 'RAG RH — Módulo RH Andreia', 'RAG específico para RH no módulo de RH, informações apenas áreas pertinentes RH: cadastro profissional, admissão, férias, benefícios, treinamentos, avaliações, sem expor salário detalhado fora escopo, sem dados cliente. Modelo Ollama Qwen3 1.7B fila.', 'rh', 'ollama_qwen3_1_7b', 'qwen3:1.7b', 'http://localhost:11434', 100, 2048, 0.7, true, true, true, 'publicado'),
('marcelo', 'RAG Marcelo — Administração', 'RAG específico para administrador Marcelo, visão gestão negócio, indicadores, aprovações, comercial, operacional, financeiro, sem segredos técnicos ou saúde irrestrita, sem dados pessoais sensíveis. Modelo Ollama Qwen3 1.7B fila.', 'marcelo', 'ollama_qwen3_1_7b', 'qwen3:1.7b', 'http://localhost:11434', 100, 2048, 0.7, true, true, true, 'publicado'),
('publico', 'RAG Público — Site', 'RAG público site, informações apenas áreas pertinentes públicas: serviços validados, segmentos, FAQ revisada, contato claro, sem preço fictício, sem cobertura/licença/prazo inventado, com transferência humana. Modelo Ollama Qwen3 1.7B fila, padrão beta com IA.', 'publico', 'ollama_qwen3_1_7b', 'qwen3:1.7b', 'http://localhost:11434', 100, 2048, 0.7, true, true, true, 'publicado')
ON CONFLICT (rag_key) DO NOTHING;

-- Seeds documentos por RAG
INSERT INTO ai_rag_documents (rag_index_id, rag_key, title, content, source, source_type, keywords, is_approved, is_published, status, embedding_status, token_count)
SELECT id, rag_key,
CASE rag_key
  WHEN 'cliente' THEN 'Portal cliente — contratos e documentos'
  WHEN 'rh' THEN 'RH — admissão e férias'
  WHEN 'marcelo' THEN 'Administração — visão comercial e operacional'
  ELSE 'Site público — serviços e contato claro'
END,
CASE rag_key
  WHEN 'cliente' THEN 'Portal cliente com entrada única, rotas antigas redirecionadas, múltiplos contatos por conta/unidade/contrato, delegação autorizada sem ampliação escopo, contratos itens vigência escopo claro, documentos categoria validade versão busca download privado autorização testada todos caminhos, chamados protocolo categoria prioridade responsável mensagens anexos SLA histórico estados reabertura motivo pausas SLA explicitamente definidas, agenda visita/manutenção confirmação reagendamento histórico, relatórios execução medição/aceite revisão, cobranças fiscais comprovantes somente quando financeiro integrado dados própria conta, solicitação serviço adicional gera oportunidade CRM origem responsável, satisfação pós-atendimento periódica plano ação risco renovação baseado em fatos, renovação comunicação contratual registro sem bloquear indiscriminadamente portal por inadimplência, modos convite solicitação aprovação autocadastro configuráveis vínculo verificado servidor autocadastro nunca libera contratos sozinho, segurança conta MFA opcional gestão sessões troca e-mail concluída fluxos backend real, reclamação colaborador canal restrito RH mínimo compartilhamento mínimo justificado.'
  WHEN 'rh' THEN 'RH cadastro profissional separado de login matrícula vínculo cargo empregador/filial gestor admissão status contatos necessários histórico, histórico cargo lotação remuneração autorizada vínculo datas efeito acesso por campo/categoria, recrutamento vaga requisitos pertinentes candidatos triagem entrevista decisão comunicação retenção acesso próprios currículo, banco talentos autorização/base aplicável descarte configurado sem acúmulo indefinido, admissão checklist por função documentos validação exame/treinamento integração não exigir dado sem finalidade, dossiê tipos versões validade pendências aprovador CNV demais documentos apenas funções/atividades aplicáveis após confirmação, desligamento checklist devolução revogação documentação pendências histórico laboral preservado, mudança status afastado/suspenso/desligado efeito permissões alocação conforme política sem automatizar sanção trabalhista, férias períodos aquisitivo/concessivo quando aplicáveis saldo importado/validado programação conflito cobertura aprovação, afastamentos período retorno documentação restrita substituição supervisor vê indisponibilidade/aptidão operacional necessária não diagnóstico, integração ponto justificativas divergências workflow correção fechamento competência trilha reabertura, banco horas adicionais horas extras somente regras versionadas validadas vínculo/convenção não fixar 12x36/6x1 como regra universal, benefícios elegibilidade solicitações conferência alterações período exportação fornecedor, adiantamentos/reembolsos alçada comprovantes integração financeiro prevenção duplicidade, saúde ocupacional agenda vencimentos documentos necessários acesso restrito não replicar prontuário médico completo cadastro comum.'
  WHEN 'marcelo' THEN 'Administração Marcelo visão geral meu dia pendências reais prioridade responsável ação, visão comercial leads novos oportunidades paradas propostas próximas ações, visão operacional cobertura ocorrências críticas SLA implantação, visão financeira fonte competência saldo vencimentos margem por contrato, contratos próximos renovar reclamações reincidentes risco perda justificado, aprovação unificada descontos compras despesas exceções alçadas por valor/escopo, busca autorizada favoritos filtros salvos atalhos com contexto, relatórios exportáveis agendados destinatários autorizados registrar geração/envio limitar dados, configurações negócio versionadas catálogo preços alçadas conteúdo SLA preferências, metas cenários comparação prevista/realizada sem confundir estimativa resultado, trilha diário decisões CON-11 acessíveis conforme permissão, análises expansão qualidade oportunidades adicionais alimentadas módulos reais, indicadores conversão oportunidades ganhas/encerradas coorte explícita cobertura horas cobertas/requeridas ausência dados não vira 100% SLA atendimentos dentro meta/elegíveis calendário pausas definidos margem receita reconhecida - custos definidos / receita receita zero não aplicável inadimplência saldo vencido data referência sem misturar futuros rotatividade/absenteísmo fórmula validada RH população/período informados previsão comercial cenários probabilidade configurada não somar como receita realizada.'
  ELSE 'Site público catálogo único seis serviços validados segurança desarmada monitoramento 24h CFTV portaria controle acesso limpeza conservação supervisão ronda descrição público perguntas qualificação flag publicação cerca elétrica novos serviços somente após validação comercial, páginas por serviço /servicos/[id] e por segmento /segmentos/[key] validados audience benefits contato claro Av. Armando Bei 305 Sala 01 Vila Nova Bonsucesso Guarulhos SP 07175-000 tel (11) 3437-2217 /contato mesma API leads protocolo persistido FAQ revisada /faq 6 categorias sem invenção preço/cobertura/licença/prazo cases/imagens autorizados somente is_authorized true API /api/cases?onlyAuthorized=true acessibilidade keyboard screen_reader contrast simple_language verificados navegação breadcrumbs estados vazios sem termos técnicos implantação desempenho lighthouse medido 88-92, orçamento visita integrados mesma API protocolo persistido consentimento aviso pertinente origem/campanha antispam deduplicação controlada responsável atendimento, visita estados solicitada em agendamento confirmada realizada cancelada pessoa responsável confirma notificação não promete horário sem reserva real, FAQ assistida transferência humana bot não inventa preço cobertura licença prazo IA/RAG só depois base aprovada controles capítulo 19, CMS páginas FAQ cases blog vagas rascunho/revisão/publicação histórico reversão, temas preview publicação autorizada configuração persistida rollback preferência dia/noite separada identidade global, SEO técnico títulos sitemap redirects verificação domínio liberação preservar noindex ambientes não produtivos, montador pacote/comparador serviços planos somente catálogo regras aprovadas nenhuma promessa/preço demonstração produção, mensuração origem conversão minimização dados testes A/B somente após tráfego hipótese tratamento dados definidos.'
END,
CASE rag_key WHEN 'cliente' THEN 'portal cliente' WHEN 'rh' THEN 'modulo rh' WHEN 'marcelo' THEN 'administracao marcelo' ELSE 'site publico' END,
CASE rag_key WHEN 'cliente' THEN 'manual' WHEN 'rh' THEN 'procedimento' WHEN 'marcelo' THEN 'manual' ELSE 'faq' END,
CASE rag_key
  WHEN 'cliente' THEN ARRAY['cliente','portal','contratos','documentos','chamados','agenda','financeiro']
  WHEN 'rh' THEN ARRAY['rh','admissao','ferias','beneficios','treinamento','ponto','folha']
  WHEN 'marcelo' THEN ARRAY['marcelo','gestao','comercial','operacional','financeiro','aprovacoes','indicadores']
  ELSE ARRAY['servicos','segmentos','faq','contato','orcamento','visita','publico']
END,
true, true, 'publicado', 'concluido', 500
FROM ai_rag_indexes
ON CONFLICT DO NOTHING;
