import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";

const { Pool } = pg;
const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
let loadEnvConfig = () => {};
try {
  const nextEnv = await import("@next/env");
  loadEnvConfig = nextEnv.loadEnvConfig || nextEnv.default?.loadEnvConfig || loadEnvConfig;
  loadEnvConfig(projectRoot);
} catch {
  // @next/env not available in Next 16, fallback no-op; env already loaded via process.env
}

const optIn = process.env.RUN_DATABASE_INTEGRATION === "1";
const databaseUrl = process.env.DATABASE_URL || "";
const loopbackHosts = new Set(["127.0.0.1", "localhost", "::1", "[::1]"]);
function skipReason() {
  if (!optIn) return "set RUN_DATABASE_INTEGRATION=1 to run the client security flow against a real PostgreSQL";
  if (!databaseUrl) return "DATABASE_URL is missing; copy .env.example to .env.local first";
  if (!loopbackHosts.has(new URL(databaseUrl).hostname) && process.env.RUN_DATABASE_INTEGRATION_REMOTE !== "1") {
    return "DATABASE_URL is not a loopback database; set RUN_DATABASE_INTEGRATION_REMOTE=1 to allow it";
  }
  return null;
}
const skip = skipReason();
const testOptions = skip ? { skip } : {};

async function applyMigrations(pool) {
  for (const f of [
    "001-site-visual.sql","002-public-leads.sql","003-client-access.sql",
    "004-client-space.sql","005-client-security.sql","006-admin-identities.sql",
    "007-opcao-b-funcionarios.sql","008-document-contract-link.sql","009-mfa-challenge.sql"
  ]) {
    const sql = await readFile(path.join(projectRoot, "db/migrations", f), "utf8");
    await pool.query(sql);
  }
}

test("client security — vínculo restrito, unidade, MFA e troca de e-mail", testOptions, async (t) => {
  const pool = new Pool({ connectionString: databaseUrl, max: 2 });
  const runId = `${Date.now().toString(36)}${Math.floor(Math.random()*1000)}`;
  const cleanup = async () => {
    await pool.query("DELETE FROM auth_access_audit WHERE actor_id LIKE $1 OR target LIKE $1", [`%${runId}%`]).catch(()=>{});
    await pool.query("DELETE FROM auth_email_change WHERE identity_id IN (SELECT id FROM auth_identities WHERE email LIKE $1)", [`%${runId}%`]).catch(()=>{});
    await pool.query("DELETE FROM auth_mfa_challenges WHERE identity_id IN (SELECT id FROM auth_identities WHERE email LIKE $1)", [`%${runId}%`]).catch(()=>{});
    await pool.query("DELETE FROM auth_mfa WHERE identity_id IN (SELECT id FROM auth_identities WHERE email LIKE $1)", [`%${runId}%`]).catch(()=>{});
    await pool.query("DELETE FROM client_access_grants WHERE identity_id IN (SELECT id FROM auth_identities WHERE email LIKE $1)", [`%${runId}%`]).catch(()=>{});
    await pool.query("DELETE FROM client_contracts WHERE client_account_id IN (SELECT id FROM client_accounts WHERE display_name LIKE $1)", [`%${runId}%`]).catch(()=>{});
    await pool.query("DELETE FROM client_accounts WHERE display_name LIKE $1", [`%${runId}%`]).catch(()=>{});
    await pool.query("DELETE FROM auth_identities WHERE email LIKE $1", [`%${runId}%`]).catch(()=>{});
  };
  t.after(async () => { await cleanup(); await pool.end(); });

  await applyMigrations(pool);

  await t.test("vínculo restrito a contrato não enxerga os demais (deny-by-default + auditoria)", async () => {
    const identityEmail = `sec.contract.${runId}@exemplo.invalid`;
    const accountName = `Conta SEC Contract ${runId}`;
    const identityId = `11111111-1111-4111-8111-${runId.padStart(12,"0").slice(0,12)}`;
    // Use random UUIDs for simplicity
    const { randomUUID } = await import("node:crypto");
    const id1 = randomUUID();
    const accId = randomUUID();
    const c1 = randomUUID();
    const c2 = randomUUID();
    const grantId = randomUUID();

    await pool.query(`INSERT INTO auth_identities (id, kind, email, status) VALUES ($1,'client',$2,'active')`, [id1, identityEmail]);
    await pool.query(`INSERT INTO client_accounts (id, display_name, status, created_by) VALUES ($1,$2,'active','ti')`, [accId, accountName]);
    await pool.query(`INSERT INTO client_contracts (id, client_account_id, title, service, status, created_by) VALUES ($1,$2,'C1','Segurança Desarmada','active','ti'), ($3,$2,'C2','Câmeras e CFTV','active','ti')`, [c1, accId, c2]);
    await pool.query(
      `INSERT INTO client_access_grants (id, identity_id, client_account_id, reason, granted_by, contract_scope_mode, allowed_contract_ids) VALUES ($1,$2,$3,'teste contrato restrito','ti','selected',$4)`,
      [grantId, id1, accId, [c1]]
    );

    const allowed = await pool.query(`SELECT id FROM client_contracts WHERE client_account_id = $1 AND id = ANY($2)`, [accId, [c1]]);
    assert.equal(allowed.rows.length, 1);
    assert.equal(allowed.rows[0].id, c1);

    // Grant vazio selected deve negar todos
    await pool.query(`UPDATE client_access_grants SET allowed_contract_ids = '{}' WHERE id = $1`, [grantId]);
    const denied = await pool.query(`SELECT id FROM client_contracts WHERE client_account_id = $1 AND id = ANY($2)`, [accId, []]);
    assert.equal(denied.rows.length, 0);

    // Auditoria de negação
    await pool.query(`INSERT INTO auth_access_audit (actor_kind, actor_id, action, target, result, detail_category) VALUES ('client',$1,'contract_list',$2,'denied','authorization_denied')`, [id1, accId]);
    const audit = await pool.query(`SELECT * FROM auth_access_audit WHERE actor_id = $1 AND detail_category = 'authorization_denied'`, [id1]);
    assert.ok(audit.rows.length >= 1);
  });

  await t.test("vínculo por unidade não vaza entre unidades", async () => {
    const { randomUUID } = await import("node:crypto");
    const id = randomUUID();
    const email = `sec.unit.${runId}@exemplo.invalid`;
    const parentId = randomUUID();
    const childId = randomUUID();
    const otherId = randomUUID();
    const grantId = randomUUID();

    await pool.query(`INSERT INTO auth_identities (id, kind, email, status) VALUES ($1,'client',$2,'active')`, [id, email]);
    await pool.query(`INSERT INTO client_accounts (id, display_name, status, created_by) VALUES ($1,$2,'active','ti')`, [parentId, `Pai ${runId}`]);
    await pool.query(`INSERT INTO client_accounts (id, display_name, status, parent_account_id, created_by) VALUES ($1,$2,'active',$3,'ti')`, [childId, `Filha ${runId}`, parentId]);
    await pool.query(`INSERT INTO client_accounts (id, display_name, status, created_by) VALUES ($1,$2,'active','ti')`, [otherId, `Outra ${runId}`]);
    await pool.query(`INSERT INTO client_access_grants (id, identity_id, client_account_id, reason, granted_by, unit_account_id) VALUES ($1,$2,$3,'teste unidade','ti',$3)`, [grantId, id, parentId]);

    const pai = await pool.query(`SELECT id FROM client_accounts WHERE id = $1 AND (id = $2 OR parent_account_id = $2)`, [parentId, parentId]);
    assert.equal(pai.rows.length, 1);
    const filha = await pool.query(`SELECT id FROM client_accounts WHERE id = $1 AND (id = $2 OR parent_account_id = $2)`, [childId, parentId]);
    assert.equal(filha.rows.length, 1);
    const outra = await pool.query(`SELECT id FROM client_accounts WHERE id = $1 AND (id = $2 OR parent_account_id = $2)`, [otherId, parentId]);
    assert.equal(outra.rows.length, 0, "unidade separada não vaza");
  });

  await t.test("MFA bloqueia login sem código válido", async () => {
    const { randomUUID } = await import("node:crypto");
    const id = randomUUID();
    const email = `sec.mfa.${runId}@exemplo.invalid`;
    await pool.query(`INSERT INTO auth_identities (id, kind, email, status) VALUES ($1,'client',$2,'active')`, [id, email]);
    await pool.query(`INSERT INTO auth_mfa (identity_id, totp_secret_encrypted, recovery_hashes, activated_at) VALUES ($1,'JBSWY3DPEHPK3PXP','{}',NOW())`, [id]);
    const verify = await pool.query("SELECT * FROM auth_mfa WHERE identity_id = $1", [id]);
    assert.ok(verify.rows[0].activated_at);
    assert.ok(verify.rows[0].attempts_since_verified >= 0);
    // Simula falha de verificação incrementando tentativas
    await pool.query("UPDATE auth_mfa SET attempts_since_verified = attempts_since_verified + 1 WHERE identity_id = $1", [id]);
    const after = await pool.query("SELECT attempts_since_verified FROM auth_mfa WHERE identity_id = $1", [id]);
    assert.equal(after.rows[0].attempts_since_verified, 1);
  });

  await t.test("Não fui eu cancela troca e registra alerta", async () => {
    const { randomUUID } = await import("node:crypto");
    const id = randomUUID();
    const changeId = randomUUID();
    const email = `sec.email.${runId}@exemplo.invalid`;
    await pool.query(`INSERT INTO auth_identities (id, kind, email, status) VALUES ($1,'client',$2,'active')`, [id, email]);
    await pool.query(`INSERT INTO auth_email_change (id, identity_id, old_email, new_email, token_hash, expires_at) VALUES ($1,$2,$3,$4,$5,NOW()+INTERVAL '1 hour')`, [changeId, id, email, `novo.${runId}@exemplo.invalid`, `hash-${runId}`]);
    await pool.query(`UPDATE auth_email_change SET cancelled_at = NOW(), cancelled_by = 'security_alert', alert_generated_at = NOW() WHERE id = $1`, [changeId]);
    const ch = await pool.query("SELECT * FROM auth_email_change WHERE id = $1", [changeId]);
    assert.ok(ch.rows[0].cancelled_at);
    assert.equal(ch.rows[0].cancelled_by, "security_alert");
    assert.ok(ch.rows[0].alert_generated_at);
  });
});
