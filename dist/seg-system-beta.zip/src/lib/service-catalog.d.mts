export interface CatalogService {
  id: string;
  /** Nome exato aceito pela API em `public_leads.services`. */
  name: string;
  short: string;
  description: string;
  audience: string;
  questions: string[];
  /** Pergunta de qualificação; não descreve promessa de serviço. (compat) */
  question: string;
  isPublished: boolean;
  isValidated: boolean;
  validationNote?: string;
  // CRM-11
  serviceType?: "recorrente" | "avulso" | "instalacao" | "manutencao" | "venda" | "locacao" | "comodato" | "outro";
  billingUnit?: string;
  scope?: string;
  exclusions?: string;
  resources?: string;
  resourcesJson?: any[];
  validityDays?: number;
  approvalStatus?: "rascunho" | "em_revisao" | "aprovado" | "arquivado";
  isRecurring?: boolean;
  version?: number;
  cost?: number | null;
  price?: number | null;
  currency?: string;
}

export interface CatalogPropertyType {
  id: string;
  /** Nome exato aceito pela API em `public_leads.property_type`. */
  name: string;
  question: string;
  questions: string[];
}

export interface RequestSummaryInput {
  kind: "quote" | "visit";
  name: string;
  phone: string;
  city: string;
  propertyType: string;
  services: string[];
  visitPreference: string;
  details: string;
}

export declare const PUBLIC_SERVICES: readonly CatalogService[];
export declare const PROPERTY_TYPES: readonly CatalogPropertyType[];

export declare function isPublicService(value: unknown): value is string;
export declare function isPropertyType(value: unknown): value is string;
export declare function findService(value: string): CatalogService | null;
export declare function findPropertyType(value: string): CatalogPropertyType | null;
export declare function getPublishedServices(): CatalogService[];
export declare function getServiceById(id: string): CatalogService | null;
export declare function getServicesByType(serviceType: string): CatalogService[];
export declare function getRecurringServices(): CatalogService[];
export declare function getOneTimeServices(): CatalogService[];
export declare function buildRequestSummary(input: RequestSummaryInput): string[];
