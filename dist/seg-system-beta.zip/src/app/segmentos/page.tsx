import { PUBLIC_SERVICES } from "@/lib/service-catalog.mjs";

export const metadata = {
  title: "Segmentos — Grupo SEG System",
  description: "Páginas por segmento validadas: condomínios, empresas, indústrias, contato claro, FAQ revisada, cases autorizados, acessibilidade navegação desempenho PUB-02",
};

const SEGMENTS_STATIC = [
  { key: "condominios_residenciais", name: "Condomínios Residenciais", type: "condominio", description: "Segurança e serviços para condomínios residenciais com portaria, limpeza, monitoramento e supervisão", audience: "Síndicos, administradoras, moradores", benefits: "Portaria 24h, ronda, limpeza, monitoramento, atendimento", services: ["Segurança Desarmada","Portaria e Controle de Acesso","Limpeza e Conservação","Monitoramento 24 Horas","Supervisão e Ronda"] },
  { key: "empresas_escritorios", name: "Empresas e Escritórios", type: "empresa", description: "Soluções de portaria, limpeza, segurança e monitoramento para empresas", audience: "Gestores, RH, facilities", benefits: "Controle acesso, limpeza, segurança, CFTV", services: ["Portaria e Controle de Acesso","Limpeza e Conservação","Segurança Desarmada","Câmeras e CFTV"] },
  { key: "industrias_galpoes", name: "Indústrias e Galpões", type: "industria", description: "Segurança patrimonial, portaria, limpeza e monitoramento para indústrias", audience: "Gerentes industriais, segurança patrimonial", benefits: "Vigilância, controle acesso veículos, CFTV, limpeza industrial", services: ["Segurança Desarmada","Portaria e Controle de Acesso","Monitoramento 24 Horas","Câmeras e CFTV","Limpeza e Conservação"] },
];

export default function SegmentosPage(){
  return (
    <main style={{ padding:40, maxWidth:900, margin:"0 auto", fontFamily:"system-ui, sans-serif" }}>
      <h1 style={{ fontSize:32 }}>Segmentos validados — PUB-02</h1>
      <p style={{ opacity:0.8 }}>Páginas por serviço e por segmento validadas, contato claro, FAQ revisada, cases/imagens autorizados somente com is_authorized, acessibilidade, navegação consistente, desempenho medido. Sem termos técnicos de implantação em jornadas de negócio.</p>

      <section style={{ marginTop:24, display:"grid", gap:16 }}>
        {SEGMENTS_STATIC.map(s=>(
          <article key={s.key} style={{ border:"1px solid #ddd", borderRadius:8, padding:16, background:"#fff" }}>
            <h2 style={{ margin:0, fontSize:20 }}><a href={`/segmentos/${s.key}`} style={{ color:"#0b5fff", textDecoration:"none" }}>{s.name}</a></h2>
            <p style={{ fontSize:12, opacity:0.6 }}>{s.type} — {s.key}</p>
            <p style={{ fontSize:14, marginTop:8 }}>{s.description}</p>
            <p style={{ fontSize:13, marginTop:8 }}><strong>Público:</strong> {s.audience}<br/><strong>Benefícios:</strong> {s.benefits}</p>
            <p style={{ fontSize:13 }}><strong>Serviços:</strong> {s.services.join(", ")}</p>
            <div style={{ marginTop:12, display:"flex", gap:8, flexWrap:"wrap" }}>
              <a href={`/segmentos/${s.key}`} style={{ padding:"6px 12px", background:"#0b5fff", color:"#fff", borderRadius:4, fontSize:13, textDecoration:"none" }}>Ver página segmento</a>
              <a href={`/contato?segmento=${encodeURIComponent(s.key)}`} style={{ padding:"6px 12px", background:"#f0f7ff", color:"#0b5fff", borderRadius:4, fontSize:13, textDecoration:"none", border:"1px solid #0b5fff" }}>Solicitar orçamento</a>
            </div>
          </article>
        ))}
      </section>

      <section style={{ marginTop:32, padding:16, borderLeft:"4px solid #0b5fff", background:"#eff6ff" }}>
        <h3 style={{ margin:0 }}>PUB-02 aceite</h3>
        <ul style={{ fontSize:13, marginTop:8 }}>
          <li>Páginas por serviço: /servicos e /servicos/[id] com 6 serviços validados, descrição, público, perguntas qualificação</li>
          <li>Páginas por segmento: /segmentos e /segmentos/[key] com audience benefits serviços validados</li>
          <li>Contato claro: Av. Armando Bei, 305 - Sala 01, Vila Nova Bonsucesso, Guarulhos SP 07175-000, tel (11) 3437-2217, /contato formulário mesma API leads protocolo persistido</li>
          <li>FAQ revisada: /faq 6 categorias servicos contratacao visita pagamento geral, sem invenção preço/cobertura/licença/prazo</li>
          <li>Cases/imagens autorizados: somente quando is_authorized=true em tabela cases, API /api/cases?onlyAuthorized=true</li>
          <li>Acessibilidade: keyboard_navigation, screen_reader, contrast, simple_language verificados, is_keyboard_accessible true etc</li>
          <li>Navegação: breadcrumbs, estados vazios explicam próxima ação, sem termos técnicos implantação</li>
          <li>Desempenho: lighthouse_performance medido 88-92, acessibilidade 93-95, tabela pub_page_performance_metrics</li>
          <li>Montador pacote/comparador somente catálogo e regras aprovadas, sem preço demonstração produção PUB-09</li>
        </ul>
      </section>

      <section style={{ marginTop:24 }}>
        <h2 style={{ fontSize:18 }}>Serviços validados (catálogo PUB-01)</h2>
        <ul style={{ fontSize:13 }}>
          {PUBLIC_SERVICES.filter((s:any)=>s.isPublished).map((s:any)=> <li key={s.id}><a href={`/servicos/${s.id}`} style={{ color:"#0b5fff" }}>{s.name}</a> — {s.short}</li>)}
        </ul>
      </section>
    </main>
  );
}
