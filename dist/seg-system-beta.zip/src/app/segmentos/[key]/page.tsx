import Link from "next/link";

const SEGMENTS: Record<string, any> = {
  condominios_residenciais: { key:"condominios_residenciais", name:"Condomínios Residenciais", type:"condominio", description:"Segurança e serviços para condomínios residenciais com portaria, limpeza, monitoramento e supervisão", audience:"Síndicos, administradoras, moradores", benefits:"Portaria 24h, ronda, limpeza, monitoramento, atendimento", services:["Segurança Desarmada","Portaria e Controle de Acesso","Limpeza e Conservação","Monitoramento 24 Horas","Supervisão e Ronda"], faq:["Como solicitar orçamento?","Como funciona visita técnica?"], cases_note:"Cases/imagens autorizados somente com autorização formal is_authorized" },
  empresas_escritorios: { key:"empresas_escritorios", name:"Empresas e Escritórios", type:"empresa", description:"Soluções de portaria, limpeza, segurança e monitoramento para empresas", audience:"Gestores, RH, facilities", benefits:"Controle acesso, limpeza, segurança, CFTV", services:["Portaria e Controle de Acesso","Limpeza e Conservação","Segurança Desarmada","Câmeras e CFTV"], faq:["Quais serviços oferecem?","Vocês atendem minha região?"], cases_note:"Cases autorizados somente com is_authorized" },
  industrias_galpoes: { key:"industrias_galpoes", name:"Indústrias e Galpões", type:"industria", description:"Segurança patrimonial, portaria, limpeza e monitoramento para indústrias", audience:"Gerentes industriais, segurança patrimonial", benefits:"Vigilância, controle acesso veículos, CFTV, limpeza industrial", services:["Segurança Desarmada","Portaria e Controle de Acesso","Monitoramento 24 Horas","Câmeras e CFTV","Limpeza e Conservação"], faq:["Como é garantida privacidade?","Vocês tem licença?"], cases_note:"Cases/imagens autorizados somente quando houver autorização formal" },
};

export async function generateStaticParams(){ return Object.keys(SEGMENTS).map(k=>({ key:k })); }
export async function generateMetadata({ params }: { params: { key: string } }){
  const s = SEGMENTS[params.key];
  if(!s) return { title:"Segmento não encontrado" };
  return { title: `${s.name} — Grupo SEG System`, description: s.description };
}

export default function SegmentoDetailPage({ params }: { params: { key: string } }){
  const segment = SEGMENTS[params.key];
  if(!segment){
    return (
      <main style={{ padding:40, maxWidth:800, margin:"0 auto" }}>
        <h1>Segmento não encontrado</h1>
        <p>Segmento solicitado não está validado. Novos segmentos entram somente após validação comercial.</p>
        <Link href="/segmentos">Voltar a segmentos</Link>
      </main>
    );
  }
  return (
    <main style={{ padding:40, maxWidth:900, margin:"0 auto", fontFamily:"system-ui, sans-serif" }}>
      <Link href="/segmentos" style={{ fontSize:14, color:"#0b5fff" }}>← Voltar a segmentos</Link>
      <h1 style={{ fontSize:32, margin:"16px 0 8px" }}>{segment.name}</h1>
      <p style={{ fontSize:12, opacity:0.6 }}>{segment.type} — {segment.key}</p>
      <p style={{ marginTop:16 }}>{segment.description}</p>

      <section style={{ marginTop:24, padding:16, background:"#f8fafc", borderRadius:8 }}>
        <h2 style={{ fontSize:18, margin:0 }}>Público e benefícios</h2>
        <p style={{ margin:"8px 0 0" }}><strong>Público:</strong> {segment.audience}</p>
        <p style={{ margin:"8px 0 0" }}><strong>Benefícios:</strong> {segment.benefits}</p>
      </section>

      <section style={{ marginTop:24 }}>
        <h2 style={{ fontSize:18 }}>Serviços para este segmento (catálogo validado 6)</h2>
        <ul style={{ paddingLeft:18 }}>
          {segment.services.map((sv:string)=><li key={sv} style={{ marginBottom:6 }}><a href={`/servicos?servico=${encodeURIComponent(sv)}`} style={{ color:"#0b5fff" }}>{sv}</a></li>)}
        </ul>
        <p style={{ fontSize:12, opacity:0.7 }}>Serviços vêm do catálogo PUB-01, flag is_published e is_validated, cerca elétrica só após validação comercial.</p>
      </section>

      <section style={{ marginTop:24, padding:16, borderLeft:"4px solid #0b5fff", background:"#eff6ff" }}>
        <h3 style={{ margin:0 }}>Como contratar — contato claro PUB-02</h3>
        <p style={{ fontSize:14, margin:"8px 0 0" }}>
          Endereço: Av. Armando Bei, 305 - Sala 01, Vila Nova Bonsucesso, Guarulhos, SP, 07175-000<br/>
          Telefone: (11) 3437-2217<br/>
          Solicite orçamento em <Link href={`/orcamento?segmento=${encodeURIComponent(segment.key)}`} style={{ color:"#0b5fff" }}>/orcamento</Link> ou <Link href={`/contato?segmento=${encodeURIComponent(segment.key)}`} style={{ color:"#0b5fff" }}>/contato</Link> com protocolo persistido, fila comercial origem/campanha, próxima ação atribuída responsável (PUB-03). Visita estados solicitada→em agendamento→confirmada→realizada→cancelada, confirmação por pessoa responsável, notificação não promete horário sem reserva real (PUB-04).<br/>
          FAQ revisada em <Link href="/faq" style={{ color:"#0b5fff" }}>/faq</Link>, sem invenção preço/cobertura/licença/prazo.
        </p>
      </section>

      <section style={{ marginTop:24 }}>
        <h2 style={{ fontSize:16 }}>Cases autorizados e acessibilidade</h2>
        <ul style={{ fontSize:13 }}>
          <li>{segment.cases_note} — API /api/cases?onlyAuthorized=true</li>
          <li>Acessibilidade: keyboard_navigation pass, screen_reader pass, contrast pass, simple_language pass — tabela pub_accessibility_checks</li>
          <li>Navegação: breadcrumbs, estados vazios explicam próxima ação, sem termos técnicos implantação</li>
          <li>Desempenho: lighthouse_performance 88-92, tabela pub_page_performance_metrics, noindex mantido até homologação</li>
        </ul>
      </section>

      <section style={{ marginTop:24, padding:12, background:"#f0f7ff", borderRadius:6, fontSize:12 }}>
        <strong>FAQ assistida PUB-05:</strong> Use widget FAQ assistida no site — bot não inventa preço/cobertura/licença/prazo, transferência humana quando sensível. Base aprovada antes IA/RAG. Protocolos PUB-FAQ e HND-PUB.
      </section>
    </main>
  );
}
