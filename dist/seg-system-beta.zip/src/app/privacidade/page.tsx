"use client";
import { useEffect, useState } from "react";

export default function PrivacidadePage() {
  const [inventory, setInventory] = useState<any[]>([]);
  const [policy, setPolicy] = useState<any>(null);

  useEffect(() => {
    fetch('/api/privacy/policies?published=true').then(r => r.json()).then(j => {
      if (j.policies && j.policies.length > 0) setPolicy(j.policies[0]);
    }).catch(() => {});
    fetch('/api/privacy/inventory').then(r => r.json()).then(j => {
      if (j.inventory) setInventory(j.inventory);
    }).catch(() => {});
  }, []);

  return (
    <main style={{ padding: 40, maxWidth: 860, margin: "0 auto", fontFamily: "system-ui, sans-serif", color: "#1a1a2e", background: "#fff" }}>
      <div style={{ borderLeft: "4px solid #d97706", background: "#fef3c7", padding: "12px 16px", marginBottom: 24, borderRadius: 6 }}>
        <strong style={{ color: "#92400e" }}>{policy?.is_published ? `Política publicada v${policy.version} em ${policy.published_at?.slice(0,10)}` : "Aviso — Minuta pendente de aprovação formal"}</strong>
        <p style={{ margin: "8px 0 0", color: "#78350f", fontSize: 14 }}>
          {policy?.is_published ? "Esta política foi aprovada por revisão competente (admin) e publicada. Noindex removido em produção após homologação." : "Este texto é uma minuta técnica para revisão interna. Não constitui política oficial publicada. Enquanto faltar aprovação do responsável por privacidade/Marcelo, o site permanece com noindex e sem coleta real além do necessário para orçamento/simulador. Nenhuma declaração de conformidade deve ser considerada definitiva."}
        </p>
      </div>
      <h1>Política de Privacidade — {policy?.is_published ? `v${policy.version} publicada` : "Minuta (não aprovada)"}</h1>
      <p><em>Estado: {policy?.status || "rascunho"} {policy?.approved_by ? `aprovado por ${policy.approved_by} em ${policy.approved_at?.slice(0,10)}` : "pendente de aprovação formal"} em {new Date().toISOString().slice(0,10)}.</em></p>
      {policy && (
        <div style={{ background: '#f9fafb', padding: 12, borderRadius: 8, marginBottom: 16, fontSize: 13 }}>
          <div><strong>Título:</strong> {policy.title}</div>
          <div style={{ whiteSpace: 'pre-wrap', marginTop: 8 }}>{policy.content}</div>
          <div style={{ marginTop: 8 }}><strong>Contato:</strong> {policy.contact_email} • <strong>DPO:</strong> {policy.dpo_name} {policy.dpo_contact}</div>
          <div><strong>Retenção:</strong> {policy.retention_summary}</div>
          <div><strong>Direitos:</strong> {policy.rights_description}</div>
          <div><strong>Destinatários:</strong> {policy.recipients_description}</div>
        </div>
      )}
      <h2>1. Base legal e finalidade</h2>
      <p>Tratamento de dados para atendimento a pedidos de orçamento/visita, execução de contrato, cumprimento legal e legítimo interesse, conforme LGPD. Coleta minimizada: nome, telefone, cidade/bairro, tipo de local, serviços de interesse, preferência de visita, detalhes opcionais, consentimento.</p>
      <h2>2. Inventário de dados, finalidades, bases, destinatários e prazos (PLT-09)</h2>
      <p style={{ fontSize: 12, color: '#6b7280' }}>Inventário completo com categoria, campo, descrição, finalidade, base legal, detalhe base, retenção dias + descrição, destinatários, sensível, obrigatório, fonte. Minimização e sem segredos.</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8 }}>
        {inventory.map((it: any) => (
          <div key={it.id} style={{ padding: 8, border: '1px solid #e5e7eb', borderRadius: 6, fontSize: 12, background: it.is_sensitive ? '#fef2f2' : '#fff' }}>
            <div style={{ fontWeight: 600 }}>{it.data_category} • {it.data_field} {it.is_sensitive ? '(sensível)' : ''}</div>
            <div>{it.description} — <em>Finalidade:</em> {it.purpose}</div>
            <div style={{ color: '#6b7280' }}>Base: {it.legal_basis} {it.legal_basis_detail ? `(${it.legal_basis_detail})` : ''} • Ret: {it.retention_days}d {it.retention_description || ''} • Dest: {it.recipients?.join(', ') || '—'} • Fonte: {it.source || '—'}</div>
          </div>
        ))}
      </div>
      <h2>3. Retenção</h2>
      <ul>
        <li>Auditoria de acesso: 12 meses, sem segredos, em <code>auth_access_audit</code>.</li>
        <li>Leads: até conversão/descarte, com deduplicação controlada e responsável de atendimento.</li>
        <li>Documentos e chamados: vinculados a conta/unidade/contrato/classificação, acesso restrito.</li>
        <li>CFTV e geolocalização (quando aplicável): dado sensível, retenção 30d CFTV / 90d geo salvo incidente, opcional por padrão, conforme inventário.</li>
        <li>Backups: 90d banco/full, 365d documentos, criptografados AES-256-GCM, restauração testada isolado.</li>
      </ul>
      <h2>4. Encarregado e direitos do titular</h2>
      <p>Encarregado a definir (D-11) — {policy?.dpo_name || "pendente"}. Direitos: confirmação, acesso, correção, anonimização, eliminação, portabilidade, revogação de consentimento, oposição, revisão decisão automatizada. Canal: {policy?.contact_email || "contato@gruposegsystemseguranca.com.br"} (pendente confirmação). Prazo resposta até 15 dias.</p>
      <h2>5. Compartilhamento e segurança</h2>
      <p>Sem compartilhamento indiscriminado. Destinatários: equipe comercial, operacional, TI, financeiro, segurança, marketing, provedores e-mail/storage quando configurados. Acesso por RBAC granular (PLT-01), sessão HttpOnly SameSite Lax Secure em produção, CSRF via mesma origem, auditoria durável. Tokens e segredos TOTP cifrados, códigos de recuperação apenas como hash. Backups criptografados, restauração testada isolado. Observabilidade com correlação request/event ID sem segredos.</p>
      <h2>6. Consentimento e aviso</h2>
      <p>Orçamento/simulador exigem consentimento explícito. Aviso pertinente exibido. Origem/campanha e antispam com rate limit IP. Templates notificação sem info médica em assunto/push (PLT-05).</p>
      <h2>7. Próximos passos para aprovação</h2>
      <ul>
        <li>Revisar com responsável LGPD/Marcelo, definir CNPJ, contatos oficiais, marca.</li>
        <li>Validar prazos de retenção de CFTV, geo e documentos trabalhistas (D-07).</li>
        <li>Publicar versão aprovada somente após homologação e remoção de noindex em produção — status aprovado por admin antes de publicado (PLT-09).</li>
      </ul>
      <p style={{ fontSize: 12, opacity: 0.7, marginTop: 32 }}>Documento gerado em {new Date().toISOString()} — {policy?.is_published ? "política oficial publicada" : "minuta técnica, não oficial, noindex mantido"}.</p>
    </main>
  );
}
