import { PUBLIC_SERVICES } from "@/lib/service-catalog.mjs";
import Link from "next/link";

export async function generateStaticParams() {
  return PUBLIC_SERVICES.filter((s:any) => s.isPublished).map((s:any) => ({ id: s.id }));
}

export async function generateMetadata({ params }: { params: { id: string } }) {
  const service = PUBLIC_SERVICES.find((s:any) => s.id === params.id);
  if (!service) return { title: "Serviço não encontrado" };
  return {
    title: `${service.name} — Grupo SEG System`,
    description: service.description,
  };
}

export default function ServicoDetailPage({ params }: { params: { id: string } }) {
  const service = PUBLIC_SERVICES.find((s:any) => s.id === params.id);

  if (!service) {
    return (
      <main style={{ padding: 40, maxWidth: 800, margin: "0 auto" }}>
        <h1>Serviço não encontrado</h1>
        <p>O serviço solicitado não está no catálogo validado. Cerca elétrica ou novos serviços entram somente após validação comercial.</p>
        <Link href="/servicos">Voltar ao catálogo</Link>
      </main>
    );
  }

  return (
    <main style={{ padding: 40, maxWidth: 900, margin: "0 auto", fontFamily: "system-ui, sans-serif" }}>
      <Link href="/servicos" style={{ fontSize: 14, color: "#0b5fff" }}>← Voltar ao catálogo</Link>
      <h1 style={{ fontSize: 32, margin: "16px 0 8px" }}>{service.name}</h1>
      <p style={{ fontSize: 16, opacity: 0.9 }}><strong>{service.short}</strong></p>
      <p style={{ marginTop: 16 }}>{service.description}</p>

      <section style={{ marginTop: 24, padding: 16, background: "#f8fafc", borderRadius: 8 }}>
        <h2 style={{ fontSize: 18, margin: 0 }}>Público</h2>
        <p style={{ margin: "8px 0 0" }}>{service.audience}</p>
      </section>

      <section style={{ marginTop: 24 }}>
        <h2 style={{ fontSize: 18 }}>Perguntas de qualificação</h2>
        <ul style={{ paddingLeft: 18 }}>
          {service.questions.map((q:string, i:number) => <li key={i} style={{ marginBottom: 6 }}>{q}</li>)}
        </ul>
        <p style={{ fontSize: 12, opacity: 0.7 }}>Estas perguntas são usadas no orçamento/simulador para qualificar a necessidade sem prometer preço, cobertura, licença ou prazo.</p>
      </section>

      <section style={{ marginTop: 24, padding: 16, borderLeft: "4px solid #0b5fff", background: "#eff6ff" }}>
        <h3 style={{ margin: 0 }}>Como contratar</h3>
        <p style={{ fontSize: 14, margin: "8px 0 0" }}>
          Solicite orçamento em <Link href={`/orcamento?servico=${encodeURIComponent(service.name)}`} style={{ color: "#0b5fff" }}>/orcamento</Link> ou simule visita em <Link href={`/simulador?servico=${encodeURIComponent(service.name)}`} style={{ color: "#0b5fff" }}>/simulador</Link>.
          O pedido gera protocolo persistido, entra na fila comercial com origem/campanha, próxima ação atribuída a responsável (PUB-03). Visita com estados solicitada → em agendamento → confirmada → realizada → cancelada, confirmação por pessoa responsável, notificação não promete horário sem reserva real (PUB-04).
        </p>
      </section>

      <section style={{ marginTop: 24 }}>
        <h2 style={{ fontSize: 16 }}>Informações adicionais</h2>
        <ul style={{ fontSize: 13 }}>
          <li>ID: {service.id}</li>
          <li>Publicado: {service.isPublished ? "sim" : "não"}</li>
          <li>Validado: {service.isValidated ? "sim" : "não"}</li>
          <li>Nota validação: {service.validationNote}</li>
        </ul>
      </section>
    </main>
  );
}
