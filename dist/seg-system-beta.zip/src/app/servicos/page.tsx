import { PUBLIC_SERVICES } from "@/lib/service-catalog.mjs";

export const metadata = {
  title: "Serviços — Grupo SEG System",
  description: "Catálogo único dos seis serviços validados: segurança desarmada, monitoramento 24h, CFTV, portaria, limpeza, supervisão. Cada serviço com descrição, público, perguntas de qualificação, tipo recorrente/instalação/manutenção/locação, unidade cobrança, escopo, exclusões, recursos, vigência e aprovação (CRM-11).",
};

export default function ServicosPage() {
  const services = PUBLIC_SERVICES.filter((s:any) => s.isPublished !== false && s.isValidated !== false);

  return (
    <main style={{ padding: 40, maxWidth: 1100, margin: "0 auto", fontFamily: "system-ui, sans-serif" }}>
      <h1 style={{ fontSize: 32, marginBottom: 8 }}>Nossos serviços — catálogo validado (PUB-01 + CRM-11)</h1>
      <p style={{ opacity: 0.8, marginBottom: 24 }}>
        Catálogo único dos seis serviços validados no projeto. Cada item tem descrição, público, perguntas de qualificação, flag de publicação e classificação CRM-11: tipo (recorrente/avulso/instalação/manutenção/venda/locação/comodato), unidade de cobrança, escopo, exclusões, recursos, custo, preço, vigência e aprovação.
        Cerca elétrica ou novos serviços entram somente após validação comercial (D-02). Fonte: <code>service_catalog</code> (DB) com fallback arquivo.
      </p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 16 }}>
        {services.map((s:any) => (
          <article key={s.id} style={{ border: "1px solid #ddd", borderRadius: 8, padding: 16, background: "#fff" }}>
            <h2 style={{ margin: "0 0 8px", fontSize: 18 }}>{s.name} <span style={{ fontSize: 10, padding: "2px 6px", borderRadius: 4, background: "#e0e7ff" }}>{s.serviceType || "recorrente"}</span> <span style={{ fontSize: 10, padding: "2px 6px", borderRadius: 4, background: s.isRecurring ? "#dcfce7" : "#fef9c3" }}>{s.isRecurring ? "recorrente" : "avulso"}</span></h2>
            <p style={{ margin: 0, fontSize: 12, opacity: 0.7 }}><strong>Unidade cobrança:</strong> {s.billingUnit || "-"} | <strong>Vigência:</strong> {s.validityDays ? `${s.validityDays} dias` : "-"} | <strong>Aprovação:</strong> {s.approvalStatus || "aprovado"} | <strong>Versão:</strong> {s.version || 1}</p>
            <p style={{ margin: "8px 0 0", fontSize: 14, opacity: 0.9 }}><strong>Resumo:</strong> {s.short}</p>
            <p style={{ margin: "8px 0 0", fontSize: 13 }}><strong>Descrição:</strong> {s.description}</p>
            <p style={{ margin: "8px 0 0", fontSize: 13 }}><strong>Público:</strong> {s.audience}</p>
            <p style={{ margin: "8px 0 0", fontSize: 12 }}><strong>Escopo:</strong> {s.scope || "-"}</p>
            <p style={{ margin: "4px 0 0", fontSize: 12 }}><strong>Exclusões:</strong> {s.exclusions || "-"}</p>
            <p style={{ margin: "4px 0 0", fontSize: 12 }}><strong>Recursos:</strong> {s.resources || "-"}</p>
            <div style={{ marginTop: 8 }}>
              <strong style={{ fontSize: 12 }}>Perguntas de qualificação:</strong>
              <ul style={{ margin: "4px 0 0", paddingLeft: 18, fontSize: 12 }}>
                {s.questions.map((q:string, i:number) => <li key={i}>{q}</li>)}
              </ul>
            </div>
            <div style={{ marginTop: 12, display: "flex", gap: 8 }}>
              <a href={`/orcamento?servico=${encodeURIComponent(s.name)}`} style={{ padding: "6px 12px", background: "#0b5fff", color: "#fff", borderRadius: 6, textDecoration: "none", fontSize: 13 }}>Solicitar orçamento</a>
              <a href={`/simulador?servico=${encodeURIComponent(s.name)}`} style={{ padding: "6px 12px", border: "1px solid #0b5fff", color: "#0b5fff", borderRadius: 6, textDecoration: "none", fontSize: 13 }}>Simular visita</a>
            </div>
            <p style={{ margin: "8px 0 0", fontSize: 10, opacity: 0.6 }}>ID: {s.id} | Publicado: {s.isPublished ? "sim" : "não"} | Validado: {s.isValidated ? "sim" : "não"} | Tipo: {s.serviceType} | Unidade: {s.billingUnit}</p>
          </article>
        ))}
      </div>
      <section style={{ marginTop: 32, padding: 16, borderLeft: "4px solid #0b5fff", background: "#f0f7ff" }}>
        <h3 style={{ margin: 0 }}>Como pedir orçamento (PUB-03 + CRM-11) + PUB-02 páginas por segmento</h3>
        <p style={{ fontSize: 14, margin: "8px 0 0" }}>
          Escolha um ou mais serviços, informe tipo de imóvel (condomínio, empresa, indústria, instituição, outro) e detalhes. O pedido é integrado à mesma API de leads com protocolo persistido, consentimento obrigatório, origem/campanha e antispam (PUB-03). Serviços separados por tipo recorrente/avulso/instalação/manutenção/venda/locação/comodato (CRM-11) com unidade de cobrança, escopo, exclusões, recursos, vigência e aprovação. Visita com estados solicitada → em agendamento → confirmada → realizada → cancelada (PUB-04) depende de confirmação humana.<br/>
          Páginas por segmento: <a href="/segmentos" style={{ color:"#0b5fff" }}>/segmentos</a> — condomínios, empresas, indústrias com audience benefits validados, contato claro, FAQ revisada, cases autorizados is_authorized, acessibilidade keyboard/screen_reader/contrast/simple_language, navegação breadcrumbs, desempenho lighthouse medido (PUB-02).<br/>
          FAQ assistida: <a href="/faq" style={{ color:"#0b5fff" }}>/faq</a> com widget PUB-05 bot não inventa preço/cobertura/licença/prazo, transferência humana protocolo HND-PUB.
        </p>
      </section>
    </main>
  );
}
