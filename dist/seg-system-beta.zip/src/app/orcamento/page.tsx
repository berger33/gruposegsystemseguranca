"use client";

import { useState } from "react";
import Link from "next/link";
import { PUBLIC_SERVICES, PROPERTY_TYPES, buildRequestSummary } from "@/lib/service-catalog.mjs";

type Kind = "quote" | "visit";

export default function OrcamentoPage() {
  const [propertyType, setPropertyType] = useState("");
  const [services, setServices] = useState<string[]>([]);
  const [kind, setKind] = useState<Kind>("quote");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState("");
  const [visitPreference, setVisitPreference] = useState("");
  const [details, setDetails] = useState("");
  const [consent, setConsent] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState<{ id: string; whatsapp: string } | null>(null);

  const WHATSAPP = "551134372217";

  function toggleService(name: string) {
    setServices((prev) => (prev.includes(name) ? prev.filter((x) => x !== name) : [...prev, name]));
    setError("");
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return;
    setError("");
    if (!propertyType) {
      setError("Selecione o tipo de imóvel.");
      return;
    }
    if (name.trim().length < 2) {
      setError("Informe seu nome.");
      return;
    }
    if (phone.replace(/\D/g, "").length < 8) {
      setError("Informe um telefone com DDD.");
      return;
    }
    if (city.trim().length < 2) {
      setError("Informe a cidade ou bairro.");
      return;
    }
    if (kind === "visit" && visitPreference.trim().length < 2) {
      setError("Informe preferência de visita.");
      return;
    }
    if (!consent) {
      setError("É preciso autorizar o registro dos dados.");
      return;
    }

    setSubmitting(true);
    try {
      const summary = buildRequestSummary({ kind, name, phone, city, propertyType, services, visitPreference, details });
      const response = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          requestKind: kind,
          name: name.trim(),
          phone: phone.trim(),
          city: city.trim(),
          propertyType,
          services,
          visitPreference: kind === "visit" ? visitPreference.trim() : "",
          details: details.trim(),
          consent,
          website: "",
        }),
      });
      const result = await response.json().catch(() => ({}));
      if (!response.ok || !result.recorded) {
        setError(result.error === "too_many_attempts" ? "Muitas tentativas. Aguarde alguns minutos." : "Não foi possível registrar. Tente novamente.");
        return;
      }
      setDone({
        id: result.leadId || "registrado",
        whatsapp: `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(summary.join("\n"))}`,
      });
    } catch {
      setError("Falha de conexão. Tente novamente.");
    } finally {
      setSubmitting(false);
    }
  }

  if (done) {
    return (
      <main style={{ padding: 32, maxWidth: 800, margin: "0 auto", fontFamily: "system-ui, sans-serif" }}>
        <h1>Solicitação registrada</h1>
        <p>Protocolo: {done.id.slice(0, 8)} — entrou na fila da equipe em /admin/leads. Visita ainda depende de confirmação humana.</p>
        <div style={{ marginTop: 16, display: "flex", gap: 12 }}>
          <a href={done.whatsapp} target="_blank" rel="noopener noreferrer" style={{ padding: "10px 16px", background: "#25D366", color: "#fff", borderRadius: 6, textDecoration: "none" }}>Continuar no WhatsApp</a>
          <Link href="/simulador" style={{ padding: "10px 16px", border: "1px solid currentColor", borderRadius: 6, textDecoration: "none" }}>Abrir simulador completo</Link>
        </div>
        <p style={{ marginTop: 16, fontSize: 12, opacity: 0.7 }}>Nenhum preço foi exibido — proposta depende de vistoria e parâmetros aprovados. Dados registrados em PostgreSQL quando configurado.</p>
      </main>
    );
  }

  return (
    <main style={{ padding: 32, maxWidth: 900, margin: "0 auto", fontFamily: "system-ui, sans-serif" }}>
      <h1>Solicitar orçamento — Grupo SEG System</h1>
      <p>Fluxo integrado à mesma API do simulador. Sem exibição de preço ilustrativo. Registro só é confirmado após persistência no servidor.</p>

      <form onSubmit={submit} style={{ display: "grid", gap: 16, marginTop: 24 }}>
        <fieldset>
          <legend>Tipo de imóvel *</legend>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {PROPERTY_TYPES.map((p) => (
              <button key={p.name} type="button" onClick={() => setPropertyType(p.name)} style={{ padding: "8px 12px", border: propertyType === p.name ? "2px solid #0b5fff" : "1px solid #ccc", borderRadius: 6, background: propertyType === p.name ? "#eef3ff" : "#fff" }}>{p.name}</button>
            ))}
          </div>
        </fieldset>

        <fieldset>
          <legend>Serviços de interesse</legend>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {PUBLIC_SERVICES.map((s) => (
              <button key={s.name} type="button" onClick={() => toggleService(s.name)} style={{ padding: "8px 12px", border: services.includes(s.name) ? "2px solid #0b5fff" : "1px solid #ccc", borderRadius: 6, background: services.includes(s.name) ? "#eef3ff" : "#fff" }}>{s.name}</button>
            ))}
          </div>
          <small style={{ opacity: 0.7 }}>Catálogo único de 6 serviços validados. Nenhum preço exibido aqui.</small>
        </fieldset>

        <div style={{ display: "flex", gap: 8 }}>
          <button type="button" onClick={() => setKind("quote")} style={{ padding: "8px 12px", border: kind === "quote" ? "2px solid #0b5fff" : "1px solid #ccc", borderRadius: 6, background: kind === "quote" ? "#eef3ff" : "#fff" }}>Quero orçamento</button>
          <button type="button" onClick={() => setKind("visit")} style={{ padding: "8px 12px", border: kind === "visit" ? "2px solid #0b5fff" : "1px solid #ccc", borderRadius: 6, background: kind === "visit" ? "#eef3ff" : "#fff" }}>Quero visita técnica</button>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
          <label>Nome *<br /><input value={name} onChange={(e) => setName(e.target.value)} maxLength={100} required style={{ width: "100%", padding: 8, border: "1px solid #ccc", borderRadius: 6 }} /></label>
          <label>Telefone *<br /><input value={phone} onChange={(e) => setPhone(e.target.value)} maxLength={30} required style={{ width: "100%", padding: 8, border: "1px solid #ccc", borderRadius: 6 }} /></label>
          <label>Cidade/bairro *<br /><input value={city} onChange={(e) => setCity(e.target.value)} maxLength={100} required style={{ width: "100%", padding: 8, border: "1px solid #ccc", borderRadius: 6 }} /></label>
          {kind === "visit" && <label>Preferência visita *<br /><input value={visitPreference} onChange={(e) => setVisitPreference(e.target.value)} maxLength={120} required style={{ width: "100%", padding: 8, border: "1px solid #ccc", borderRadius: 6 }} /></label>}
        </div>

        <label>Detalhes (opcional)<br /><textarea value={details} onChange={(e) => setDetails(e.target.value)} maxLength={1000} rows={3} style={{ width: "100%", padding: 8, border: "1px solid #ccc", borderRadius: 6 }} /></label>

        <label style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
          <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} required />
          <span>Autorizo o registro destes dados para resposta ao pedido. Visita só é confirmada por pessoa da equipe.</span>
        </label>

        {error && <p style={{ color: "red" }}>{error}</p>}

        <button type="submit" disabled={submitting} style={{ padding: "12px 20px", background: "#0b5fff", color: "#fff", border: "none", borderRadius: 6, cursor: "pointer" }}>{submitting ? "Registrando..." : "Registrar solicitação"}</button>

        <p style={{ fontSize: 12, opacity: 0.6 }}>Este formulário usa a mesma API de /simulador. Sem SMTP, gravação continua independente. Sem preço fictício. Protocolo persistido com trilha de auditoria.</p>
      </form>
    </main>
  );
}
