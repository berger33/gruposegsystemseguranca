"use client";
import { THEMES } from "../../../lib/themes.mjs";

type Theme = { id: string; name: string; desc: string };

export default function AdminTemaPage() {
  return (
    <main style={{ padding: 24, fontFamily: "system-ui, sans-serif", color: "var(--theme-fg)", background: "var(--theme-bg)" }}>
      <div style={{ borderLeft: "4px solid #d97706", background: "#fef3c7", padding: "12px 16px", marginBottom: 16, borderRadius: 6, color: "#78350f" }}>
        <strong>Prévia local — sem persistência global</strong>
        <p style={{ margin: "6px 0 0", fontSize: 13 }}>
          Este painel é uma prévia estática. O botão &quot;Pré-visualizar&quot; altera apenas o tema no seu navegador (documentElement). Nenhuma alteração é salva no banco, nenhum cliente vê a mudança, nenhum e-mail é enviado. Publicação autorizada, configuração persistida e rollback (PUB-07) ainda não implementados.
        </p>
      </div>
      <h1 style={{ fontFamily: "var(--theme-font)" }}>Painel do tema — Camada 3 / 4 (prévia)</h1>
      <p style={{ opacity: 0.8 }}>Apenas Marcelo (admin) ou administrador de sistema/TI poderá alterar quando implementado. Nenhuma mudança afeta dados de clientes.</p>
      <section style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 16, marginTop: 24 }}>
        {THEMES.map((t: Theme) => (
          <article key={t.id} style={{ border: "1px solid currentColor", borderRadius: "var(--theme-radius)", padding: 16, background: "var(--theme-bg)", boxShadow: "var(--theme-shadow)" }}>
            <h2 style={{ margin: "0 0 8px", fontFamily: "var(--theme-font)", color: "var(--theme-accent)" }}>{t.name}</h2>
            <p style={{ margin: "0 0 12px", fontSize: 14, opacity: 0.85 }}>{t.desc}</p>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <span style={{ fontSize: 11, padding: "2px 6px", border: "1px solid var(--theme-accent)", borderRadius: 4, color: "var(--theme-accent)" }}>{t.id}</span>
              <button style={{ padding: "6px 12px", border: "1px solid currentColor", borderRadius: "var(--theme-radius)", background: "transparent", color: "inherit", cursor: "pointer" }} onClick={() => { document.documentElement.setAttribute("data-theme", t.id); }}>Pré-visualizar (local)</button>
            </div>
          </article>
        ))}
      </section>
      <section style={{ marginTop: 32, padding: 16, borderLeft: "4px solid var(--theme-accent)", background: "rgba(0,0,0,0.03)" }}>
        <h3>Como funcionará (quando implementado)</h3>
        <p>As 10 interfaces usam o mesmo componente base; apenas os tokens CSS (cor, fonte, raio, sombra) mudam. Quando PUB-07 for implementado, Marcelo seleciona uma no painel, a escolha será persistida em site_visual com histórico e rollback, e todos os clientes verão a mudança após publicação autorizada. Nenhum dado de cliente será alterado.</p>
        <p>Modo dia/noite é controlado separadamente (não é tema, é preferência de usuário).</p>
      </section>
      <div style={{ marginTop: 24, fontSize: 12, opacity: 0.6 }}>Máximo 10 interfaces ativas previstas. Nenhuma interface pode ser removida do banco — apenas desativada via toggle de configuração (não implementado nesta prévia).</div>
    </main>
  );
}
