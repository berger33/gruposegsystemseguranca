"use client";
import RagWidget from "@/components/RagWidget";
import AiBotWidget from "@/components/AiBotWidget";

export default function RhAssistentePage(){
  return (
    <main style={{ padding:24, maxWidth:900, margin:"0 auto", fontFamily:"system-ui, sans-serif" }}>
      <h1 style={{ fontSize:28 }}>Assistente RH — RAG específico RH + Ollama Qwen3 1.7B</h1>
      <p style={{ fontSize:13, opacity:0.8 }}>RAG específico para RH no módulo de RH, informações apenas áreas pertinentes RH: cadastro profissional, admissão, férias, benefícios, treinamentos, avaliações, sem expor salário detalhado fora escopo, sem dados cliente PII. Modelo Ollama Qwen3 1.7B fila garante atendimento todo mundo em fila. Modo desenvolvedor altera dinâmica sem_ia/com_ia/whatsapp, padrão com IA beta.</p>

      <AiBotWidget defaultRagKey="rh" showDevConfig={false} />

      <RagWidget ragKey="rh" title="RAG RH Andreia" description="RH cadastro profissional separado login, histórico cargo lotação remuneração autorizada, recrutamento vaga candidatos triagem entrevista, banco talentos, admissão checklist documentos validação exame treinamento, dossiê tipos versões validade pendências aprovador, desligamento checklist devolução revogação, férias períodos aquisitivo concessivo saldo programação conflito cobertura, afastamentos período retorno documentação restrita substituição, ponto justificativas divergências workflow correção fechamento competência, banco horas adicionais, benefícios elegibilidade solicitações conferência exportação fornecedor, adiantamentos reembolsos alçada comprovantes, saúde ocupacional agenda vencimentos documentos restritos, integração contabilidade SST, treinamento por cargo, competências, uniformes EPI, fechamento DP, holerites fonte autorizada, avaliações planos desenvolvimento, atendimento interno, indicadores" placeholder="Ex: como admitir colaborador? como programar férias? como consultar benefício? qual treinamento vence?" />

      <section style={{ marginTop:24, padding:12, background:"#f8fafc", borderRadius:6, fontSize:12 }}>
        <strong>Aceite:</strong> RAG RH apenas área pertinente RH, sem dados cliente PII, sem diagnóstico médico exposto, modelo qwen3:1.7b Ollama host http://localhost:11434 queue 100, fila garante todo mundo atendido, guardrails sem invenção preço/cobertura/licença/prazo, protocolo RAG-RH-YYYYMMDD-XXXX, BOT-RH-YYYYMMDD-XXXX.
      </section>
    </main>
  );
}
