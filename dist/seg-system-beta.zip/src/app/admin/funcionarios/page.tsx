export default function AdminFuncionariosPage() {
  return (
    <main style={{ padding: 24, fontFamily: "system-ui, sans-serif", color: "var(--theme-fg)", background: "var(--theme-bg)" }}>
      <div style={{ borderLeft: "4px solid #d97706", background: "#fef3c7", padding: "12px 16px", marginBottom: 16, borderRadius: 6, color: "#78350f" }}>
        <strong>Prévia — recurso em modelagem, sem persistência garantida</strong>
        <p style={{ margin: "6px 0 0", fontSize: 13 }}>
          Esta tela é descritiva. Não concede permissão, não cria vínculo trabalhista, não envia e-mail, não registra ponto. Dados exibidos são ilustrativos. A execução real depende de migrações aplicadas (007) verificadas via <code>npm run db:migrate</code> e de decisão de negócio (escala, geolocalização, retenção).
        </p>
      </div>
      <h1>Funcionários / RH — Opção B (em modelagem)</h1>
      <p>Postos, escalas (12x36 / 6x1 / diarista), ponto com geolocalização, evidência, passagem de plantão.</p>
      <ul>
        <li>Migração 007 modelada (posts, assignments, scale_rules, time_entries, handover) — execução verificável via runner 001-010, não presumida.</li>
        <li>Administração por convite (não autocadastro) — convite real via <code>/api/admin/invites</code> com kind=staff, sem envio fictício.</li>
        <li>Geolocalização opcional; retenção ainda a definir (D-07).</li>
        <li>Dados de demonstração só em testes identificados, nunca em produção.</li>
      </ul>
      <div style={{ marginTop: 16, padding: 16, borderLeft: "4px solid var(--theme-accent)", background: "rgba(0,0,0,0.03)" }}>
        <strong>Próximo:</strong> definir escala por posto, ponto por posto/pessoa, e retenção de geo. SMTP só depois de provedor real (D-08). Nenhuma promessa de envio até lá.
      </div>
    </main>
  );
}
