"use client";
import { useState } from "react";

export default function BackupClient() {
  const [backups, setBackups] = useState<any[]>([]);
  const [restores, setRestores] = useState<any[]>([]);
  const [policies, setPolicies] = useState<any[]>([]);
  const [msg, setMsg] = useState("");
  const [form, setForm] = useState({ backup_type: "full", retention_days: "90", storage_provider: "local_encrypted", encryption_enabled: true });
  const [restoreForm, setRestoreForm] = useState({ backup_job_id: "", restore_type: "test", target_env: "isolated_test_env", is_isolated: true });

  async function loadBackups() {
    setMsg("Carregando backups...");
    const r = await fetch('/api/admin/backups');
    const j = await r.json();
    if (!r.ok) { setMsg(`Erro backups: ${j.error}`); return; }
    setBackups(j.backups || []);
    setMsg(`Backups ${j.backups?.length || 0} — ${j.note}`);
  }

  async function loadRestores() {
    const r = await fetch('/api/admin/backups/restores');
    const j = await r.json();
    if (!r.ok) { setMsg(`Erro restores: ${j.error}`); return; }
    setRestores(j.restores || []);
    setMsg(`Restores ${j.restores?.length || 0} — ${j.note}`);
  }

  async function loadRetention() {
    const r = await fetch('/api/admin/backups/retention');
    const j = await r.json();
    if (!r.ok) { setMsg(`Erro retention: ${j.error}`); return; }
    setPolicies(j.policies || []);
    setMsg(`Políticas ${j.policies?.length || 0} expirados ${j.expired_count} — ${j.note}`);
  }

  async function createBackup() {
    setMsg("Criando backup...");
    const r = await fetch('/api/admin/backups', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
    const j = await r.json();
    if (!r.ok) { setMsg(`Erro criar: ${j.error} ${j.detail || ''}`); return; }
    setMsg(`Backup criado ${j.backup?.id} pendente — ${j.note}`);
    await loadBackups();
  }

  async function createRestore() {
    if (!restoreForm.backup_job_id.trim()) { setMsg("backup_job_id obrigatório"); return; }
    setMsg("Iniciando restauração...");
    const r = await fetch('/api/admin/backups/restores', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(restoreForm) });
    const j = await r.json();
    if (!r.ok) { setMsg(`Erro restore: ${j.error} ${j.detail || ''}`); return; }
    setMsg(`Restore ${j.restore?.id} ${j.restore?.restore_type} em ${j.restore?.target_env} isolado=${j.restore?.is_isolated} — ${j.note}`);
    await loadRestores();
  }

  async function loadAll() {
    await loadBackups();
    await loadRestores();
    await loadRetention();
  }

  return (
    <div style={{ border: '1px solid #e5e7eb', borderRadius: 12, padding: 16, marginTop: 16 }}>
      <h3 style={{ fontSize: 16, fontWeight: 700 }}>PLT-08 Backup — banco e documentos, criptografia, acesso, retenção, restauração testada isolado</h3>
      <p style={{ fontSize: 12, color: '#6b7280' }}>Backup com criptografia AES-256-GCM, acesso restrito admin/ti, retenção configurável, checksum, storage_location sanitizado, restauração testada em ambiente isolado obrigatório antes de produção. Sem segredos em logs, error_sanitized.</p>
      {msg && <div style={{ background: '#f3f4f6', padding: 8, borderRadius: 8, fontSize: 11, marginTop: 8, whiteSpace: 'pre-wrap' }}>{msg}</div>}
      <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
        <button onClick={loadAll} style={{ padding: '6px 12px', borderRadius: 6, background: '#111827', color: '#fff', fontSize: 12 }}>Carregar tudo</button>
        <button onClick={loadBackups} style={{ padding: '6px 12px', borderRadius: 6, background: '#374151', color: '#fff', fontSize: 12 }}>Backups</button>
        <button onClick={loadRestores} style={{ padding: '6px 12px', borderRadius: 6, background: '#374151', color: '#fff', fontSize: 12 }}>Restores</button>
        <button onClick={loadRetention} style={{ padding: '6px 12px', borderRadius: 6, background: '#374151', color: '#fff', fontSize: 12 }}>Retenção</button>
      </div>

      <div style={{ display: 'flex', gap: 16, marginTop: 12 }}>
        <div style={{ flex: 1 }}>
          <h4 style={{ fontSize: 13, fontWeight: 600 }}>Backups ({backups.length})</h4>
          <div style={{ maxHeight: 300, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 4, marginTop: 6 }}>
            {backups.map((b: any) => (
              <div key={b.id} style={{ padding: 6, border: '1px solid #e5e7eb', borderRadius: 6, fontSize: 11, background: b.status === 'success' ? '#f0fdf4' : b.status === 'failed' ? '#fef2f2' : '#fff' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontWeight: 600 }}>{b.backup_type} • {b.status} • {b.encryption_method}</span><span>{b.size_bytes ? `${(b.size_bytes/1024/1024).toFixed(1)}MB` : '—'}</span></div>
                <div style={{ color: '#6b7280' }}>ret {b.retention_days}d até {b.retention_until?.slice(0,10)} • {b.storage_location || '—'} • checksum {b.checksum?.slice(0,16) || '—'} • restore_tested {String(b.is_restore_tested)} {b.restore_test_env || ''}</div>
                <div style={{ color: '#6b7280' }}>{new Date(b.created_at).toLocaleString('pt-BR')} por {b.created_by} {b.error_sanitized ? `ERR:${b.error_sanitized.slice(0,50)}` : ''}</div>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 10, padding: 8, border: '1px dashed #d1d5db', borderRadius: 6 }}>
            <div style={{ fontSize: 12, fontWeight: 600 }}>Novo backup (criptografado)</div>
            <div style={{ display: 'flex', gap: 4, marginTop: 4 }}>
              <select value={form.backup_type} onChange={e => setForm({ ...form, backup_type: e.target.value })} style={{ flex: 1, padding: 4, borderRadius: 4, border: '1px solid #d1d5db', fontSize: 11 }}>
                <option value="full">full</option><option value="database">database</option><option value="documents">documents</option><option value="incremental">incremental</option>
              </select>
              <input value={form.retention_days} onChange={e => setForm({ ...form, retention_days: e.target.value })} placeholder="ret dias" type="number" style={{ width: 70, padding: 4, borderRadius: 4, border: '1px solid #d1d5db', fontSize: 11 }} />
            </div>
            <input value={form.storage_provider} onChange={e => setForm({ ...form, storage_provider: e.target.value })} placeholder="storage_provider" style={{ width: '100%', marginTop: 4, padding: 4, borderRadius: 4, border: '1px solid #d1d5db', fontSize: 11 }} />
            <label style={{ fontSize: 11, display: 'flex', alignItems: 'center', gap: 4, marginTop: 4 }}><input type="checkbox" checked={form.encryption_enabled} onChange={e => setForm({ ...form, encryption_enabled: e.target.checked })} /> encryption AES-256-GCM</label>
            <button onClick={createBackup} style={{ marginTop: 6, padding: '4px 10px', borderRadius: 6, background: '#111827', color: '#fff', fontSize: 11 }}>Criar backup</button>
          </div>
        </div>

        <div style={{ flex: 1 }}>
          <h4 style={{ fontSize: 13, fontWeight: 600 }}>Restores ({restores.length}) — teste isolado obrigatório</h4>
          <div style={{ maxHeight: 250, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 4, marginTop: 6 }}>
            {restores.map((r: any) => (
              <div key={r.id} style={{ padding: 6, border: '1px solid #e5e7eb', borderRadius: 6, fontSize: 11, background: r.status === 'success' ? '#f0fdf4' : r.status === 'failed' ? '#fef2f2' : '#fef3c7' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ fontWeight: 600 }}>{r.restore_type} • {r.status} • isolado {String(r.is_isolated)}</span><span>{r.target_env}</span></div>
                <div style={{ color: '#6b7280' }}>backup {r.backup_job_id.slice(0,8)} • {new Date(r.created_at).toLocaleString('pt-BR')} por {r.requested_by}</div>
                {r.verification_notes && <div style={{ color: '#065f46' }}>{r.verification_notes.slice(0,120)}</div>}
                {r.error_sanitized && <div style={{ color: '#991b1b' }}>ERR:{r.error_sanitized.slice(0,80)}</div>}
              </div>
            ))}
          </div>
          <div style={{ marginTop: 10, padding: 8, border: '1px dashed #d1d5db', borderRadius: 6 }}>
            <div style={{ fontSize: 12, fontWeight: 600 }}>Testar restauração (isolado)</div>
            <input value={restoreForm.backup_job_id} onChange={e => setRestoreForm({ ...restoreForm, backup_job_id: e.target.value })} placeholder="backup_job_id UUID" style={{ width: '100%', marginTop: 4, padding: 4, borderRadius: 4, border: '1px solid #d1d5db', fontSize: 11 }} />
            <div style={{ display: 'flex', gap: 4, marginTop: 4 }}>
              <select value={restoreForm.restore_type} onChange={e => setRestoreForm({ ...restoreForm, restore_type: e.target.value })} style={{ flex: 1, padding: 4, borderRadius: 4, border: '1px solid #d1d5db', fontSize: 11 }}>
                <option value="test">test (isolado obrigatório)</option><option value="verification">verification</option><option value="production">production (exige teste isolado prévio)</option>
              </select>
              <input value={restoreForm.target_env} onChange={e => setRestoreForm({ ...restoreForm, target_env: e.target.value })} placeholder="target_env" style={{ flex: 1, padding: 4, borderRadius: 4, border: '1px solid #d1d5db', fontSize: 11 }} />
            </div>
            <label style={{ fontSize: 11, display: 'flex', alignItems: 'center', gap: 4, marginTop: 4 }}><input type="checkbox" checked={restoreForm.is_isolated} onChange={e => setRestoreForm({ ...restoreForm, is_isolated: e.target.checked })} /> is_isolated (teste deve ser isolado)</label>
            <button onClick={createRestore} style={{ marginTop: 6, padding: '4px 10px', borderRadius: 6, background: '#7c2d12', color: '#fff', fontSize: 11 }}>Iniciar restore</button>
          </div>

          <h4 style={{ fontSize: 13, fontWeight: 600, marginTop: 12 }}>Retenção ({policies.length})</h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4, marginTop: 6 }}>
            {policies.map((p: any) => (
              <div key={p.id} style={{ padding: 6, border: '1px solid #e5e7eb', borderRadius: 6, fontSize: 11 }}>
                <div style={{ fontWeight: 600 }}>{p.category} • {p.retention_days} dias • {p.is_active ? 'ativa' : 'inativa'}</div>
                <div style={{ color: '#6b7280' }}>{p.description || '—'}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
