import RbacClient from "./RbacClient";
import AuditClient from "./AuditClient";
import NotificationsClient from "./NotificationsClient";
import IntegrationsClient from "./IntegrationsClient";
import CatalogClient from "./CatalogClient";
import EquipmentClient from "./EquipmentClient";
import InspectionClient from "./InspectionClient";
import LaborBudgetClient from "./LaborBudgetClient";
import TechnicalBudgetClient from "./TechnicalBudgetClient";
import CostParameterClient from "./CostParameterClient";
import PriceScenarioClient from "./PriceScenarioClient";
import DiscountClient from "./DiscountClient";
import ProposalClient from "./ProposalClient";
import ProposalDeliveryClient from "./ProposalDeliveryClient";
import ProposalAcceptanceClient from "./ProposalAcceptanceClient";
import ContractClient from "./ContractClient";
import ReportClient from "./ReportClient";
import CommissionClient from "./CommissionClient";
import CommercialLibraryClient from "./CommercialLibraryClient";
import PartnershipClient from "./PartnershipClient";
import ContractDetailsClient from "./ContractDetailsClient";
import ContractStatusClient from "./ContractStatusClient";
import ContractAmendmentClient from "./ContractAmendmentClient";
import ContractAlertClient from "./ContractAlertClient";
import ContractDocObligationClient from "./ContractDocObligationClient";
import ContractImplantationClient from "./ContractImplantationClient";
import ContractClosureClient from "./ContractClosureClient";
import ContractFiscalClient from "./ContractFiscalClient";
import ContractManagementDiaryClient from "./ContractManagementDiaryClient";
import NotificationPreferencesClient from "./NotificationPreferencesClient";
import ObservabilityClient from "./ObservabilityClient";
import HealthcheckClient from "./HealthcheckClient";
import BackupClient from "./BackupClient";
import PrivacyClient from "./PrivacyClient";
import LgpdRequestClient from "./LgpdRequestClient";
import RetentionClient from "./RetentionClient";
import IncidentClient from "./IncidentClient";
import ConfigClient from "./ConfigClient";
import DependencyClient from "./DependencyClient";
import IntegrationLogClient from "./IntegrationLogClient";
import BudgetClient from "./BudgetClient";
import EnvClient from "./EnvClient";
import MaintenanceDocClient from "./MaintenanceDocClient";
import HrClient from "./HrClient";
import EmpProfileClient from "./EmpProfileClient";
import HrRecruitmentClient from "./HrRecruitmentClient";
import HrTerminationClient from "./HrTerminationClient";
import HrAbsenceClient from "./HrAbsenceClient";
import HrBenefitsClient from "./HrBenefitsClient";
import HrTrainingClient from "./HrTrainingClient";
import HrAdvancedClient from "./HrAdvancedClient";
import EmpPortalClient from "./EmpPortalClient";
import EmpOpsClient from "./EmpOpsClient";
import EmpSelfClient from "./EmpSelfClient";
import EmpAdvanced2Client from "./EmpAdvanced2Client";
import EmpPwaClient from "./EmpPwaClient";
import OpsClient from "./OpsClient";
import OpsAdvancedClient from "./OpsAdvancedClient";
import OpsAdvanced2Client from "./OpsAdvanced2Client";
import OpsAdvanced3Client from "./OpsAdvanced3Client";
import CliClient from "./CliClient";
import CliAdvancedClient from "./CliAdvancedClient";
import CliFinanceClient from "./CliFinanceClient";
import FinClient from "./FinClient";
import FinAdvancedClient from "./FinAdvancedClient";
import FinManagementClient from "./FinManagementClient";
import FinBudgetClient from "./FinBudgetClient";
import AdmClient from "./AdmClient";
import AdmAdvancedClient from "./AdmAdvancedClient";
import AstClient from "./AstClient";
import AstAdvancedClient from "./AstAdvancedClient";
import ExtClient from "./ExtClient";
import ExtAdvancedClient from "./ExtAdvancedClient";
import ExtReportingClient from "./ExtReportingClient";
import CmsClient from "./CmsClient";
import ThemeClient from "./ThemeClient";
import SeoClient from "./SeoClient";
import PackageClient from "./PackageClient";
import OriginMetricsClient from "./OriginMetricsClient";
import EmployeeComplaintClient from "./EmployeeComplaintClient";
import PubFaqAssistedClient from "./PubFaqAssistedClient";
import AiRagClient from "./AiRagClient";

export default function TiAdminPage() {
  return (
    <main style={{ padding: 24, maxWidth: 1100, margin: "0 auto", fontFamily: "system-ui, sans-serif", color: "var(--theme-fg)", background: "var(--theme-bg)", borderRadius: "var(--theme-radius)", boxShadow: "var(--theme-shadow)" }}>
      <h1 style={{ fontFamily: "var(--theme-font)", color: "var(--theme-accent)" }}>TI — RBAC, auditoria, fila, integrações, catálogo e equipamentos (F1/F2/F3)</h1>
      <p>Login individual de staff, RBAC granular, auditoria consultável PLT-02, fila durável PLT-04, integrações PLT-03, catálogo PUB-01 + CRM-11 e equipamentos CRM-12 implementados.</p>
      <section style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 16, marginTop: 16 }}>
        {[
          { label: "Login staff", desc: "POST /api/admin/session com email+password, sessão com identityId, auditoria staff_login. Tokens marcelo/ti ainda válidos como migração." },
          { label: "Convites staff", desc: "POST /api/admin/invites com kind=staff e role=admin|ti|rh, aceita em /admin/convite. Rate limit 10/h IP, 20/h admin (SEC-15)." },
          { label: "RBAC granular PLT-01", desc: "Tabela auth_permissions com permission, scope_type, scope_id, motivo obrigatório, revogação idempotente. 29 permissões conhecidas." },
          { label: "Auditoria PLT-02", desc: "GET /api/admin/audit?actorKind=&action=&result=&from=&to=, POST /api/admin/audit/export, audit_query e audit_export registrados, acesso restrito admin/ti, sem segredos, 12 meses retenção." },
          { label: "Fila notificações PLT-04", desc: "Tabela notification_queue com dedup_key único, recipient_kind autorizado, channel, template, payload, status queued/sending/sent/failed/dead, attempts, backoff 1m/5m/15m/60m/240m, retry." },
          { label: "Integrações PLT-03", desc: "Tabela integrations com status configurado/não configurado/falha, último processamento, erros sanitizados, teste conexão. GET /api/admin/integrations, POST /:id/test, PUT /:id." },
          { label: "Catálogo PUB-01", desc: "Tabela service_catalog com 6 serviços validados, descrição, público, perguntas qualificação, flag publicação. GET /api/catalog e /api/catalog/:id, fallback arquivo." },
          { label: "Segurança SEC-13/15", desc: "Cookies Secure, sameOrigin, JSON limitado, métodos corretos, erro sem stack, proxy confiável TRUST_PROXY, throttle login/lead/resend/mfa/invite." },
        ].map((c) => (
          <article key={c.label} style={{ padding: 16, border: "1px solid currentColor", borderRadius: "var(--theme-radius)", background: "rgba(0,0,0,0.03)" }}>
            <h3 style={{ margin: 0, color: "var(--theme-accent)" }}>{c.label}</h3>
            <p style={{ fontSize: 14, margin: "8px 0 0" }}>{c.desc}</p>
          </article>
        ))}
      </section>
      <RbacClient />
      <AuditClient />
      <NotificationsClient />
      <IntegrationsClient />
      <CatalogClient />
      <EquipmentClient />
      <InspectionClient />
      <LaborBudgetClient />
      <TechnicalBudgetClient />
      <CostParameterClient />
      <PriceScenarioClient />
      <DiscountClient />
      <ProposalClient />
      <ProposalDeliveryClient />
      <ProposalAcceptanceClient />
      <ContractClient />
      <ReportClient />
      <CommissionClient />
      <CommercialLibraryClient />
      <PartnershipClient />
      <ContractDetailsClient />
      <ContractStatusClient />
      <ContractAmendmentClient />
      <ContractAlertClient />
      <ContractDocObligationClient />
      <ContractImplantationClient />
      <ContractClosureClient />
      <ContractFiscalClient />
      <ContractManagementDiaryClient />
      <NotificationPreferencesClient />
      <ObservabilityClient />
      <HealthcheckClient />
      <BackupClient />
      <PrivacyClient />
      <LgpdRequestClient />
      <RetentionClient />
      <IncidentClient />
      <ConfigClient />
      <DependencyClient />
      <IntegrationLogClient />
      <BudgetClient />
      <EnvClient />
      <MaintenanceDocClient />
      <HrClient />
      <EmpProfileClient />
      <HrRecruitmentClient />
      <HrTerminationClient />
      <HrAbsenceClient />
      <HrBenefitsClient />
      <HrTrainingClient />
      <HrAdvancedClient />
      <EmpPortalClient />
      <EmpOpsClient />
      <EmpSelfClient />
      <EmpAdvanced2Client />
      <EmpPwaClient />
      <OpsClient />
      <OpsAdvancedClient />
      <OpsAdvanced2Client />
      <OpsAdvanced3Client />
      <CliClient />
      <CliAdvancedClient />
      <CliFinanceClient />
      <FinClient />
      <FinAdvancedClient />
      <FinManagementClient />
      <FinBudgetClient />
      <AdmClient />
      <AdmAdvancedClient />
      <AstClient />
      <AstAdvancedClient />
      <ExtClient />
      <ExtAdvancedClient />
      <ExtReportingClient />
      <CmsClient />
      <ThemeClient />
      <SeoClient />
      <PackageClient />
      <OriginMetricsClient />
      <EmployeeComplaintClient />
      <PubFaqAssistedClient />
      <AiRagClient />
      <section style={{ marginTop: 24, padding: 16, borderLeft: "4px solid var(--theme-accent)", background: "rgba(0,0,0,0.03)" }}>
        <h3>SEC-11 / SEC-12 — Prévias e privacidade</h3>
        <ul style={{ fontSize: 14 }}>
          <li><strong>SEC-11:</strong> Nenhuma simulação concede permissão ou informa envio inexistente — /admin/tema só pré-visualiza local, /admin/visual seleção pausada, /admin/funcionarios e /admin/marcelo prévia descritiva com aviso sem persistência, sem envio fictício.</li>
          <li><strong>SEC-12:</strong> /privacidade minuta pendente com aviso explícito, base legal, retenção, encarregado a definir, direitos titular, noindex mantido.</li>
          <li><strong>PUB-01:</strong> Catálogo único 6 serviços validados com descrição, público, perguntas qualificação, flag publicação — tabela service_catalog + arquivo fallback, API /api/catalog, cerca elétrica só após validação comercial.</li>
          <li><strong>PLT-03:</strong> Integrações com status configurado/não configurado/falha, último processamento, erros sanitizados sem segredos, teste conexão via POST /:id/test, auditoria integration_check/test/update.</li>
        </ul>
      </section>
    </main>
  );
}
