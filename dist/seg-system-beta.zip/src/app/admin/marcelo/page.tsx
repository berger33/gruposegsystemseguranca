export default function MarceloDashboardPage() {
  return (
    <main style={{ padding: 24, maxWidth: 1000, margin: "0 auto", fontFamily: "system-ui, sans-serif", color: "var(--theme-fg)", background: "var(--theme-bg)", borderRadius: "var(--theme-radius)", boxShadow: "var(--theme-shadow)" }}>
      <div style={{ borderLeft: "4px solid #d97706", background: "#fef3c7", padding: "12px 16px", marginBottom: 16, borderRadius: 6, color: "#78350f" }}>
        <strong>Prévia — painel descritivo, sem dados reais</strong>
        <p style={{ margin: "6px 0 0", fontSize: 13 }}>
          Esta tela lista recursos futuros. Não exibe faturamento real, não concede permissão, não envia notificação. Nenhuma simulação informa envio inexistente. Implementação depende de CRM (F3), CON (F4), FIN (F7) e PLT completo.
        </p>
      </div>
      <h1 style={{ fontFamily: "var(--theme-font)", color: "var(--theme-accent)" }}>Camada 3 — Marcelo (dono / admin) — prévia</h1>
      <p>Acesso a todas as configurações menos programação/TI avançado (reservado à Camada 4) — quando implementado.</p>
      <section style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 16, marginTop: 16 }}>
        {[
          { label: "Dashboard executivo (futuro)", desc: "Faturamento por posto/cliente, inadimplência, contratos a vencer — depende de FIN-07 e dados reais." },
          { label: "Gestão de contratos (futuro)", desc: "Vigência, reajuste anual, SLA por cliente — CON-01..CON-11." },
          { label: "CRM / Propostas (futuro)", desc: "Funil de leads do site, follow-up — CRM-01..CRM-27, sem promessa de entrega automática." },
          { label: "Financeiro (futuro)", desc: "Contas a pagar/receber; NF-e — FIN-11/12 condicionais, sem emissão real nesta prévia." },
          { label: "Aprovações (futuro)", desc: "Despesas RH, descontos, contratos especiais — com alçada e auditoria." },
          { label: "Tema / Marca (prévia local)", desc: "Escolher entre 10 interfaces; logo, cores, textos — publicação autorizada e rollback em PUB-07, hoje só pré-visualização local." },
          { label: "Bot RAG (condicional)", desc: "Curadoria: revisar respostas, adicionar documentos — só após base aprovada e controles capítulo 19, sem invenção de preço/cobertura." },
          { label: "Notificações (futuro)", desc: "Contratos vencendo, CNV vencida, meta não batida — depende de PLT-04 fila durável, sem promessa de envio sem provedor configurado." },
        ].map((c) => (
          <article key={c.label} style={{ padding: 16, border: "1px solid currentColor", borderRadius: "var(--theme-radius)", background: "rgba(0,0,0,0.03)" }}>
            <h3 style={{ margin: 0, color: "var(--theme-accent)" }}>{c.label}</h3>
            <p style={{ fontSize: 14, margin: "8px 0 0" }}>{c.desc}</p>
          </article>
        ))}
      </section>
      <div style={{ marginTop: 20, padding: 12, borderLeft: "4px solid var(--theme-accent)", background: "rgba(255,255,255,0.2)" }}>
        <strong>Modo dia/noite:</strong> controle global de preferência do usuário; pode ser configurado como padrão para operadores de monitoramento — quando PUB-07 implementado.
      </div>
    </main>
  );
}
