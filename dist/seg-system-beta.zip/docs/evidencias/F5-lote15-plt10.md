# F5 lote 15 — PLT-10 pedidos LGPD

- Data/hora: 2026-09-29T02:00Z
- Fase: PLT-10 pedidos de acesso/correção/eliminação com verificação de identidade
- Status: implementado não verificado

## Escopo

- Pedidos LGPD art.18: acesso, correção, eliminação, portabilidade, oposição, revogação consentimento, informação, outro
- Verificação de identidade obrigatória antes de aprovado/atendido
- Responsável interno, prazo 15 dias, impedimentos legais documentados
- Histórico de transições completo + auditoria

## Migração 048-plt10-lgpd-requests.sql

- Enums: crm_lgpd_request_type acesso/correcao/eliminacao/portabilidade/oposicao/revogacao_consentimento/informacao/outro
- crm_lgpd_request_status recebido/em_verificacao/em_analise/aguardando_titular/aprovado/atendido/rejeitado/cancelado/expirado
- crm_lgpd_verification_method email/documento/presencial/video/outro
- Tabela lgpd_requests: id PK, request_type, status, requester_name 200, requester_email 320, requester_document_hash 200, description 10..5000, verification_method, is_identity_verified bool default false, verified_at/by, responsible_id/name, due_date DATE 15 dias, legal_impediment 2000, impediment_documented bool, response 5000, response_sent_at, created_by/by_id, updated_by/by_id, timestamps, índices type/status email/status responsible, trigger updated_at
- Tabela lgpd_request_history: id PK, request_id FK CASCADE, previous_status, next_status, reason 2000, changed_by 80, changed_by_id, created_at, índice request_id
- Audit: lgpd_request_create/verify/update/respond/reject

## API lgpd-request-api.mjs

- REQUEST_TYPES 8, STATUSES 9, VERIFICATION_METHODS 5
- sanitizeText 5000, hashDocument SHA256
- ALLOWED_TRANSITIONS: recebido->[em_verificacao,cancelado], em_verificacao->[em_analise,aguardando_titular,rejeitado,cancelado], em_analise->[aprovado,rejeitado,aguardando_titular,cancelado], aguardando->[em_analise,rejeitado,expirado,cancelado], aprovado->[atendido,rejeitado,cancelado]
- handleRequests: POST público /api/lgpd/requests /privacy/requests /public/lgpd sameOrigin valida type name email description min10 hash doc dueDate +15d INSERT recebido audit public create, GET admin list filtros type status email limit 200 admin/ti/rh restrito
- handleRequestById: GET request+history UUID valida, PATCH next_status reason responsible_name/id verification_method is_identity_verified legal_impediment impediment_documented response valida transition identity_verification_required legal_impediment_must_be_documented UPDATE INSERT history audit verify/update/respond/reject

## server.mjs

- import createLgpdRequestApi, const lgpdRequestApi init
- Rotas: /api/lgpd/requests /privacy/requests /public/lgpd POST+GET, /admin/lgpd/requests /crm/lgpd/requests /admin/privacy/requests GET, byId /admin/lgpd/requests/:id /crm/lgpd/requests/:id /admin/privacy/requests/:id /lgpd/requests/:id GET/PATCH
- API_PATH_MATCH expandido: /api/lgpd/requests /privacy/requests /public/lgpd /admin/lgpd/requests /crm/lgpd/requests /admin/privacy/requests startsWith /admin/lgpd/requests/ /crm/lgpd/requests/ /admin/privacy/requests/ /lgpd/requests/

## UI

- src/app/admin/ti/LgpdRequestClient.tsx: load requests list type status verificado prazo requester email resp date description, form novo pedido público request_type name email document hash description, detail status verificado requester doc_hash description verification responsible due impediment response history list previous→next por changed_by reason, form atualizar next_status reason responsible_name verification_method is_identity_verified legal_impediment impediment_documented response
- src/app/admin/ti/page.tsx: import LgpdRequestClient + <LgpdRequestClient/>

## Infra

- scripts/migrate-site-visual.mjs: adicionado 048-plt10-lgpd-requests.sql
- Build: 59 páginas, testes 46 pass 4 skipped
- Próxima: PLT-11 retenção por categoria descarte automático
