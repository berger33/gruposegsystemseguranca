# F3 lote 19 — CRM-27 parcerias e indicações, renovação/upsell e recuperação da carteira

Data: 2026-09-28T12:30Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 0a970bb (CRM-26)

## Requisito
CRM-27: parcerias e indicações, renovação/upsell e recuperação da carteira, com responsáveis e métricas.

## Implementação
### Migração 031
- `db/migrations/031-crm27-partnerships-renewals.sql`
- Tipos: crm_partner_type parceiro/revenda/indicador/fornecedor/outro, crm_partner_status ativo/inativo/suspenso/arquivado, crm_referral_status pendente/em_contato/qualificada/convertida/rejeitada/expirada, crm_renewal_type renovacao/upsell/cross_sell/recuperacao, crm_renewal_status planejada/em_negociacao/proposta_enviada/ganha/perdida/cancelada
- `crm_partners` id UUID PK, display_name 200, type, document_ref 32, email 320, phone 30, city 100, state 2, status ativo/inativo/suspenso/arquivado, responsible_id FK, responsible_name 120, commission_percent 0..100, notes 2000, origin 100, created_by/by_id, índices type_status/responsible/city, trigger
- `crm_referrals` id UUID PK, partner_id/contact_id/company_id FK SET NULL, referred_company/contact/opportunity_id FK SET NULL, title 200, description 2000, status pendente/em_contato/qualificada/convertida/rejeitada/expirada, reward_type 100, reward_value 14,2, responsible_id/name, converted_at, rejection_reason 500, created_by/by_id, índices partner/status/responsible/opportunity, CHECK referrer required
- `crm_renewals` id UUID PK, company_id FK CASCADE, contract_id/previous_contract_id/opportunity_id FK SET NULL, type renovacao/upsell/cross_sell/recuperacao, title 200, description 2000, previous/new value 14,2, uplift_percent, renewal_date/forecast_date DATE, status planejada/em_negociacao/proposta_enviada/ganha/perdida/cancelada, loss_reason 500, responsible_id/name, metrics JSONB dias_desde_ultimo_contato/tentativas_contato/motivo_perda_anterior, created_by/by_id, índices company/contract/status/responsible/type, trigger
- `crm_partner_metrics` id UUID PK, partner_id FK CASCADE, period_start/end DATE CHECK end>=start, referrals_count, converted_count, conversion_rate, total_value, responsible_id, UNIQUE(partner_id,period_start,period_end), índices partner
- Auditoria crm_partner_create/update/status, crm_referral_create/update/status, crm_renewal_create/update/status

### API
- `src/server/partnership-api.mjs`
- `handlePartners` GET filtros type/status/responsible count+list, POST display_name 200 type enum document_ref email phone city state responsible_id/name commission_percent notes origin INSERT ativo
- `handlePartnerById` GET partner+metrics 12+referralsByStatus GROUP BY status, PATCH display_name/type/status/responsible/commission/notes
- `handleReferrals` GET filtros partner/status/responsible count total converted list, POST partner_id/contact_id/company_id title 200 description reward_type/value responsible_id/name INSERT pendente CHECK referrer required
- `handleReferralById` GET/PATCH status pendente/em_contato/qualificada/convertida/rejeitada/expirada converted_at NOW rejection_reason required para rejeitada opportunity_id/responsible
- `handleRenewals` GET filtros company/type/status/responsible count total_new_value list, POST company_id UUID title 200 type renovacao/upsell/cross_sell/recuperacao description previous/new value renewal_date/forecast_date responsible_id/name metrics JSONB calcula uplift_percent (new-previous)/previous*100 INSERT planejada
- `handleRenewalById` GET/PATCH title/description/new_value/renewal_date/forecast_date/status planejada/em_negociacao/proposta_enviada/ganha/perdida/cancelada loss_reason required para perdida responsible/metrics
- `handleMetrics` GET responsible/periodStart/end filtros WHERE renewal_date GROUP BY type,status COUNT SUM new_value referral GROUP BY status partner COUNT active, note métricas por responsável

- `server.mjs` rotas `/api/crm/partners`, `/:id`, `/api/crm/referrals`, `/:id`, `/api/crm/renewals`, `/:id`, `/api/crm/partnership-metrics`

### UI
- `src/app/admin/ti/PartnershipClient.tsx`
- Forms criar parceiro display_name/type/email/responsible_name/commission_percent lista
- Criar indicação partner_id/title/referred_company_id/responsible_name lista com ações Converter/Qualificar
- Criar renovação/upsell/recuperação company_id/type/title/previous/new/renewal_date/responsible_name lista com ações Ganha/Negociação
- Métricas parceiros total/ativos, renovações por tipo/status, indicações por status

## Responsáveis e métricas
- responsible_id FK auth_identities, responsible_name 120 em todas tabelas
- Métricas: crm_partner_metrics com referrals_count, converted_count, conversion_rate, total_value por período, UNIQUE por parceiro+período
- handleMetrics agrupa renovações por tipo/status com COUNT SUM new_value, indicações por status, parceiros total/ativos
- UI exibe métricas por responsável

## Validação
- npm test 46 pass 4 skipped
- npx next build ok 59 páginas (Next 16.3.6)
- migrate-site-visual 001-031

## Próximo
CON-01..CON-11 contratos e implantação, PLT-05..18
