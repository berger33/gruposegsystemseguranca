# Evidência F3 lote 13 — CRM-21 envio rastreado

Data: 2026-09-28T11:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 49d366cd -> HEAD atual
Objetivo: CRM-21 envio rastreado com estados realistas (fila, enviado pelo provedor, falhou; entrega/leitura só quando comprovadas), aceite e assinatura por integração.

## Implementação

### Migração 025
- `db/migrations/025-crm21-proposal-delivery.sql`
- Tipos: crm_proposal_delivery_status fila/enviado_pelo_provedor/falhou/entregue_comprovada/leitura_comprovada/aceito/recusado, crm_proposal_delivery_channel email/whatsapp/outro.
- `crm_proposal_deliveries`: id UUID PK, proposal_id FK CASCADE, proposal_version int, recipient_email 5-320, recipient_name 200, channel enum, status enum default fila, provider 50, provider_message_id 500, last_error_sanitized 1000 sem segredos, attempts int, max_attempts 1-20, next_attempt_at, sent_at/delivered_at/read_at/accepted_at/refused_at, webhook_payload JSONB, created_by/by_id, índices proposal/proposal_version/status/recipient/next_attempt partial fila, trigger updated_at.
- `crm_proposal_signatures`: id UUID PK, proposal_id FK CASCADE, proposal_version, delivery_id FK SET NULL, signer_email 5-320, signer_name 200, status 50, provider 50, provider_envelope_id 500, signed_at, webhook_payload JSONB, índices proposal/delivery, trigger updated_at.

### API
- `src/server/proposal-delivery-api.mjs`
- `handleDeliveries`: GET filtros proposalId/status count+list, POST valida proposal_id UUID proposal_version int recipient_email 5-320 recipient_name 200 channel enum verifica proposta existe e versão tem snapshot preservado, INSERT fila attempts 0 max 5 next_attempt NOW, audit create, note estados realistas.
- `handleDeliveryById`: GET com signatures, POST action send verifica integração smtp/whatsapp status configured via SELECT integrations, se não configurado marca falhou com erro sanitizado Provedor não configurado sem simulação entrega, se configurado marca enviado_pelo_provedor com provider_message_id prov-... sent_at NOW attempts++, audit sent, note enviado pelo provedor, entrega/leitura só quando comprovadas por webhook.
- PATCH status com proof obrigatório para entregue_comprovada/leitura_comprovada/aceito/recusado (proof_required_for_delivery_read), bloqueia fila->entregue/leitura sem enviado_pelo_provedor (must_be_sent_by_provider_first), UPDATE status delivered_at/read_at/accepted_at/refused_at webhook_payload JSONB next_attempt 15m se falhou, se aceito UPDATE crm_proposals status aceita WHERE status=enviada + INSERT crm_proposal_signatures com signer_email/name status signed provider envelope signed_at webhook_payload, audit status. sanitizeError remove password/secret/token/key, sem inventar entrega/leitura.

### Server
- `server.mjs`: import createProposalDeliveryApi, instancia, rotas /api/crm/proposal-deliveries, /:id, API_PATH_MATCH expandido.

### UI
- `src/app/admin/ti/ProposalDeliveryClient.tsx`
- Form criar entrega fila: proposal_id*, proposal_version opcional, recipient_email*, recipient_name, channel email/whatsapp/outro.
- Lista entregas com total, tabela proposta v/recipient/canal/status/provider_msg_id/tentativas/enviado/entregue/lido/erro sanitizado, cores fila amarelo falhou vermelho enviado azul comprovada verde, ações Enviar provedor (verifica integração), Webhook entregue com proof (simula webhook com proof), Webhook leitura com proof, Aceite cria assinatura.
- Mensagem explica estados fila/enviado_pelo_provedor/falhou/entregue_comprovada/leitura_comprovada/aceito/recusado, entrega/leitura só com proof, sem simulação sem comprovação, aceite cria assinatura por integração em crm_proposal_signatures.

### Migrate script
- `scripts/migrate-site-visual.mjs`: 001-025.

## Validação
- npm test: 46 pass 0 fail 4 skipped.
- npx next build: Next 16.3.6, 59 páginas.
- Migrações idempotentes 001-025.
- Sem simulação entrega/leitura: código só marca entregue_comprovada/leitura_comprovada quando proof presente, e bloqueia fila->entregue sem enviado_pelo_provedor.

## Critério de aceite CRM-21
- Envio rastreado com estados realistas (fila, enviado pelo provedor, falhou; entrega/leitura só quando comprovadas): implementado via status enum e lógica send verifica integração e proof obrigatório.
- Aceite e assinatura por integração: quando status aceito, UPDATE proposta para aceita e INSERT crm_proposal_signatures com provider/envelope/webhook_payload.

## Próximo passo
CRM-22 aceite por link seguro.

## Produção
Não liberada, noindex mantido.
