# F3 lote 5 — CRM-12 equipamentos

Data: 2026-09-28T07:30Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 762fdd1 (CRM-11) -> novo com CRM-12

## Objetivo
CRM-12: equipamentos: fabricante/modelo, especificações, compatibilidades, fornecedor, garantia e ligação com estoque. Não confundir serviço com item físico.

## Implementação

### Migração 017-crm12-equipment.sql
- `crm_equipment`: id TEXT PK 1-100, manufacturer 100, model 100, name 200, description 2000, specifications JSONB default {}, compatibilities JSONB default [], category 100, supplier_name 200, supplier_contact 200, warranty_months INT 1-120, stock_sku 100, stock_location 100, is_active bool default true, is_validated bool default false, validation_note TEXT, created_at, updated_at, índices manufacturer/model, category/active, active/validated, trigger updated_at
- 3 exemplos iniciais (não confundir serviço com item físico, aguardam validação técnica):
  - hikvision_ds-2ce56d0t: Hikvision DS-2CE56D0T-IRP, Câmera Dome 1080p IR, specs resolucao 1080p/lente 2.8mm/ir 20m/wdr DWDR/alimentacao 12V, compatibilidades DVR Hikvision Turbo HD/Fonte 12V 1A/Cabo coaxial, categoria camera, fornecedor padrão CFTV, garantia 12m
  - intelbras_vd_3104: Intelbras VD 3104, DVR 4 canais 1080p, specs canais 4+1/resolucao 1080p/compressao H.265/saida HDMI/VGA/armazenamento 1x SATA, compat câmeras Intelbras 1080p/HD 1TB/Fonte 12V, categoria dvr
  - control_id_idface: Control iD iDFace, Controle acesso facial, specs capacidade_faces 1500/conectividade TCP/IP WiFi/leitor facial+senha/saida rele 1, compat fechadura eletromagnética/Fonte 12V/Software iDCloud, categoria controle_acesso
- Ligação com estoque: stock_sku e stock_location, futura tabela ast_stock_movements referenciará equipment_id
- Auditoria: crm_equipment_create/update

### equipment-api.mjs
- `handleList` GET /api/crm/equipment?category=&manufacturer=&search=&includeInactive=&limit=&offset=: require admin session + sameOrigin + GET, conditions ILIKE category/manufacturer/search name/model/manufacturer, is_active true unless includeInactive, count e list ORDER BY manufacturer,model, limit/offset
- `handleGet` GET /api/crm/equipment/:id: retorna equipamento ou 404
- `handleCreate` POST /api/crm/equipment: id/manufacturer/model/name obrigatórios, id sanitizado lowercase _ , warranty 1-120, specifications object, compatibilities array, stock_sku/location, INSERT RETURNING *, audit create, 409 se exists

### server.mjs
- Importa createEquipmentApi, instancia equipmentApi, rotas /api/crm/equipment GET/POST e /api/crm/equipment/:id GET, API_PATH_MATCH expandido

### EquipmentClient.tsx (/admin/ti)
- Form criar equipamento com id, fabricante, modelo, nome, categoria, fornecedor, garantia meses
- Filtros categoria e busca nome/modelo/fabricante
- Lista cards com fabricante/modelo/categoria/fornecedor/garantia/SKU/local/descrição/specs JSON/compatibilidades, badges validado/aguarda validação, ativo
- Texto não confundir serviço (service_catalog) com item físico (crm_equipment) e ligação estoque via stock_sku/location futura ast_stock_movements

### scripts/migrate-site-visual.mjs
- 001-017, log All schemas (001-017)

## Validação
- npm test 46 pass 0 fail 4 skipped
- next build ok Next 16.3.6 54 páginas incluindo /admin/ti com EquipmentClient
- Equipamentos validados: 3 exemplos com fabricante/modelo/specs/compat/fornecedor/garantia

## Aceite CRM-12
- Fabricante/modelo: manufacturer, model
- Especificações: specifications JSONB
- Compatibilidades: compatibilities JSONB
- Fornecedor: supplier_name, supplier_contact
- Garantia: warranty_months
- Ligação com estoque: stock_sku, stock_location (ligação com AST futuro)
- Não confundir serviço com item físico: service_catalog (serviço) vs crm_equipment (item físico), texto explícito em UI e docs

## Bloqueios
- PG real ausente sandbox: migração idempotente
- Validação técnica dos equipamentos pendente D-02
- Ligação estoque completa depende de AST-01..12

## Próxima ação
- CRM-13 vistoria com checklist por serviço
- CRM-14/15 orçamentos mão de obra e técnico
- CRM-16..18 parâmetros tributos/custos/jornada versionados, cenários preço/margem, alçadas desconto
- CON-01..11 contratos e implantação
