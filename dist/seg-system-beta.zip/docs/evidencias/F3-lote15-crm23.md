# F3 lote 15 — CRM-23 proposta aceita cria contrato/implantação idempotente

Data: 2026-09-28T11:30Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 2d01400 (CRM-22)

## Requisito
CRM-23: proposta aceita cria contrato/implantação de modo idempotente; retries não duplicam cliente, contrato, postos ou faturamento.

## Implementação
### Migração 027
- `db/migrations/027-crm23-contract-idempotent.sql`
- Tipos: crm_contract_status rascunho/ativo/suspenso/encerrado/cancelado, crm_contract_origin manual/crm_proposal_acceptance/importacao, crm_implantation_status planejada/em_andamento/concluida/cancelada
- `crm_contracts` id UUID PK, proposal_id FK CASCADE, proposal_version int, UNIQUE(proposal_id,proposal_version), company_id/opportunity_id FK SET NULL, title 200, status ativo, origin crm_proposal_acceptance, version 1, total_cost/price 14,2, margin, validity_days/until, conditions 5000, notes 5000, idempotency_key UNIQUE 200 `proposal:UUID:vN`, created_by/by_id, índices proposal/company/status, trigger updated_at
- `crm_contract_items` id UUID PK, contract_id FK CASCADE, proposal_item_id FK SET NULL, type 50, description 500, equipment_id, quantity 12,2, unit 50, unit_cost/total_cost/unit_price/total_price 14,2, recurrence_type recorrente/avulso/implantacao/outro, recurrence_details 500, supplier 200, notes 500, UNIQUE(contract_id,proposal_item_id) evita duplicar postos, índices contract/type
- `crm_contract_implantations` id UUID PK, contract_id FK CASCADE UNIQUE, proposal_id FK CASCADE, proposal_version, status planejada, checklist JSONB default com itens contrato/data_inicio/postos/dimensionamento/contratacao_alocacao/exames_treinamentos/equipamentos/instrucoes/faturamento/convite_cliente, started_at, notes 2000, created_by/by_id, índices contract/status, trigger updated_at
- Auditoria: crm_contract_create, crm_contract_idempotent_hit, crm_contract_implantation_create

### API
- `src/server/contract-api.mjs`
- `createContractFromProposalInternal({pool, proposalId, proposalVersion, session, origin})`
  - Verifica proposta existe e status aceita, senão 409 proposal_not_accepted
  - Verifica snapshot preservado version_not_preserved_cannot_create_contract
  - idempotencyKey `proposal:UUID:vN`
  - SELECT existente retorna isNew false idempotent hit audit crm_contract_idempotent_hit
  - Senão BEGIN, SELECT FOR UPDATE double-check race, SELECT proposal_items, INSERT crm_contracts title total_cost/price margin validity conditions notes idempotency_key created_by, INSERT crm_contract_items copia proposal_items ON CONFLICT (contract_id,proposal_item_id) DO NOTHING (evita duplicar postos), INSERT crm_contract_implantations checklist default ON CONFLICT (contract_id) DO NOTHING, COMMIT audit create
- `handleContracts` GET filtros proposalId/company/status count+list limit 200, POST proposal_id UUID version chama internal idempotente retorna 201 novo 200 existente isNew idempotent note retries não duplicam
- `handleCreateFromProposal` POST proposal_id version idempotente
- `handleContractById` GET contract+items+implantation+proposal PATCH status/notes
- `handleImplantationByContract` GET/PATCH status/checklist/started_at/notes

- `proposal-acceptance-api.mjs` POST aceita link agora cria contrato idempotente após aceite com BEGIN FOR UPDATE copia itens e implantação checklist, audit idempotent_hit/create, retorna contract info
- `proposal-api.mjs` PATCH aceita cria contrato idempotente mesmo fluxo
- `proposal-delivery-api.mjs` PATCH aceito cria contrato idempotente

- `server.mjs` rotas `/api/crm/contracts`, `/:id`, `/:id/implantation`, `/from-proposal`, API_PATH_MATCH expandido

### UI
- `src/app/admin/ti/ContractClient.tsx`
- Form criar contrato idempotente da proposta aceita proposal_id/version
- Lista contratos id/proposta v/título/status/origem/idempotency_key/preço/criado
- Ações Ver detalhe (mostra itens e checklist implantação) e Retry idempotente (chama mesmo endpoint, não duplica)
- Detalhe itens e checklist implantação JSON

## Idempotência
- UNIQUE(proposal_id, proposal_version) + UNIQUE(idempotency_key) garante contrato único por proposta+versão
- UNIQUE(contract_id, proposal_item_id) evita duplicar postos/itens em retries
- UNIQUE(contract_id) em implantation evita duplicar implantação
- BEGIN + SELECT FOR UPDATE double-check evita race condition em retries concorrentes
- Retries retornam contrato existente com isNew false, audit crm_contract_idempotent_hit
- Cliente não duplicado: company_id reutilizado da proposta, não cria novo client_account automaticamente; se criar no futuro, deve usar mesma idempotency
- Faturamento não duplicado: implantação e itens com ON CONFLICT DO NOTHING, futuros FIN com contract_id+competência UNIQUE

## Validação
- npm test 46 pass 4 skipped
- npx next build ok 59 páginas (Next 16.3.6)
- migrate-site-visual 001-027

## Próximo
CRM-24..27 relatórios, metas comissões, CON-01..CON-11 contratos e implantação, PLT-05..18
