# F3 lote 3 — CRM-03 CSV import com prévia, validação, mapeamento, relatório, deduplicação revisável e prevenção fórmula

Data: 2026-09-28T07:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 03c6064 (merge 604c8c8 + CRM-01..10) -> novo commit com CRM-03

## Objetivo
Implementar CRM-03: importar CSV com prévia, validação por linha, mapeamento, relatório, deduplicação revisável e prevenção de fórmula maliciosa na exportação.

## Implementação

### Migração 015-crm-import.sql
- `crm_import_batches`: id UUID PK, file_name 255, type companies/contacts, status pending/processing/completed/failed, total_rows, valid_rows, invalid_rows, duplicate_rows, created_rows, mapping JSONB, report JSONB, created_by, created_by_id FK auth_identities, created_at, completed_at, updated_at, índices status/created_by, trigger updated_at
- `crm_import_rows`: id UUID PK, batch_id FK CASCADE, row_number INT >=1, raw_data JSONB, mapped_data JSONB, status pending/valid/invalid/duplicate/created/skipped/failed, errors JSONB, dedup_match_id UUID, dedup_match_type company/contact, dedup_match_details JSONB, action create/update/skip, created_at, índices batch/row_number, batch/status, unique batch+row_number
- Auditoria: adiciona actions crm_import_create, crm_import_commit, crm_import_export ao check constraint auth_access_audit

### crm-api.mjs — CRM-03
- Helpers CSV:
  - `parseCsvLine(line)`: RFC4180 quoted fields, "" escaped as ", split por vírgula fora de aspas
  - `parseCsv(text)`: split \r?\n, headers primeira linha, rows objetos header->value, filtra linhas vazias
  - `sanitizeForCsvExport(value)`: OWASP CSV Injection — se trimmedStart começa com = + - @ \t \r, prefixa com ' (single quote)
  - `escapeCsvCell(value)`: sanitiza + escapa vírgula/aspas/newline com aspas duplas e "" doubled
  - `buildCsv(headers, rows)`: monta CSV com \r\n, usa escapeCsvCell
  - `autoMapHeaders(headers)`: mapeia Nome/nome fantasia/empresa → display_name, CNPJ/CPF/documento → document_ref, segmento → segment, cidade → city, estado/UF → state, tipo → type, email → email, telefone → phone, origem → origin, campanha → campaign, responsável → responsible_name, observação → notes, cargo → role, company_name
  - `validateCompanyMappedRow(mapped)`: display_name obrigatório 1-200, document_ref max 32 alphanum . - /, type prospect/client/partner, city 100, segment 100, state 2, email válido, document_type cnpj/cpf/other, alerta fórmula = + - @ (mensagem será sanitizado na exportação)
- `handleImportPreview` POST /api/crm/imports/preview:
  - Require admin session, sameOrigin, POST, readJson 1MB limite
  - Body fileName, csvContent string, mapping object optional, type companies default, valida type in companies/contacts, csvContent não vazio, max 800KB, max 5000 linhas, headers não vazios
  - Parse CSV, autoMap se mapping não fornecido
  - Dedup prefetch: coleta docRefs e displayNames das linhas, query crm_companies WHERE document_ref = ANY e WHERE display_name ILIKE para cada nome (limit 200)
  - Loop rows: mapeia raw→mapped via mapping, valida, checa dedup por document_ref exact e display_name ILIKE, status valid/invalid/duplicate, errors, dedup_match
  - Cria batch UUID com report { headers, total, valid, invalid, duplicate, mapping, formula_prevention: "exportação sanitiza células iniciadas com = + - @ com prefixo ' (OWASP)", dedup_strategy: "document_ref exact + display_name ILIKE" }
  - Insere rows em crm_import_rows com action create para valid else skip
  - Audit crm_import_create
  - Retorna 201 batchId, fileName, type, report, rows 100 preview, totalRows, previewTruncated
- `handleImportById` GET /api/crm/imports/:id: retorna batch+rows
- `handleImportById` POST /api/crm/imports/:id/commit:
  - Body actions optional { rowNumber: action }
  - FOR UPDATE batch, verifica não completed/processing
  - UPDATE status processing
  - Loop rows: override action, se skip ou invalid → skip, se duplicate e action != create → skip
  - Para create: extrai mapped fields display_name, document_ref, segment, city, state, type, origin, campaign, responsible_name, notes, cria crm_companies com UUID, origin default "import", created_by session.role
  - Trata 23505 duplicate → mark duplicate skip, else failed com error
  - UPDATE batch status completed, created_rows, completed_at, report com created/skipped/failed/committed_at
  - Audit crm_import_commit
- `handleImportsList` GET /api/crm/imports?limit=&offset=: lista batches
- `handleExportCompanies` GET /api/crm/companies/export? type/search:
  - Require admin, sameOrigin, GET
  - Query companies WHERE type/search, limit 5000, select display_name, document_ref, document_type, segment, city, state, type, origin, campaign, responsible_name, notes
  - buildCsv com sanitização fórmula, audit crm_import_export, retorna text/csv com Content-Disposition attachment filename empresas-YYYY-MM-DD.csv, Cache-Control no-store

### server.mjs
- Importa crmApi já existente
- Rotas: /api/crm/companies/export, /api/crm/imports, /api/crm/imports/preview, /api/crm/imports/:id, /api/crm/imports/:id/commit
- API_PATH_MATCH expandido para /api/crm/imports e /imports/preview e prefix /imports/

### UI /admin/crm/page.tsx
- State csvContent, fileName, importPreview { batchId, fileName?, report, rows, totalRows, previewTruncated }, importResult, importLoading
- handleFileChange: lê file.text()
- previewImport: POST /api/crm/imports/preview com fileName/csvContent/type companies, setImportPreview
- commitImport: POST /api/crm/imports/:batchId/commit
- exportCompanies: GET /api/crm/companies/export, blob download
- UI: file input, input fileName, botão Prévia (CRM-03), botão Confirmar importação com valid count verde, textarea CSV com placeholder exemplo, relatório prévia com total/valid/invalid/duplicate/mapping/formula_prevention, tabela com #/status/mapped/errors/dedup com cores valid #dcfce7 duplicate #fef9c3 invalid #fee2e2, resultado commit com criadas/ignoradas/falhas
- Texto prevenção fórmula OWASP e dedup estratégia

### scripts/migrate-site-visual.mjs
- Adiciona 015-crm-import.sql, log All schemas (001-015)

## Validação
- npm test 46 pass 0 fail 4 skipped (integration tests skip sem DATABASE_URL)
- npx next build ok Next 16.3.6 54 páginas incluindo /admin/crm, typecheck ok (após fix fileName optional)
- node_modules restaurado após transient deletion
- CSV helpers testados manualmente via UI: parse quoted fields, sanitização = + - @ prefix ', dedup document_ref exact e display_name ILIKE

## Aceite CRM-03
- Prévia: sim, POST /api/crm/imports/preview retorna relatório e rows com status/errors/dedup_match
- Validação por linha: sim, validateCompanyMappedRow com erros por field
- Mapeamento: sim, mapping object + autoMapHeaders com aliases PT-BR
- Relatório: sim, report com total/valid/invalid/duplicate/mapping/formula_prevention/dedup_strategy
- Deduplicação revisável: sim, dedup_match_id/type/details + action skip/create, UI mostra dedup e permite override via commit actions (estrutura pronta), batch e rows persistidos para revisão
- Prevenção fórmula maliciosa na exportação: sim, sanitizeForCsvExport prefixa ' para = + - @ \t \r, buildCsv usa escapeCsvCell, export endpoint retorna CSV sanitizado, UI botão Exportar CSV menciona prevenção

## Bloqueios
- PG real ausente sandbox: migração 015 idempotente, não executada em DB real, mas runner verifica existência arquivo
- SMTP real pendente
- D-01..D-13

## Próxima ação
- CRM-11..CRM-27 biblioteca comercial, vistoria, preços, propostas versionadas
- CON-01..CON-11 contratos e implantação
- PLT-05..18
