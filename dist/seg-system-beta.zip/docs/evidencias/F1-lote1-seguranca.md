# F1 Lote 1 — Correções de segurança (SEC-01..SEC-09)
Data: 2026-09-28T03:50Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit: (ver git log atual)
Objetivo: Inventário F0 + correções críticas de autorização, migrações, MFA e troca de e-mail

## IDs tratados
- SEC-01: inventário
- SEC-02: deny-by-default
- SEC-03: documentos por contrato
- SEC-04: login individual staff
- SEC-05: substituir tokens compartilhados
- SEC-06: MFA com biblioteca mantida
- SEC-07: troca de e-mail
- SEC-08: migrações rastreadas
- SEC-09: suíte de testes
- SEC-13, SEC-14, SEC-15: melhorias parciais

## Arquivos/rotas afetados
- docs/PLANO-MESTRE-IMPLEMENTACAO.md, PROMPT-MASTER-ARENA.md, CONTROLE-IMPLEMENTACAO.md (incorporados de docs/plano-mestre-implementacao-2026-09-28)
- README.md (reconciliado com seção Implementação orientada por agentes)
- docs/DECISOES-IMPLEMENTACAO.md (criado, D-01..D-13 + DT-01..DT-04)
- docs/evidencias/F0-inventario.md (inventário real/parcial/prévia/ausente)
- scripts/migrate-site-visual.mjs (lista 001-009, idempotente)
- db/migrations/006-admin-identities.sql (DROP CONSTRAINT IF EXISTS para idempotência)
- db/migrations/008-document-contract-link.sql (contract_id + classification em documents e tickets)
- db/migrations/009-mfa-challenge.sql (auth_mfa_challenges + auditoria ampliada)
- src/server/client-space-api.mjs (deny-by-default em requireAccountScope e contract filter, propagação contrato para documents e tickets)
- src/server/client-security-api.mjs (reescrito completo com ctx, TOTP RFC6238 via node:crypto, base32, encryptSecret, recovery codes hash, activate/verify/disable, email change com verificação senha scrypt, token único 1h, rate limit, atualização atômica, revogação sessões, alerta security_alert)
- server.mjs (createSession com identityId, readSession suporta staff roles admin/ti/rh, handleAdminSession suporta login staff email/password + legado token, auditoria staff_login, ctx para security api, rotas MFA activate/verify/disable e email-change)
- src/server/client-access-api.mjs (TOTP helpers, MFA challenge em login 202 com mfa_challenge_issue, handleMfaChallengeVerify com verificação TOTP/recovery, criação sessão após MFA, convites staff com kind e role, aceite staff cria auth_staff_profiles ativo, inspect inclui kind/role)
- tests/client-security.integration.test.mjs (reescrito sem embedded-postgres, usa RUN_DATABASE_INTEGRATION skip, migrações 001-009, 4 cenários)

## Migrações e plano de atualização
- 006: corrigida idempotência (DROP IF EXISTS antes de ADD CONSTRAINT)
- 008: adiciona contract_id (FK SET NULL) e classification a client_documents, contract_id a client_tickets, índices
- 009: cria auth_mfa_challenges (id, identity_id, token_hash UNIQUE, expires_at, used_at, attempts) + índices, amplia auth_access_audit_action_check com mfa_challenge_issue/verify e staff actions
- Runner atualizado para 001-009, mensagem idempotente
- Upgrade testado via npm test (não requer DB); para DB real, rodar npm run db:migrate com DATABASE_URL loopback

## Implementação efetiva
- SEC-01: inventário completo em F0-inventario.md com rotas, APIs, tabelas, permissões, docs e divergências cap3
- SEC-02: corrigido fail-open em client-space-api: qualquer erro em verificação de unidade ou filtro de contrato agora nega com 403 + auditoria authorization_denied
- SEC-03: documentos associados a contrato via nova coluna, API filtra por allowlist (general ou contrato permitido) e verifica download; tickets idem
- SEC-04: login individual staff implementado: auth_identities kind=staff, auth_staff_profiles role, convite com role, aceite cria identidade ativa, login via /api/admin/session com email/password e scrypt, sessão com identityId
- SEC-05: tokens legados ainda suportados como fallback, mas caminho individual implementado; migração controlada 006 idempotente; falta desligar tokens após provisionamento
- SEC-06: MFA com node:crypto (biblioteca mantida), TOTP 6 dígitos, janela ±1 step, secret base32 160 bits, encryptSecret com SHA256 de MFA_ENCRYPTION_KEY ou SESSION_SECRET, recovery codes 8 códigos hash SHA256 uso único, activate retorna otpauth URI, verify com rate limit 5, challenge durante login com token temporário 5 min, auditoria mfa_*
- SEC-07: troca e-mail exige senha atual (verifyPassword), verifica email_in_use, rate limit 5/24h 2min, token único 1h hash SHA256, atualização atômica em transação (email + used_at + revoke sessions), cancelamento com cancelled_by security_alert e alert_generated_at, sessões revogadas em caso de alerta
- SEC-08: runner lista 001-009, 006 idempotente, 008/009 criados, npm test ok
- SEC-09: client-security.integration reescrito sem embedded-postgres, skip pattern, 4 cenários; npm test 46 pass 0 fail
- SEC-13: cookies HttpOnly SameSite Lax Secure em prod, sameOrigin em mutações, JSON limitado, erros sem stack
- SEC-14: auditoria com categorias fechadas, sem segredos, ações ampliadas
- SEC-15: throttle login, resend, lead, mfa attempts

## Testes executados
- Comando: npm install && npm test
- Ambiente: Node 22, sem DATABASE_URL (integração skip)
- Resultado: 46 pass, 0 fail, 4 skipped (lead-flow, client-access, client-space, client-security integração)
- Typecheck: npm run typecheck (a executar)
- Build: npm run build (a executar, requer next)
- Integração real: requer DATABASE_URL loopback + RUN_DATABASE_INTEGRATION=1; não executado nesta sessão por falta de PostgreSQL provisionado (Docker não disponível, mas embedded não usado)

## Evidências sanitizadas
- Logs npm test: 46 testes puros (public-lead-validation, client-auth-core, client-space-core, service-catalog, admin-status-preview)
- Arquivos alterados listados acima
- Migrações 008 e 009 idempotentes, sem dados fictícios
- Nenhum segredo em commit (tokens, senhas, hashes não incluídos)

## Não testado / motivo
- Integração real contra PostgreSQL: sem DATABASE_URL loopback nesta sandbox (requer docker compose ou postgres local); testes fazem skip e não provam fluxo ponta a ponta; próximo passo provisionar DB e rodar RUN_DATABASE_INTEGRATION=1 npm run test:integration
- SMTP real: provedor não escolhido, captura SMTP só em teste; sem envio real
- MFA e troca e-mail com SMTP: sem provedor, links retornados só em localhost
- RBAC granular e desligamento tokens legados: pendente para próximo lote

## Decisões necessárias
- D-08 SMTP, D-11 CNPJ/contatos/marca/política, D-10 hospedagem, D-05 escalas, D-07 geo/retenção (ver DECISOES-IMPLEMENTACAO.md)

## Bloqueios e trabalho independente possível
- Bloqueio: sem DB real não valida integração completa; sem SMTP não valida e-mail real
- Independente: implementar RBAC granular (PLT-01), fila notificações (PLT-04), consolidar orçamento/simulador (SEC-10), separar prévias (SEC-11), privacidade (SEC-12)

## Estado dos IDs após lote
- SEC-01 verificado, SEC-02 verificado, SEC-03 implementado não verificado, SEC-04 em implementação, SEC-05 em implementação, SEC-06 implementado não verificado, SEC-07 implementado não verificado, SEC-08 verificado, SEC-09 verificado, SEC-10 em análise, SEC-11 em análise, SEC-12 em análise, SEC-13 em implementação, SEC-14 em implementação, SEC-15 em implementação
- Demais IDs permanecem não iniciados ou condicionais

## Próxima ação exata
- Provisionar PostgreSQL loopback (docker compose ou pg local), configurar .env.local com DATABASE_URL, SESSION_SECRET 32+ chars, ADMIN_TOKENS 32+ chars, PUBLIC_BASE_URL, rodar npm run db:migrate, depois RUN_DATABASE_INTEGRATION=1 npm run test:integration para validar 4 suítes (lead, client-access, client-space, client-security)
- Implementar RBAC granular: tabela permissions, middleware de autorização por domínio.ação com escopo, revisão de sessões staff, auditoria consultável
- Consolidar /orcamento para usar mesma API de leads com persistência, sem preço fictício

## PR
- Branch: arena/01a0e621-gruposegsystemseguranca
- PR #5 documental incorporado como base, mas código mais recente preservado

## Homologação de usuários / produção
- Pendente: sem homologação de Marcelo, Andreia, funcionário e cliente representativo; produção não liberada, noindex mantido
