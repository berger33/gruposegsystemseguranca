# F3 lote 18 — CRM-26 biblioteca comercial, apresentações/cases aprovados, campanhas segmentadas e comparação de propostas

Data: 2026-09-28T12:15Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 2a61ce0 (CRM-25)

## Requisito
CRM-26: biblioteca comercial, apresentações/cases aprovados, campanhas segmentadas e comparação de propostas.

## Implementação
### Migração 030
- `db/migrations/030-crm26-commercial-library.sql`
- Tipos: crm_library_type apresentacao/case/documento/video/planilha/imagem/outro, crm_library_status rascunho/em_revisao/aprovado/rejeitado/arquivado, crm_campaign_status rascunho/ativa/pausada/encerrada/cancelada, crm_campaign_segment setor/cidade/tipo_empresa/campanha/origem/responsavel/outro
- `crm_commercial_library` id UUID PK, title 200, type, description 2000, category 100, tags JSONB, file_url 1000, storage_key 200, status rascunho/em_revisao/aprovado/rejeitado/arquivado, version 1, approved_by/by_id/at/role, rejection_reason 500, created_by/by_id, índices type_status/category/created_at, trigger
- `crm_campaigns` id UUID PK, name 200, description 2000, segment_type, segment_filter JSONB, status rascunho/ativa/pausada/encerrada/cancelada, start_date/end_date, target_count, library_ids JSONB, created_by/by_id, índices status/segment/created_at, trigger
- `crm_campaign_targets` id UUID PK, campaign_id FK CASCADE, company_id/contact_id FK SET NULL, status pendente/enviado/respondido/convertido/descartado, notes 500, UNIQUE(campaign_id,company_id,contact_id), índices campaign/company
- `crm_proposal_comparisons` id UUID PK, title 200, proposal_ids JSONB 2-5, comparison_data JSONB, notes 2000, created_by/by_id, índices created_at, trigger
- Auditoria crm_library_create/update/approve/reject, crm_campaign_create/update/status, crm_proposal_comparison_create

### API
- `src/server/commercial-api.mjs`
- `handleLibrary` GET filtros type/status/category count+list, POST title 200 type enum description 2000 category 100 tags 20 file_url 1000 INSERT rascunho version 1
- `handleLibraryById` GET/PATCH title/description/category/tags/file_url/status rascunho/em_revisao/aprovado/rejeitado/arquivado version++ approved_by/at/role rejection_reason required para rejeitado audit approve/reject
- `handleCampaigns` GET filtros status/segment_type count+list, POST name 200 description 2000 segment_type setor/cidade/tipo_empresa/campanha/origem/responsavel/outro segment_filter JSONB start_date/end_date library_ids 20 UUIDs INSERT rascunho
- `handleCampaignById` GET campaign+targets 100, PATCH name/description/segment_filter/library_ids/status/start_date/end_date
- `handleCampaignTargets` GET list 200, POST company_id/contact_id UUID company_or_contact_required INSERT ON CONFLICT (campaign_id,company_id,contact_id) DO NOTHING idempotente
- `handleComparisons` GET limit 50, POST title 200 proposal_ids 2-5 UUIDs verifica propostas existem SELECT IN placeholders, busca itens versão atual para cada proposta, comparison_data {proposals:[id,title,status,version,total_cost,total_price,margin,validity,scope,items,items_count], summary {min_price,max_price,price_range,count}} INSERT
- `handleComparisonById` GET

- `server.mjs` rotas `/api/crm/commercial-library`, `/:id`, `/api/crm/campaigns`, `/:id`, `/:id/targets`, `/api/crm/proposal-comparisons`, `/:id`

### UI
- `src/app/admin/ti/CommercialLibraryClient.tsx`
- Forms criar biblioteca title/type/category/file_url/tags/description lista com aprovar
- Criar campanha name/segment_type/segment_filter JSON/start_date/end_date/description lista
- Criar comparação title/proposal_ids vírgula lista com min/max/range

## Validação
- npm test 46 pass 4 skipped
- npx next build ok 59 páginas (Next 16.3.6)
- migrate-site-visual 001-030

## Próximo
CRM-27 parcerias e indicações, CON-01..CON-11 contratos e implantação, PLT-05..18
