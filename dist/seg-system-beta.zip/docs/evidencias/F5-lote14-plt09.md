# F5 Lote 14 — PLT-09 Privacidade Completa — Evidência

Data: 2026-09-29T01:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Base: 5b53690 (PLT-08)

## Objetivo PLT-09
Política de privacidade completa, inventário de dados/finalidades, bases aplicáveis, destinatários, prazos, contatos e direitos; revisão competente antes de publicar.

## Migração 047
- Enums: data_category identificacao/contato/localizacao/profissional/financeiro/tecnico/comportamental/sensivel/outro, legal_basis consentimento/execucao_contrato/cumprimento_legal/legitimo_interesse/protecao_vida/tutela_saude/exercicio_direitos/protecao_credito/outro, policy_status rascunho/em_revisao/aprovado/publicado/arquivado/rejeitado
- Tabelas:
  - privacy_data_inventory: data_category, data_field 100, description 1000, purpose 1000, legal_basis, legal_basis_detail 1000, retention_days 1..3650, retention_description 1000, recipients TEXT[], is_sensitive bool, is_required bool, source 200, created_by/by_id, UNIQUE(category,field), índices category/basis, trigger
  - privacy_policies: version UNIQUE, status, title 200, content 20000, inventory_snapshot JSONB, contact_email 320, dpo_name 200, dpo_contact 500, retention_summary 2000, rights_description 2000, recipients_description 2000, is_published bool, published_at, approved_by/at, rejection_reason 1000, created_by/by_id, índices status/published, trigger
- Seed inventory 10 itens: nome, telefone, email, cidade, cargo_funcao, servicos_interesse, origem_campanha, cftv_imagem sensível, geolocalizacao sensível, documento_fiscal + seed policy v1 rascunho minuta técnica
- Auditoria: privacy_inventory_create/update, policy_create/update/approve/publish/reject

## API privacy-api.mjs
- DATA_CATEGORIES 9, LEGAL_BASES 9, POLICY_STATUSES 6, sanitizeText max
- handleInventory: sameOrigin session, GET filtros category basis sensitive SELECT ORDER BY category field note inventário minimização, POST/PUT admin/ti restrito data_category data_field description purpose legal_basis legal_basis_detail retention_days retention_description recipients is_sensitive is_required source upsert ON CONFLICT category+field audit create
- handlePolicies: sameOrigin session, GET filtros status published SELECT ORDER BY version DESC LIMIT 50 + inventory snapshot SELECT * ORDER BY category field, note inventário revisão competente noindex até publicado, POST admin/ti title content contact_email dpo_name dpo_contact retention_summary rights_description recipients_description version MAX+1 inventory_snapshot rascunho audit create
- handlePolicyById: UUID, sameOrigin session, GET policy, PATCH title content contact_email dpo_name dpo_contact retention_summary rights_description recipients_description status approval admin required must_be_approved_before_publish is_published published_at approved_by/at rejection_reason audit approve/publish/reject/update

- Rotas server.mjs: /api/admin/privacy/inventory /crm/privacy/inventory /privacy/inventory, /api/admin/privacy/policies /crm/privacy/policies /privacy/policies /privacy /:id, API_PATH_MATCH expandido privacy

## UI PrivacyClient (TI)
- load fetch inventory + policies, inventory list category field sensível obrigatório base finalidade retenção dest fonte, form novo inventário category legal_basis field description purpose ret days recipients ret desc sensível obrigatório, policies list version status publicado title content 300 contato DPO retenção direitos dest approved_by rejection_reason transição em_revisao/aprovado/publicado/arquivado/rejeitado, form nova política title content contact DPO retention rights recipients rascunho

## /privacidade page
- Client component useEffect fetch published policies + inventory
- Aviso: se policy is_published mostra publicada v approved_by, senão minuta pendente noindex
- Exibe policy title content contato DPO retenção direitos destinatários
- Inventário completo categoria campo sensível finalidade base retenção dest fonte
- Retenção expandida backups 90/365d criptografados, direitos 15 dias, segurança RBAC sessão HttpOnly observabilidade, templates sem info médica, noindex até publicado

## Validação
- npm test 46 pass 4 skipped
- npx next build 59 páginas OK
- migrate-site-visual 001-047

## Próximos
- PLT-10 pedidos acesso/correção/eliminação LGPD verificação identidade responsável prazo impedimentos
- PLT-11 retenção por categoria descarte jobs verificáveis retenção excepcional formal histórico minimizado
- PLT-12 resposta incidente
- PLT-13..18
