# F3 lote 4 — CRM-11 catálogo recorrente/avulso/instalação/manutenção/venda/locação/comodato

Data: 2026-09-28T07:15Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 0e73a17 (CRM-03) -> novo com CRM-11

## Objetivo
CRM-11: separar serviços recorrentes/avulsos, instalação, manutenção, venda, locação/comodato quando praticados. Campos: unidade de cobrança, escopo, exclusões, recursos, custo, preço, vigência e aprovação.

## Implementação

### Migração 016-crm11-catalog-enrichment.sql
- ALTER TABLE service_catalog ADD:
  - service_type TEXT enum recorrente/avulso/instalacao/manutencao/venda/locacao/comodato/outro DEFAULT recorrente
  - billing_unit TEXT 100 (ex: por_posto_mensal, mensal, por_projeto, por_area_mensal, por_visita)
  - scope_description TEXT 2000
  - exclusions TEXT 2000
  - resources TEXT 2000
  - resources_json JSONB default []
  - cost NUMERIC(12,2) >=0
  - price NUMERIC(12,2) >=0
  - validity_days INT 1-365
  - approval_status TEXT enum rascunho/em_revisao/aprovado/arquivado DEFAULT aprovado
  - approved_by UUID FK auth_identities, approved_by_role TEXT, approved_at TIMESTAMPTZ
  - version INT >=1 DEFAULT 1
  - currency TEXT BRL default
  - is_recurring BOOLEAN default true
- Índices: service_type + is_published + approval_status, approval_status + updated_at
- UPDATE 6 serviços existentes:
  - seg_desarmada: recorrente, por_posto_mensal, escopo presença preventiva/rondas/controle acesso básico/apoio ocorrências, exclusões sem armada/escolta/valores, recursos profissional/uniforme/rádio/livro, validity 30, aprovado, recorrente true
  - monitoramento_24h: recorrente, mensal, escopo acompanhamento 24h/acionamento/registro/SLA, exclusões sem intervenção garantida sem equipe local, recursos central/software/equipe, 30d
  - cftv: instalacao, por_projeto, escopo projeto/dimensionamento/venda/instalação/configuração/treinamento, exclusões sem obra civil pesada/infra elétrica principal/licenças/garantia estendida sem contrato, recursos câmeras/DVR/cabeamento/fontes/mão obra, is_recurring false
  - portaria: recorrente, por_posto_mensal, escopo rotinas entrada/saída/identificação/encomendas/atendimento, exclusões sem segurança armada/limpeza/manutenção, recursos porteiro/uniforme/livro/rádio
  - limpeza: recorrente, por_area_mensal, escopo limpeza/conservação por área/frequência/materiais/equipamentos/supervisão, exclusões sem altura sem EPI/tratamento pisos/segurança, recursos auxiliar/materiais/equipamentos/supervisão
  - supervisao: recorrente, mensal, escopo visitas programadas/verificação/apoio/registro, exclusões sem cobertura posto/substituição automática, recursos supervisor/veículo/checklist/relatório
- INSERT 2 exemplos rascunho não publicados aguardando validação comercial (D-02):
  - cftv_manutencao: manutencao, por_visita, rascunho, não recorrente, exemplo CRM-11
  - controle_acesso_locacao: locacao, mensal, rascunho, recorrente, locação/comodato

### service-catalog.mjs
- Cada um dos 6 serviços agora tem serviceType, billingUnit, scope, exclusions, resources, validityDays 30, approvalStatus aprovado, isRecurring true/false, version 1, cost null, price null, currency BRL
- Helpers: getServicesByType(serviceType), getRecurringServices(), getOneTimeServices()

### service-catalog-api.mjs
- handleList: SELECT novos campos, filtros serviceType e approvalStatus validados com 400 se inválido, conditions dinâmicas com valores parametrizados, fallback filtra por serviceType/approvalStatus
- handleGet: retorna novos campos
- Total/source

### service-catalog.d.mts
- CatalogService interface expandida com serviceType, billingUnit, scope, exclusions, resources, resourcesJson, validityDays, approvalStatus, isRecurring, version, cost, price, currency
- Declarações getServicesByType, getRecurringServices, getOneTimeServices

### CatalogClient.tsx (/admin/ti)
- Filtro select serviceType todos/recorrente/avulso/instalacao/manutencao/venda/locacao/comodato/outro
- Exibe badges tipo, recorrente, aprovação, unidade cobrança, vigência, versão, escopo, exclusões, recursos, custo/preço/moeda
- Total serviços, nota 6 validados + 2 exemplos rascunho aguardando validação comercial

### /servicos/page.tsx
- Título PUB-01 + CRM-11
- Exibe tipo, unidade cobrança, vigência, aprovação, versão, escopo, exclusões, recursos
- Descrição menciona separação por tipo recorrente/avulso/instalação/manutenção/venda/locação/comodato com unidade cobrança, escopo, exclusões, recursos, vigência e aprovação

### scripts/migrate-site-visual.mjs
- 001-016, log All schemas (001-016)

## Validação
- npm test 46 pass 0 fail 4 skipped
- next build ok Next 16.3.6 54 páginas incluindo /servicos, /admin/ti, /admin/crm
- node_modules restaurado após transient deletion
- Catálogo validado: 6 serviços publicados validados com service_type e billing_unit distintos, 2 exemplos rascunho não publicados

## Aceite CRM-11
- Separar serviços recorrentes/avulsos/instalação/manutenção/venda/locação/comodato: sim, service_type enum 8 valores, exemplos recorrente (seg_desarmada, monitoramento_24h, portaria, limpeza, supervisao), instalacao (cftv), manutencao (cftv_manutencao), locacao (controle_acesso_locacao)
- Campos unidade cobrança: billing_unit (por_posto_mensal, mensal, por_projeto, por_area_mensal, por_visita)
- Escopo: scope_description 2000
- Exclusões: exclusions 2000
- Recursos: resources 2000 + resources_json
- Custo, preço: cost, price numeric 12,2
- Vigência: validity_days 1-365
- Aprovação: approval_status rascunho/em_revisao/aprovado/arquivado + approved_by/at/role + version

## Bloqueios
- PG real ausente sandbox: migração 016 idempotente
- D-02 validação comercial para novos serviços (cerca elétrica, manutenção, locação) mantida pendente
- Custo/preço null até parâmetros aprovados D-06 (nenhuma alíquota inventada)

## Próxima ação
- CRM-12 equipamentos: fabricante/modelo, especificações, compatibilidades, fornecedor, garantia, ligação estoque
- CRM-13 vistoria com checklist por serviço
- CRM-14/15 orçamentos mão de obra e técnico
- CRM-16..18 parâmetros tributos/custos/jornada versionados, cenários preço/margem, alçadas desconto
- CON-01..11 contratos e implantação
