# F4 lote 06 — CON-06 obrigações documentais

Data: 2026-09-28T17:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit: aec67c1 -> atual (CON-06)

## Requisito
CON-06: obrigações documentais por cliente/contrato com categoria, periodicidade, responsável, aprovação e comprovante.

## Implementação

### Migração 037
- `db/migrations/037-con06-document-obligations.sql`
- Enums: `crm_doc_obligation_category` certidao/alvara/licenca/comprovante/contrato/atestado/seguro/treinamento/outro, `crm_doc_obligation_periodicity` unica/mensal/trimestral/semestral/anual/sob_demanda/outro, `crm_doc_obligation_status` pendente/em_analise/aprovado/rejeitado/vencido/cancelado
- Tabela `crm_document_obligations`:
  - `id PK`, `contract_id FK CASCADE`, `company_id FK CASCADE`, CHECK pelo menos um
  - `title 200`, `category`, `description 1000`
  - `periodicity`, `responsible_id FK`, `responsible_name 1..120`
  - `status` default pendente
  - `due_date DATE`, `last_submitted_at TIMESTAMPTZ`, `next_due_date DATE`
  - `file_url 1000`, `storage_key 200` — comprovante
  - `approved_by`, `approved_by_id`, `approved_at`, `rejection_reason 1..1000`
  - `created_by`, `created_by_id`, `created_at`, `updated_at`
  - Índices: contract/status/due, company/category/status, responsible/status, due/status where pendente/em_analise, category/periodicity
  - Trigger updated_at
  - CHECK due_date/next_due_date
- Tabela `crm_document_obligation_history`:
  - `id PK`, `obligation_id FK CASCADE`, `contract_id FK`, `company_id FK`
  - `previous_status`, `next_status`, `file_url`, `reason`, `changed_by`, `changed_by_id`, `created_at`
  - Índices obligation/created, contract/created
- Auditoria: doc_obligation_create/update/approve/reject/submit

### API contract-doc-obligation-api.mjs
- `handleObligations` GET `/api/crm/contracts/:id/doc-obligations` lista, POST cria:
  - Body: title, category, description, periodicity, responsible_name/id, due_date, file_url, company_id opcional (usa contrato company_id se não informado)
  - Valida category, periodicity, responsible_required, contract ou company
  - Calcula next_due_date via `calcNextDue`: mensal +1m, trimestral +3m, semestral +6m, anual +1a
  - INSERT pendente, histórico inicial, auditoria create
- `handleObligationById` GET histórico allowed_transitions, PATCH:
  - Campos: title/category/description/periodicity/responsible/due_date/file_url/storage_key
  - Status: pendente→em_analise/cancelado (exige comprovante para em_analise), em_analise→aprovado/rejeitado/pendente/cancelado, aprovado→vencido/cancelado com next_due_date calculado, rejeitado→pendente/em_analise/cancelado, vencido→pendente/em_analise/cancelado
  - Se file_url enviado, seta last_submitted_at NOW()
  - Se aprovado, seta approved_by/id/at e calcula next_due_date
  - Se rejeitado, exige rejection_reason
  - Transação com histórico, auditoria approve/reject/submit/update
- `handleByCompany` GET `/api/crm/companies/:id/doc-obligations` lista por cliente

### server.mjs
- Import `createContractDocObligationApi`, instancia
- Rotas:
  - `/api/crm/contracts/:id/doc-obligations` GET/POST
  - `/api/crm/contracts/:id/doc-obligations/:obId` GET/PATCH
  - `/api/crm/companies/:id/doc-obligations` GET

### UI ContractDocObligationClient.tsx
- contract_id input + Carregar
- Form criar: title, category select, periodicity select, responsible_name, due_date, file_url, description, botão Criar
- Lista: category title periodicity resp status venc prox comp id
- Form transição: obligation_id, next_status select, file_url (obrigatório para em_analise), reason, rejection_reason, botão Transitar
- Regras descritas

### migrate-site-visual.mjs
- Inclui 037, log 001-037

## Validação
- npm test 46 pass 4 skipped
- next build 59 páginas
- Comprovante obrigatório para em_analise validado
- Periodicidade com next_due_date calculado
- Por cliente/contrato com CHECK

## Decisões
- DT-101 migração 037
- DT-102 contract-doc-obligation-api
- DT-103 integração server + UI

## Próximo passo
- CON-07 implantação com checklist: contrato, data de início, postos, dimensionamento, contratação/alocação, exames/treinamentos, equipamentos, instruções, faturamento e convite do cliente
