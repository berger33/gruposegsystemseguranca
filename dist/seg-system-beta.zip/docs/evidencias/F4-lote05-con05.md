# F4 lote 05 — CON-05 alertas configuráveis vencimento/renovação

Data: 2026-09-28T16:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit: c45d85d -> atual (CON-05)

## Requisito
CON-05: alertas configuráveis de vencimento/renovação, tarefas com responsável e negociação vinculada ao CRM.

## Implementação

### Migração 036
- `db/migrations/036-con05-contract-alerts.sql`
- Enums: `crm_alert_type` vencimento/renovacao/reajuste/vigencia_fim/faturamento/outro, `crm_alert_channel` email/whatsapp/sistema/outro, `crm_alert_status` pendente/enviado/confirmado/cancelado/concluido
- Adiciona `contract_id UUID FK CASCADE` em `crm_tasks` + índice `contract_id, status, due_date`
- Tabela `crm_contract_alert_rules`:
  - `id PK`, `contract_id FK CASCADE`, `company_id FK SET NULL`
  - `alert_type`, `title 200`, `description 1000`
  - `days_before INT 1..365` — configurável
  - `is_enabled BOOL default true`
  - `channel` enum
  - `responsible_id FK`, `responsible_name 1..120` — responsável
  - `opportunity_id FK SET NULL` — negociação vinculada CRM
  - `created_by`, `created_by_id`, `created_at`, `updated_at`
  - Índices: contract/type/enabled, responsible/type, company
  - Trigger updated_at
- Tabela `crm_contract_alerts`:
  - `id PK`, `rule_id FK SET NULL`, `contract_id FK CASCADE`, `company_id FK SET NULL`
  - `alert_type`, `title 200`
  - `scheduled_date DATE NOT NULL` — quando alertar
  - `due_date DATE NOT NULL` — vencimento contrato
  - `status` enum default pendente
  - `task_id FK crm_tasks SET NULL` — tarefa criada
  - `opportunity_id FK SET NULL` — negociação vinculada
  - `responsible_id`, `responsible_name`, `notes 1000`
  - `created_by`, `created_by_id`, `created_at`, `updated_at`
  - Índices: contract/scheduled, scheduled/status, rule, responsible/status, task
  - CHECK scheduled <= due
  - Trigger updated_at
- Auditoria: alert_rule_create/update, alert_create/status

### API contract-alert-api.mjs
- `handleAlertRules` GET `/api/crm/contracts/:id/alert-rules` lista regras, POST cria regra com alert_type, title, days_before 1..365, channel, responsible_name/id, opportunity_id, is_enabled, valida responsible_required
- `handleAlertRuleById` GET/PATCH (title/description/days_before/is_enabled/channel/responsible/opportunity)/DELETE
- `handleAlerts` GET lista alertas, POST gera alerta:
  - Se `rule_id` informado: busca regra, verifica is_enabled, usa alert_type/title/responsible/opportunity/company_id da regra, se due_date não informado usa contract.ends_on, calcula scheduled = due - days_before se scheduled não informado
  - Se sem regra: exige due_date, scheduled_date, title, responsible
  - Valida scheduled <= due
  - Cria tarefa `crm_tasks` com contract_id, company_id, opportunity_id, title, description alerta, responsible_id, due_date = scheduled, status aberta prioridade alta, se create_task true
  - INSERT `crm_contract_alerts` com rule_id, contract_id, company_id, alert_type, title, scheduled, due, status pendente, task_id, opportunity_id, responsible, notes
  - Auditoria alert_create
- `handleAlertById` GET/PATCH status pendente/enviado/confirmado/cancelado/concluido, notes, responsible, opportunity, auditoria status

### server.mjs
- Import `createContractAlertApi`, instancia
- Rotas:
  - `/api/crm/contracts/:id/alert-rules` GET/POST
  - `/api/crm/contracts/:id/alert-rules/:ruleId` GET/PATCH/DELETE
  - `/api/crm/contracts/:id/alerts` GET/POST
  - `/api/crm/contracts/:id/alerts/:alertId` GET/PATCH

### UI ContractAlertClient.tsx
- contract_id input + Carregar regras e alertas
- Form criar regra: alert_type select, title, days_before number, channel select, responsible_name, opportunity_id, description, botão Criar regra configurável
- Lista regras: type title days_before canal resp opp enabled
- Form gerar alerta: rule_id (calcula scheduled=due-days_before), due_date, scheduled_date, title, responsible_name, opportunity_id, notes, create_task checkbox, botão Gerar alerta + tarefa
- Lista alertas: type title agendado venc status resp opp task

### migrate-site-visual.mjs
- Inclui 036, log 001-036

## Validação
- npm test 46 pass 4 skipped
- next build 59 páginas
- Tarefas com responsável e negociação vinculada via contract_id + opportunity_id em crm_tasks
- Alertas configuráveis days_before, is_enabled, channel

## Decisões
- DT-98 migração 036
- DT-99 contract-alert-api
- DT-100 integração server + UI

## Próximo passo
- CON-06 obrigações documentais por cliente/contrato com categoria, periodicidade, responsável, aprovação e comprovante
