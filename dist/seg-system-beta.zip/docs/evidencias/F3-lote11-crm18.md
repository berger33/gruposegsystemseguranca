# Evidência F3 lote 11 — CRM-18 alçadas desconto e exceções

Data: 2026-09-28T10:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 49d366cd -> HEAD atual
Objetivo: CRM-18 alçadas de desconto e exceções; motivo, solicitante, aprovador e versão. Alteração de itens/custos após aprovação reabre a aprovação.

## Implementação

### Migração 023
- `db/migrations/023-crm18-discount-tiers.sql`
- Tipos: crm_discount_policy_status rascunho/em_revisao/aprovado/arquivado, crm_discount_request_status rascunho/solicitado/em_analise/aprovado/rejeitado/arquivado/expirado, crm_discount_scope_type global/company/opportunity/service/technical_budget/labor_budget/price_scenario/outro.
- `crm_discount_policies`: id UUID PK, name 200, description 2000, scope_type enum, scope_id UUID, min_discount_percent 0..100, max_discount_percent 0..100 CHECK max>=min, min_amount/max_amount 14,2, requires_approval bool, approver_role 50, approval_status enum default rascunho, version int, approved_by/at/role, notes 2000, created_by/by_id, índices scope/status, trigger updated_at.
- `crm_discount_requests`: id UUID PK, policy_id FK SET NULL, company_id/opportunity_id/technical_budget_id/labor_budget_id/price_scenario_id FK SET NULL, requested_discount_percent 0..100, requested_amount 14,2, original_price/discounted_price 14,2, reason 10-1000 obrigatório, requester_id/role/name 120, approver_id/role/name 120, status enum default rascunho, version int, budget_version_at_request int, technical/labor/price_version_at_approval int, approved_at/rejected_at/expires_at, rejection_reason 1000, reapproval_required bool default false, reapproval_reason 1000, notes 2000, created_by/by_id, índices policy/company/opportunity/tech/labor/price/status/reapproval partial where true, trigger updated_at.
- Auditoria via auth_access_audit.

### API
- `src/server/discount-api.mjs`
- `handlePolicies`: GET filtros scope_type/status count+list limit 200, POST valida name 200 scope_type enum min/max percent min/max amount requires_approval approver_role notes INSERT rascunho version 1 RETURNING *, audit create.
- `handlePolicyById`: GET, PATCH valida name/description/scope_type/scope_id/min/max percent/amount/requires_approval/approver_role/notes/approval_status com approved_by/at/role quando aprovado, version++ updated_at, audit.
- `handleRequests`: GET filtros companyId/opportunityId/policyId/status/reapproval_required count+list, POST valida policy_id/company/opportunity/tech/labor/price UUID requested_discount_percent 0..100 original/discounted price reason>=10 requester_name notes, busca versão atual orçamentos (SELECT version FROM crm_technical_budgets/labor_budgets/price_scenarios) para armazenar budget_version_at_request e technical/labor/price_version_at_approval, INSERT solicitado version 1 RETURNING *, audit create.
- `handleRequestById`: GET, PATCH valida reason>=10 discount/price/notes/status com rejection_reason>=5 se rejeitado, ao aprovar captura versão atual orçamentos (SELECT version) e set technical_budget_version_at_approval/labor/price_version_at_approval, approved_at, approver_id/role, reapproval_required false, reapproval_reason NULL, version++ updated_at, audit status_aprovado/rejeitado/update.
- `reopenApprovalsForBudget`: UPDATE crm_discount_requests SET reapproval_required true, reapproval_reason, status em_analise quando status=aprovado e versão orçamentos mudou após aprovação (technical_budget_version_at_approval != current version etc).
- **Integração reabertura**: `labor-budget-api.mjs` handleItems POST após INSERT e update totais executa UPDATE crm_discount_requests SET reapproval_required true reapproval_reason='Orçamento mão de obra alterado após aprovação (item adicionado)' status em_analise WHERE labor_budget_id=budgetId AND status=aprovado; handleBudgetById PATCH quando title/notes/coverage/margin alterados executa mesmo UPDATE. `technical-budget-api.mjs` handleItems POST e handleBudgetById PATCH com UPDATE similar para technical_budget_id. `price-scenario-api.mjs` PATCH após UPDATE executa UPDATE para price_scenario_id.

### Server
- `server.mjs`: import createDiscountApi, instancia, rotas /api/crm/discount-policies, /:id, /api/crm/discount-requests, /:id, API_PATH_MATCH expandido.

### UI
- `src/app/admin/ti/DiscountClient.tsx`
- Políticas: form criar nome/scope_type/min/max%/requires_approval/approver_role/notes, lista tabela nome/escopo/min/max/requer aprovação/aprovador/status/versão.
- Solicitações: filtro reapproval_required checkbox, form criar policy_id/company/opportunity/tech/labor/price/requested_discount_percent/original/discounted/reason>=10/requester_name/notes, lista tabela desconto%/original/com desconto/motivo/solicitante/aprovador/status/versão/reapproval? com highlight vermelho se reapproval_required true e motivo reabertura, botão Aprovar chama PATCH status aprovado.
- Mensagem explica motivo/solicitante/aprovador/versão e reabertura quando itens/custos alterados.

### Migrate script
- `scripts/migrate-site-visual.mjs`: 001-023.

## Validação
- npm test: 46 pass 0 fail 4 skipped.
- npx next build: Next 16.3.6, 59 páginas.
- Migrações idempotentes 001-023.
- Reabertura: ao adicionar item em labor/technical budget ou alterar dados, discount_requests aprovados voltam para em_analise com reapproval_required true e reapproval_reason.

## Critério de aceite CRM-18
- Alçadas desconto e exceções: implementado via crm_discount_policies (alçadas por escopo/min/max/requires_approval/approver_role) e crm_discount_requests (exceções/solicitações).
- Motivo, solicitante, aprovador e versão: reason 10-1000 obrigatório, requester_id/role/name, approver_id/role/name, version int, budget_version_at_request/approval.
- Alteração de itens/custos após aprovação reabre aprovação: implementado via UPDATE reapproval_required true status em_analise quando technical_budget/labor_budget/price_scenario version muda após aprovação, integrado em labor-budget-api, technical-budget-api, price-scenario-api.

## Próximo passo
CRM-19 proposta versionada.

## Produção
Não liberada, noindex mantido.
