# F5 lote 22 — PLT-17/18 isolamento ambientes docs manutenção

- Data/hora: 2026-09-29T05:30Z
- Fase: PLT-17 isolamento dev/homolog/prod + PLT-18 documentação manutenção programador
- Status: implementado não verificado

## Migração 055-plt17-env-isolation.sql

- Enums: env_type development/homologation/production/preview, env_isolation_status isolado/compartilhado/em_verificacao/falha
- environments: id PK, name 3..100 UNIQUE, env_type, status, db_name 100 UNIQUE, db_user 100, storage_bucket 200, domain 200, is_production bool, has_real_data bool, isolation_verified_at/by, notes 2000, created_by/by_id, índices type/status/production, trigger
- env_data_checks: id PK, env_id FK CASCADE, check_type real_data_scan/preview_data_check/isolation_verify/account_separation, status pendente/passou/falhou/aviso, details JSONB, checked_by/by_id, checked_at, índices env/type/status
- Seed 4 envs: development-local dev grupo_seg_dev dev_user seg-system-dev-bucket dev.gruposegsystem.local false false isolado, homologation homolog grupo_seg_homolog homolog_user seg-system-homolog-bucket homolog.gruposegsystem.com.br false false isolado, production prod grupo_seg_prod prod_user seg-system-prod-bucket gruposegsystem.com.br true true isolado, preview-vercel preview grupo_seg_preview preview_user seg-system-preview-bucket preview.gruposegsystem.vercel.app false false isolado ON CONFLICT DO NOTHING
- Audit: env_create/verify/check

## API env-api.mjs

- handleEnvs GET list ORDER production>homolog>dev>preview, POST name min3 env_type db_name db_user storage_bucket domain is_production has_real_data valida production_must_have_real_data_flag non_production_cannot_have_real_data duplicate_name_or_db INSERT audit create, PATCH id status notes valida status UPDATE isolation_verified_at/by audit verify
- handleChecks GET env_id filter, POST env_id check_type status details valida env exists preview_has_real_data non_production_has_real_data INSERT details audit check se isolation_verify passou UPDATE env status isolado verified_at/by

## Migração 056-plt18-maintenance-docs.sql

- Enums: doc_category configuracao/migracao/diagnostico/recuperacao/arquitetura/operacao/seguranca/outro, doc_status rascunho/em_revisao/aprovado/publicado/arquivado
- maintenance_docs: id PK, category, status, title 10..200, slug 200, content 50..20000, version 1.. UNIQUE(slug,version), is_published bool, published_at, approved_by/by_id/at, tags TEXT[], created_by/by_id updated_by/by_id, índices category/status/slug/published, trigger
- maintenance_doc_history: id PK, doc_id FK CASCADE, previous_version next_version change_summary changed_by/by_id, índice doc
- Seed 7 docs: arquitetura-geral arquitetura publicado monólito modular Next.js Node Postgres migrations 001-056, configuracao-ambiente configuracao publicado .env.example secrets all/dev/homolog/prod, migracao-rollback migracao publicado expansivas compatíveis rollback via history, diagnostico-saude diagnostico publicado healthcheck observabilidade, recuperacao-backup recuperacao publicado RPO/RTO backup restauração, operacao-filas operacao publicado filas notificações integrações webhooks, seguranca-sessao seguranca publicado sessão MFA RBAC auditoria ON CONFLICT DO NOTHING
- Audit: maintenance_doc_create/publish

## API maintenance-doc-api.mjs

- handleDocs GET isPublic /api/docs public filter is_published true else admin/ti restrito filtros category status is_published ORDER category slug version DESC, POST category title min10 slug min3 content min50 tags nextVersion MAX+1 INSERT version tags created_by/by_id INSERT history previous null next version Criação inicial audit create
- handleDocById GET doc+history, PATCH status content title tags change_summary publish se content changed INSERT new version version+1 category status title slug content version is_published tags created_by/by_id INSERT history previous version next version else UPDATE title status is_published published_at approved_by/at tags updated_by/by_id audit publish/create

## server.mjs

- import createEnvApi createMaintenanceDocApi, init envApi maintenanceDocApi pool auditLog sameOrigin requireSession requireRole
- Rotas: /admin/environments /environments /admin/environments/checks /environments/checks, /admin/maintenance/docs /maintenance/docs /docs /:id
- API_PATH_MATCH expandido env 6 + docs 8 entradas total 14

## UI

- EnvClient.tsx: load envs checks list status type name db user bucket domain prod real_data verified por buttons verificar isolado usar p/ check form name env_type db_name db_user bucket domain is_production has_real_data notes criar valida checks list status check_type env por details form env_id check_type status details JSON registrar check preview must not have real data isolation_verify passou atualiza env isolado
- MaintenanceDocClient.tsx: load docs list status published v version category slug title tags published_at button abrir form category slug title content tags criar doc gera versão automática doc selecionado v slug status publicado title category pre content tags button publicar histórico versões nova versão textarea conteúdo criar nova versão

## Infra

- migrate-site-visual.mjs: adicionado 055-plt17-env-isolation.sql 056-plt18-maintenance-docs.sql total 001-056
- Build: 60 páginas, testes 46 pass 4 skipped
- F5 completo: PLT-01..18 implementado não verificado, próxima verificação F5 completa homologação usuários EXT AI condicional
