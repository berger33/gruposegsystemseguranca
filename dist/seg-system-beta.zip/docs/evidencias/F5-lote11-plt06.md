# F5 Lote 11 — PLT-06 Observabilidade HTTP/jobs/DB — Evidência

Data: 2026-09-28T22:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Base: fc9b157 (PLT-05)

## Objetivo PLT-06
Observabilidade de HTTP/jobs/DB, correlação por request/event ID, métricas e alertas acionáveis, sem segredos.

## Migração 044
- Enums: alert_severity info/warning/critical, alert_status firing/acknowledged/resolved/suppressed, job_status started/success/failed/retry/dead
- Tabelas:
  - observability_http_requests: request_id 8..100, correlation_id, method enum, path 500, status_code, duration_ms, user_kind, user_id, ip_hash 200, user_agent_hash, error_sanitized 1000, índices request_id, path/status, created, status
  - observability_job_executions: job_name 100, correlation_id, request_id, status enum, duration_ms, attempts, error_sanitized 1000, metadata JSONB, índices job_name/status, corr
  - observability_db_metrics: query_type SELECT/INSERT/UPDATE/DELETE/OTHER, table_name 100, duration_ms, success bool, error_sanitized, correlation_id, request_id, índices table/corr
  - observability_metrics: metric_name 100, value 14,4, labels JSONB, collected_at, índice name
  - observability_alerts: alert_key 200, metric_name 100, severity, status, threshold, current, message 1000, correlation_id, acknowledged_by/at, resolved_at, índices key/status, trigger updated_at
- Auditoria: observability_query, alert_ack, alert_resolve

## Módulo observability.mjs
- hashValue sha256 slice 32 para ip/user_agent
- sanitizeError remove password=, token=, secret=, Bearer, stack at ... sanitized, slice 1000
- sanitizePath remove query via URL pathname slice 500
- parseQueryType SELECT/INSERT/UPDATE/DELETE/OTHER
- parseTableName FROM/INTO/UPDATE/DELETE FROM regex
- createObservability({ getPool }):
  - metrics in-memory: http_requests_total, 5xx, 4xx, duration_sum/count, db_queries_total failed sum, jobs_total failed
  - recentRequests/Jobs/Db arrays max 100
  - generateRequestId req_8 + base36 timestamp
  - generateCorrelationId corr UUID
  - recordHttp: incrementa métricas, entry sanitizado path ip_hash ua_hash error_sanitized, unshift recent, async INSERT observability_http_requests sem segredos, evaluateAlerts
  - recordJob: metrics jobs_total failed, entry, INSERT job_executions, evaluateAlerts
  - recordDb: metrics db total failed sum, entry query_type table_name, INSERT db_metrics, evaluateAlerts
  - wrapPool: monkey-patch pool.query mede duration success error, correlation/request_id de globalThis.__current*, recordDb
  - alerts array max 200
  - evaluateAlerts: http_5xx_rate >0.1 critical, http_slow >3000 warning, db_failure >0.05 critical, job failed/dead warning/critical, db_slow >2000 warning
  - triggerAlert: suprime duplicado key firing dentro 1min, cria alert sanitizado, unshift, async INSERT alerts
  - getMetrics: avg duration, db avg, recent 20, alerts firing 20, uptime, timestamp, note sem segredos

## API observability-api.mjs
- handleMetrics: sameOrigin admin/ti restricted, type summary/requests/jobs/db/alerts
  - summary: memory getMetrics() + DB aggregates 1h (http total 5xx 4xx avg max, jobs total failed avg, db total failed avg max, alerts firing critical) via SQL, audit observability_query
  - requests: SELECT * observability_http_requests ORDER BY created DESC LIMIT, memory_recent
  - jobs: SELECT job_executions LIMIT, memory_recent
  - db: SELECT db_metrics LIMIT, memory_recent
  - alerts: SELECT alerts WHERE status LIMIT 200, memory_firing
- handleAlertAction: POST/PATCH /alerts/:id action acknowledge/resolve, valida UUID, admin/ti, UPDATE alerts status acknowledged/resolved acknowledged_by/at resolved_at, audit alert_ack/resolve, update memory

- Rotas server.mjs: /api/admin/observability, /metrics, /alerts/:id, /api/crm/observability equivalents, API_PATH_MATCH expandido

## Server.mjs integração
- let pool, observabilityInstance, getPool() wrapPool se observabilityInstance existe, getObservability() lazy createObservability({ getPool })
- const observability = getObservability(), observabilityApi
- notificationQueue = createNotificationQueue({ getPool, observability: getObservability() })
- routeApi: obs = getObservability(), requestId generate, correlationId de header x-correlation-id ou generate, global __currentRequestId/__currentCorrelationId, start Date.now(), setHeader X-Request-Id/Correlation-Id, monkey-patch res.writeHead capture status, try routing, catch error 500 json com request_id, finally recordHttp com session role identityId ip x-forwarded-for remoteAddress ua path duration error, clear globals
- notification-queue.mjs ctx observability recordJob success/failed/dead com attempts channel error

## UI ObservabilityClient
- type summary/requests/jobs/db/alerts, limit, load fetch /api/admin/observability?type=&limit=
- summary: grid HTTP total 5xx 4xx avg, DB total failed avg, Jobs total failed uptime, Alerts firing, DB aggregates 1h, recent requests mono list request_id corr method path status duration user_kind err, alerts firing list key severity metric cur thresh message corr date
- requests: list request_id method path status duration ip_hash err date
- alerts: list key severity status message metric cur thresh corr buttons Ack/Resolve POST /alerts/:id action
- jobs/db: JSON stringify slice 8000

## Validação
- npm test 46 pass 4 skipped (pg installed)
- npx next build 59 páginas OK
- migrate-site-visual 001-044

## Próximos
- PLT-07 healthcheck/liveness/readiness degradação painel operacional restrito
- PLT-08 backup criptografia retenção restauração
- PLT-09 privacidade completa inventário bases etc
