# F4 lote 07 — CON-07 implantação checklist + CON-08 bloqueios e exceções

Data: 2026-09-28T18:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit: a9a1ece -> atual (CON-07/08)

## Requisitos
- CON-07: implantação com checklist: contrato, data de início, postos, dimensionamento, contratação/alocação, exames/treinamentos, equipamentos, instruções, faturamento e convite do cliente.
- CON-08: bloqueios claros para implantação incompleta; exceção somente autorizada, motivada e permitida pelas regras aplicáveis. Não permitir contornar exigência legal com simples checkbox.

## Implementação

### Migração 038 CON-07
- `db/migrations/038-con07-implantation-checklist.sql`
- Enums: `crm_implantation_step_id` contrato/data_inicio/postos/dimensionamento/contratacao_alocacao/exames_treinamentos/equipamentos/instrucoes/faturamento/convite_cliente, `crm_implantation_step_status` pendente/em_andamento/concluido/nao_aplicavel/bloqueado
- Colunas `crm_contract_implantations`: data_inicio DATE, responsible_id, responsible_name 120, completed_at DATE
- Tabela `crm_implantation_steps`: id PK, implantation_id FK CASCADE, contract_id FK CASCADE, step_id enum, title 200, description 1000, status, responsible_id/name, completed_at DATE, notes 1000, UNIQUE(implantation_id, step_id), índices implantation/status, contract/step/status, responsible/status, trigger updated_at
- Auditoria: implantation_create/update, step_create/update

### Migração 039 CON-08
- `db/migrations/039-con08-implantation-blocks.sql`
- Enums: `crm_implantation_block_type` documentacao/treinamento/equipamento/legal/operacional/financeiro/outro, `crm_implantation_exception_status` solicitada/em_analise/autorizada/rejeitada/cancelada
- Tabela `crm_implantation_blocks`: id PK, contract_id FK CASCADE, implantation_id FK CASCADE, step_id enum, block_type, title 200, description 2000 (≥20 para clareza), is_legal_requirement BOOL, is_blocking BOOL, created_by/id, resolved_at/by, índices contract/blocking/type, implantation/blocking
- Tabela `crm_implantation_exceptions`: id PK, contract_id FK CASCADE, implantation_id FK CASCADE, block_id FK SET NULL, step_id, title 200, motivation 20..2000 NOT NULL (legal ≥50), legal_basis 1000, is_legal_exception BOOL, applicable_rule 500, status, authorized_by/at, authorization_notes 1000, rejection_reason 1000, created_by/id, CHECK motivation>=20, CHECK legal exception requires legal_basis+applicable_rule, índices contract/status, block/status, legal/status, trigger updated_at
- Auditoria: block_create/resolve, exception_create/authorize/reject

### API contract-implantation-api.mjs
- `handleImplantation` GET `/api/crm/contracts/:id/implantation`:
  - Busca contrato, se implantação não existe cria planejada idempotente com proposal_id/version do contrato
  - ensureImplantationSteps inicializa 10 itens padrão se faltar
  - Lista steps ordenados por ordem lógica 1..10, calcula progresso completed/total/percent, retorna checklist_required 10
  - Nota: checklist completo
- PATCH `/api/crm/contracts/:id/implantation`: status planejada/em_andamento/concluida/cancelada, data_inicio, responsible_id/name, completed_at, notes, checklist JSONB
- `handleSteps` GET lista steps, POST inicializa checklist padrão
- `handleStepById` PATCH `/implantation/steps/:stepId` onde stepId pode ser enum (contrato, data_inicio, etc) ou UUID:
  - status, responsible_id/name, completed_at, notes, description
  - Se concluido, seta completed_at
  - Verifica all_completed (concluido ou nao_aplicavel) e atualiza implantação para concluida
  - Auditoria step_update
- `handleBlocks` GET lista bloqueios, POST cria bloqueio claro:
  - title, description ≥20, block_type, step_id opcional, is_legal_requirement, is_blocking
  - Valida description min 20 para clareza
  - Auditoria block_create
- `handleBlockResolve` PATCH `/implantation/blocks/:blockId/resolve`:
  - Se is_legal_requirement true, bloqueia 409 legal_requirement_block_cannot_be_resolved_without_exception
  - Senão seta resolved_at/by
- `handleExceptions` GET lista, POST cria exceção:
  - block_id, step_id, title, motivation ≥20 (legal ≥50), legal_basis, is_legal_exception, applicable_rule
  - Valida legal_exception requires legal_basis+applicable_rule
  - Se block_id tem is_legal_requirement true e is_legal_exception false → 409 legal_requirement_cannot_be_bypassed_with_simple_checkbox
  - Auditoria exception_create
- `handleExceptionById` GET, PATCH status em_analise/autorizada/rejeitada/cancelada, authorization_notes required para autorizada, rejection_reason required para rejeitada, resolve bloqueio se autorizada, auditoria authorize/reject

### server.mjs
- Import `createContractImplantationApi`, instancia
- Rotas:
  - `/api/crm/contracts/:id/implantation` GET/PATCH (novo, substitui antigo)
  - `/api/crm/contracts/:id/implantation/steps` GET/POST
  - `/api/crm/contracts/:id/implantation/steps/:stepId` PATCH (enum ou UUID)
  - `/api/crm/contracts/:id/implantation/blocks` GET/POST
  - `/api/crm/contracts/:id/implantation/blocks/:blockId/resolve` PATCH
  - `/api/crm/contracts/:id/implantation/exceptions` GET/POST
  - `/api/crm/contracts/:id/implantation/exceptions/:exceptionId` GET/PATCH

### UI ContractImplantationClient.tsx
- contract_id input + Carregar implantação + checklist + bloqueios + exceções
- Mostra implantação status data_inicio responsável progresso %
- Checklist 10 itens lista com cor (verde concluido, vermelho bloqueado)
- Atualizar step: step_id select 10, status select, responsible_name, notes, botão
- Bloqueios claros: title, description ≥20, block_type select, step_id opcional, is_legal_requirement checkbox, botão Criar bloqueio claro, lista bloqueios com tipo legal/bloqueante step descrição resolvido id
- Exceções: block_id, step_id, title, motivation ≥20 (legal ≥50), legal_basis, applicable_rule, is_legal_exception checkbox, botão Solicitar exceção motivada, lista exceções status legal block step mot regra id
- Autorizar/rejeitar: exception_id, status autorizada/rejeitada/em_analise/cancelada, authorization_notes, rejection_reason, botão
- Nota legal não contornar com checkbox

### migrate-site-visual.mjs
- Inclui 038, 039, log 001-039

## Validação
- npm test 46 pass 4 skipped
- next build 59 páginas
- Checklist 10 itens inicializado e progresso calculado
- Bloqueio claro com description ≥20
- Exceção motivada ≥20, legal ≥50, base legal e regra aplicável obrigatórias para legal
- Bloqueio legal não resolve sem exceção autorizada
- Exceção legal não contornada com simples checkbox (409)

## Decisões
- DT-104 migração 038
- DT-105 implantation-api CON-07
- DT-106 migração 039
- DT-107 implantação blocks/exceptions CON-08
- DT-108 integração server + UI

## Próximo passo
- CON-09 encerramento com desmobilização, devolução, cobranças/pendências, documentos e revogação de escopos; preservar histórico
