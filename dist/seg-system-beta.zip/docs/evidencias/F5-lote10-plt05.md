# F5 Lote 10 — PLT-05 Notificações painel e-mail canais externos — Evidência

Data: 2026-09-28T21:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 4a1dda2 (CON-10/11)

## Objetivo PLT-05
Notificações no painel, e-mail e canais externos configurados, preferências e templates revisados; nenhuma informação médica em assunto/push.

## Migração 043
- Enums: crm_notification_channel email/whatsapp/sms/push/webhook/internal/sistema, crm_notification_template_status rascunho/em_revisao/aprovado/arquivado/rejeitado
- Tabelas:
  - crm_notification_preferences: recipient_kind (client/staff/lead/system/marcelo/ti/admin/rh), recipient_id FK auth_identities, recipient_email 320, channel enum, is_enabled bool, is_email_enabled, is_push_enabled, is_whatsapp_enabled, is_sms_enabled, is_internal_enabled, quiet_hours_start/end TIME, created_by/by_id, UNIQUE(kind,id,channel), índices kind/channel, trigger updated_at
  - crm_notification_templates: template_key 100, channel enum, subject 200, body 5000 NOT NULL, is_medical_safe bool default true, status enum default rascunho, version INT, rejection_reason 1000, approved_by/at, medical_review_note 1000, created_by/by_id, UNIQUE(key,channel,version), índices key/channel status, trigger updated_at
- Seed 4 templates aprovados medical_safe true: lead_new internal, lead_new_email email, contract_status_change internal, implantation_blocked internal
- Auditoria: notification_preference_update, template_create/update/approve/reject

## API notification-preferences-api.mjs
- CHANNELS 7, RECIPIENT_KINDS 8, TEMPLATE_STATUSES 5
- sanitizeText, containsMedicalInfo heuristic: prontuario, diagnostico, CID, doença, sintoma, exame médico, atestado médico, receita médica, medicação, medicamento, tratamento médico, laudo, histórico médico, histórico clínico, CPF pattern
- handlePreferences:
  - GET: sameOrigin session, filtros recipientKind recipientId, SELECT ORDER BY kind channel, note preferências por canal painel e-mail externos quiet hours sem info médica
  - POST/PUT: recipient_kind enum, recipient_id optional, recipient_email 320, channel enum, is_enabled etc bool, quiet_hours TIME optional, upsert ON CONFLICT (kind,id,channel) DO UPDATE, audit preference_update
- handleTemplates:
  - GET: sameOrigin session, filtros channel status search ILIKE key/subject/body, SELECT LIMIT 200 ORDER BY key channel version DESC, note templates revisados sem médica
  - POST: template_key 100, channel enum, subject 200, body 5000, status enum default rascunho, medical_review_note 1000, valida containsMedicalInfo subject/body -> is_medical_safe false, se channel push ou subject contém médica bloqueia 400 medical_info_not_allowed, version = MAX+1, INSERT, audit template_create
- handleTemplateById:
  - GET: UUID, SELECT
  - PATCH: subject 200 valida medical_info_not_allowed_in_subject, body 5000 valida medical push, is_medical_safe recalculado, status enum approval admin/ti required para aprovado/rejeitado, rejection_reason required para rejeitado, approved_by/at, medical_review_note, UPDATE updated_at, audit approve/reject/update

- Rotas server.mjs: /api/crm/notification-preferences, /api/admin/notification-preferences, /api/crm/notification-templates, /api/admin/notification-templates, /:id

## UI NotificationPreferencesClient
- loadPrefs loadTemplates msg
- Preferências lista kind channel enabled email/push/wa/sms/internal quiet
- Form pref recipient_kind select staff/admin/ti/rh/client/lead, channel select email/internal/push/whatsapp/sms/webhook/sistema, recipient_id UUID optional, enabled checkbox, salvar
- Templates lista key channel version status subject safe body slice 200, transição status aprovado/em_revisao/arquivado/rejeitado
- Form criar template_key channel subject body status validação médica placeholder NÃO incluir prontuário/diagnóstico

## Validação
- npm test 46 pass 4 skipped
- npx next build 59 páginas OK
- migrate-site-visual 001-043

## Próximos
- PLT-06 observabilidade HTTP/jobs/DB correlação request/event ID métricas alertas sem segredos
- PLT-07 healthcheck/liveness/readiness degradação painel operacional
- PLT-08 backup criptografia retenção restauração
- PLT-09..18 privacidade LGPD etc
