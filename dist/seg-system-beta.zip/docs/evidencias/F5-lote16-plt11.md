# F5 lote 16 — PLT-11 retenção por categoria descarte verificável

- Data/hora: 2026-09-29T02:30Z
- Fase: PLT-11 retenção por categoria, descarte em jobs verificáveis, retenção excepcional formal e histórico minimizado
- Status: implementado não verificado

## Migração 049-plt11-retention.sql

- Enums: retention_exception_status solicitado/em_analise/aprovado/rejeitado/expirado/revogado, disposal_method exclusao_logica/exclusao_fisica/anonimizacao/arquivamento, disposal_job_status pendente/em_execucao/concluido/falha/parcial
- data_retention_policies: id PK, category privacy_data_category, field_pattern 200, retention_days 1..36500, description 10..2000, legal_basis privacy_legal_basis, legal_basis_detail, exceptional_retention_allowed bool, max_exception_days, disposal_method, is_active bool, created_by/by_id updated_by/by_id, UNIQUE(category,field_pattern), índices category/active, trigger
- retention_exceptions: id PK, policy_id FK, category, field_reference 200, reason 10..1000, justification 10..2000, status, requested_days, approved_days, expires_at DATE, requested_by/by_id approved_by/by_id reviewed_at rejection_reason 1000, índices policy/status/category/expires, trigger
- disposal_jobs: id PK, status, started_at finished_at scanned expired disposed errors initiated_by/by_id notes 2000 error_details 5000, índices status/created, trigger
- disposal_logs: id PK, job_id FK CASCADE, category, field, record_reference_hash 200, record_table 100, record_id 100, disposal_method, disposed_at, verified_by/by_id retention_days exception_id FK details 1000, índices job/category/disposed/hash
- Seed: INSERT data_retention_policies SELECT privacy_data_inventory category data_field retention_days purpose legal_basis exclusao_logica exceptional TRUE se sensível max*2 ON CONFLICT DO NOTHING
- Audit: retention_policy_create/update exception_create/approve/reject/revoke job_create/execute log_create

## API retention-api.mjs

- CATEGORIES 9, LEGAL_BASIS 9, EX_STATUS 6, METHODS 4, JOB_STATUSES 5
- ALLOWED solicitado->[em_analise,rejeitado,aprovado] em_analise->[aprovado,rejeitado] aprovado->[expirado,revogado]
- handlePolicies: GET filtros category active, POST/PUT upsert ON CONFLICT valida category retention_days description legal_basis disposal_method max_exception INSERT/UPDATE audit
- handleExceptions: GET status category, POST valida category field reason justification requested_days policy exceptional_not_allowed exceeds_max_exception expires_at default +requested_days INSERT solicitado audit
- handleExceptionById: GET, PATCH valida transition rejection_reason_min_10 approved_days UPDATE reviewed_at approved_by audit approve/reject/revoke
- handleJobs: GET list, POST cria pendente em_execucao UPDATE exceções aprovadas expires<CURRENT_DATE para expirado COUNT policies COUNT expired INSERT disposal_logs hashRef record_reference_hash sem dado pessoal UPDATE concluido audit job_create/execute
- handleJobById: GET job+logs
- handleLogs: GET category filter

## server.mjs

- import createRetentionApi, init retentionApi pool auditLog sameOrigin requireSession requireRole
- Rotas: /admin/retention/policies /crm/retention/policies /privacy/retention/policies /admin/privacy/retention, /admin/retention/exceptions /crm/retention/exceptions /privacy/retention/exceptions /:id, /admin/retention/disposal/jobs /crm/retention/disposal/jobs /admin/disposal/jobs /privacy/disposal/jobs /:id, /admin/retention/disposal/logs /crm/retention/disposal/logs /admin/disposal/logs /privacy/disposal/logs
- API_PATH_MATCH expandido retention 14 entradas

## UI

- RetentionClient.tsx: load policies exceptions jobs logs, lista policies category/field retention_days legal_basis disposal_method exceptional active, form política category field_pattern retention_days legal_basis disposal_method exceptional_allowed max_exception description upsert, exceções list status category/field req/apr exp por motivo, form exceção category field_reference requested_days expires_at reason justification, update exceção id next_status approved_days rejection_reason, jobs list status scanned expired disposed por created finished notes, logs list category/field hash 12 chars disposal_method retention_days disposed_at details minimizado, botão executar job descarte, aviso histórico minimizado hash sem dado pessoal

## Infra

- migrate-site-visual.mjs: adicionado 049-plt11-retention.sql
- Build: 60 páginas (antes 59), testes 46 pass 4 skipped
- Próxima: PLT-12 resposta incidente
