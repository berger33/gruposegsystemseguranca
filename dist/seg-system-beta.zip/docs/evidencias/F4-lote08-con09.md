# F4 lote 08 — CON-09 encerramento

Data: 2026-09-28T19:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit: 5be67f4 -> atual (CON-09)

## Requisito
CON-09: encerramento com desmobilização de equipe, devolução, cobranças/pendências, documentos e revogação de escopos; preservar histórico.

Aceite: mudar um aditivo não altera faturas anteriores; encerramento deixa de gerar novas rotinas conforme data de efeito sem apagar lançamentos já existentes.

## Implementação

### Migração 040
- `db/migrations/040-con09-contract-closure.sql`
- Enums: closure_type encerramento/rescisao/distrato/termino_vigencia/outro, closure_status planejado/em_andamento/concluido/cancelado, closure_step_type desmobilizacao_equipe/devolucao_equipamentos/devolucao_chaves/cobrancas_pendencias/documentos_finais/revogacao_escopos/comunicacao_cliente/outro, closure_step_status pendente/em_andamento/concluido/nao_aplicavel
- Tabela `crm_contract_closures`: id PK, contract_id FK CASCADE UNIQUE, closure_type, closure_date DATE, effective_date DATE (data efeito deixa gerar novas rotinas), reason 10..2000, status, responsible_id/name, notes 2000, created_by/id, índices contract/effective, status/effective, effective where concluido, trigger
- Tabela `crm_closure_steps`: closure_id FK CASCADE, contract_id FK CASCADE, step_type, title 200, description 1000, status, responsible_id/name, completed_at DATE, notes 1000, índices closure/status, contract/type/status, trigger
- Tabela `crm_contract_scope_revocations`: contract_id FK CASCADE, closure_id FK SET NULL, scope_type 100, scope_description 1000, revoked_at DATE, revoked_by/id, reason 1000, índice contract/revoked
- Tabela `crm_closure_history`: closure_id FK CASCADE, contract_id FK CASCADE, previous/next status, effective_date, reason, changed_by/id, índice closure/effective
- Auditoria: closure_create/update/conclude, step_create/update, scope_revocation_create
- Preservar histórico: não deleta contrato, itens, etc., apenas marca encerrado

### API contract-closure-api.mjs
- `handleClosure` GET `/api/crm/contracts/:id/closure`:
  - Busca contrato, se closure existe ensureClosureSteps 7 itens padrão, lista steps ordenados, revocations, history, progress total/completed/percent
  - Nota: preserva histórico, effective_date deixa gerar novas rotinas sem apagar lançamentos
- POST cria encerramento: closure_type, closure_date, effective_date, reason ≥10, responsible_name, notes, valida effective>=closure, contrato não já encerrado, closure único, INSERT planejado, ensureSteps, histórico
- PATCH status: planejado/em_andamento/concluido/cancelado, verifica steps incompletos se concluido → 409 closure_steps_incomplete com bloqueios claros, se concluido atualiza contrato status encerrado current_status_effective_date closure_reason status_changed_at/by, preserva histórico, INSERT closure_history e contract_status_history
- `handleSteps` GET lista steps, PATCH atualiza step por tipo (desmobilizacao_equipe etc) ou UUID, status, responsible_name, notes, completed_at
- `handleRevocations` GET lista revogações, POST cria revogação escopo: scope_type, scope_description, revoked_at DATE, reason, com closure_id opcional, preserva histórico

### server.mjs
- Import `createContractClosureApi`, instancia
- Rotas:
  - `/api/crm/contracts/:id/closure` GET/POST/PATCH
  - `/api/crm/contracts/:id/closure/steps` GET/PATCH
  - `/api/crm/contracts/:id/closure/revocations` GET/POST

### UI ContractClosureClient.tsx
- contract_id input + Carregar encerramento
- Mostra closure id tipo data efeito status resp progresso %
- Form criar: closure_type select, closure_date, effective_date (data efeito deixa gerar novas rotinas), reason ≥10, responsible_name, notes, botão Criar
- Transição status: next_status select, reason, botão Transitar (concluido exige checklist completo)
- Checklist desmobilização lista 7 itens com status
- Atualizar step: step_id select, status select, responsible_name, notes, botão
- Revogação escopos: scope_type, scope_description, revoked_at, reason, botão Revogar, lista revogações, histórico

### migrate-site-visual.mjs
- Inclui 040, log 001-040

## Validação
- npm test 46 pass 4 skipped
- next build 59 páginas
- Encerramento com data de efeito, não apaga lançamentos, preserva histórico
- Checklist 7 itens desmobilização, devolução, cobranças, documentos, revogação
- Revogação escopos com histórico

## Decisões
- DT-109 migração 040
- DT-110 contract-closure-api
- DT-111 integração server + UI

## Próximo passo
- CON-10 dossiê fiscalização contratual, medição/aceite serviços e evidências qualidade
