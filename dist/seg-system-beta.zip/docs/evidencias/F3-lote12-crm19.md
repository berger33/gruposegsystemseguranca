# Evidência F3 lote 12 — CRM-19 proposta versionada

Data: 2026-09-28T10:30Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 49d366cd -> HEAD atual
Objetivo: CRM-19 proposta versionada com itens, quantidades, recorrência, implantação, escopo, exclusões, prazo, reajuste previsto, validade e condições; PDF gerado a partir da mesma versão persistida.

## Implementação

### Migração 024
- `db/migrations/024-crm19-proposals.sql`
- Tipos: crm_proposal_status rascunho/em_revisao/aprovada_para_envio/enviada/aceita/recusada/expirada/substituida, crm_proposal_recurrence recorrente/avulso/implantacao/outro, crm_proposal_item_type material/equipamento/mao_obra/servico/instalacao/deslocamento/infraestrutura/licenca/garantia/manutencao/outro.
- `crm_proposals`: id UUID PK, company_id/opportunity_id/technical_budget_id/labor_budget_id/price_scenario_id/discount_request_id FK SET NULL, title 200, status enum default rascunho, version 1, scope_description 5000, exclusions 5000, implementation_details 5000, deadline_description 1000, readjustment_forecast 1000, validity_days 1-365, validity_until DATE, conditions 5000, total_cost/price 14,2, margin_percent -100..100, notes 5000, created_by/by_id/approved_by/at/role/sent_at/by, índices company/opportunity/status/version, trigger updated_at.
- `crm_proposal_items`: id UUID PK, proposal_id FK CASCADE, proposal_version int, type enum, description 500, equipment_id FK crm_equipment, quantity 12,2, unit 50, unit_cost/total_cost/unit_price/total_price 14,2, recurrence_type enum, recurrence_details 500, supplier 200, notes 500, índices proposal/proposal_version/type, trigger updated_at.
- `crm_proposal_versions`: id UUID PK, proposal_id FK CASCADE, version int, snapshot JSONB, reason 1000, created_by/by_id/at, unique proposal+version, índice proposal.

### API
- `src/server/proposal-api.mjs`
- `handleProposals`: GET filtros company/opportunity/status count+list, POST valida company_id UUID title 200 scope 5000 exclusions 5000 implementation 5000 deadline 1000 readjustment 1000 validity_days 1-365 validity_until DATE conditions 5000 notes 5000, calcula totais a partir de technical_budget total_cost/price + labor_budget total_cost/price + price_scenario price_calculated, INSERT rascunho version 1 + INSERT crm_proposal_versions v1 snapshot JSONB {proposal, items:[], created_at} reason Criação inicial.
- `handleProposalById`: GET proposal + items versão atual + versions, PATCH valida title/scope/exclusions/implementation/deadline/readjustment/validity/conditions/notes/margin/status enum, shouldVersion quando status aprovada_para_envio/enviada/aceita/recusada/expirada/substituida ou alteração escopo após enviada, newVersion=current+1, recalc totais itens SUM, UPDATE, copia itens versão anterior para nova versão, cria snapshot versão anterior preservada se não existe e snapshot nova versão, approved_by/at/role sent_at/by, audit.
- `handleItems`: GET itens versão atual, POST valida type enum description 500 quantity>=0 unit 50 unit_cost>=0 unit_price>=0 recurrence_type enum, bloqueio 409 proposal_version_locked_preserve_sent se status enviada/aceita/recusada (preservar versões enviadas), total_cost=qty*unit_cost total_price=qty*unit_price INSERT com proposal_version atual + UPDATE totais proposta.
- `handleVersions`: GET lista versões id/proposal_id/version/reason/created_by/at ORDER BY version DESC.
- `handleVersionByNumber`: GET snapshot versão específica.
- `handlePdf`: GET ?version= ou atual, busca snapshot JSONB versão persistida (mesma versão persistida), buildSimplePdf com escapePdfText, objetos PDF 1 Catalog 2 Pages 3 Page 4 Font Helvetica 5 Contents stream BT /F1 16 Tf 50 750 Td (title vVersion) Tj 0 -20 Td /F1 10 Tf linhas escopo/exclusões/implantação/prazo/reajuste/validade/condições/custo/preço/itens + nota Gerado a partir da versão persistida, calcula xref offsets, retorna Buffer application/pdf attachment filename proposta-id-vVersion.pdf, Cache-Control no-store.

### Server
- `server.mjs`: import createProposalApi, instancia, rotas /api/crm/proposals, /:id, /:id/items, /:id/versions, /:id/versions/:version, /:id/pdf, API_PATH_MATCH expandido.

### UI
- `src/app/admin/ti/ProposalClient.tsx`
- Form criar proposta: company_id*, opportunity_id, technical_budget_id, labor_budget_id, price_scenario_id, discount_request_id, title*, scope_description, exclusions, implementation_details, deadline_description, readjustment_forecast, validity_days, validity_until, conditions, notes.
- Lista propostas tabela título/status/versão/custo/preço/validade botão Ver.
- Detalhe selecionada: escopo/exclusões/implantação/prazo/reajuste/condições, botões status em_revisao/aprovada_para_envio/enviada (preserva versão)/aceita/recusada, botão PDF versão atual (mesma versão persistida).
- Form adicionar item: type select 11 valores, description 500, quantity, unit, unit_cost, unit_price, recurrence_type select avulso/recorrente/implantacao/outro, recurrence_details, supplier_name, lista itens tipo/descrição/qtd/un/custo total/preço total/recorrência.
- Versões preservadas: lista vVersion reason data botão PDF vVersion (PDF gerado a partir da mesma versão persistida).

### Migrate script
- `scripts/migrate-site-visual.mjs`: 001-024.

## Validação
- npm test: 46 pass 0 fail 4 skipped.
- npx next build: Next 16.3.6, 59 páginas.
- Migrações idempotentes 001-024.
- PDF gerado a partir da mesma versão persistida: handlePdf busca snapshot JSONB de crm_proposal_versions, buildSimplePdf usa snapshot, não gera a partir de dados mutáveis atuais.

## Critério de aceite CRM-19
- Proposta versionada com itens, quantidades, recorrência, implantação, escopo, exclusões, prazo, reajuste previsto, validade e condições: implementado via crm_proposals + crm_proposal_items com recurrence_type, scope_description, exclusions, implementation_details, deadline_description, readjustment_forecast, validity_days/until, conditions.
- PDF gerado a partir da mesma versão persistida: handlePdf usa snapshot JSONB de crm_proposal_versions, buildSimplePdf com mesma versão persistida, attachment filename com versão.

## Próximo passo
CRM-20 estados rascunho→revisão→aprovada para envio→enviada→aceita/recusada/expirada/substituída; preservar versões enviadas.

## Produção
Não liberada, noindex mantido.
