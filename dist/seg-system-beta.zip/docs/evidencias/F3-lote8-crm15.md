# Evidência F3 lote 8 — CRM-15 orçamento técnico

Data: 2026-09-28T08:30Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 49d366cd -> HEAD atual (ver git log)
Objetivo: CRM-15 orçamento técnico com materiais, equipamentos, mão de obra, instalação, deslocamento, infraestrutura, licenças, garantia e manutenção.

## Implementação

### Migração 020
- `db/migrations/020-crm15-technical-budget.sql`
- `crm_technical_budgets`: id UUID PK, company_id FK CASCADE, opportunity_id/inspection_id/labor_budget_id FK SET NULL, title 200, status rascunho/em_revisao/aprovado/arquivado, totais por tipo: total_materials_cost, total_equipment_cost, total_labor_cost, total_installation_cost, total_displacement_cost, total_infrastructure_cost, total_licenses_cost, total_warranty_cost, total_maintenance_cost numeric 12,2 default 0 >=0, total_cost/price numeric 12,2, margin_percent -100..100, warranty_description/maintenance_description 1000, notes 2000, created_by/by_id/approved_by/at, índices company/opportunity/status, trigger updated_at.
- `crm_technical_budget_items`: id UUID PK, budget_id FK CASCADE, type enum material/equipamento/mao_obra/instalacao/deslocamento/infraestrutura/licenca/garantia/manutencao/outro, description 500, equipment_id FK crm_equipment SET NULL, quantity numeric 12,2 default 1 >=0, unit 50, unit_cost/total_cost/unit_price/total_price numeric 12,2 >=0, supplier_name 200, notes 500, índices budget/type, trigger updated_at.
- Auditoria: crm_technical_budget_create/update/status/item_create/update.

### API
- `src/server/technical-budget-api.mjs`
- `handleBudgets`: GET valida admin+sameOrigin, filtros companyId/opportunityId/status, count + list ORDER BY created_at DESC limit 200 offset, POST valida company_id UUID title 200 warranty/maintenance 1000 notes 2000 INSERT RETURNING *.
- `handleBudgetById`: GET budget + items ORDER BY created_at, PATCH valida status enum title 200 notes 2000 warranty/maintenance 1000 margin -100..100, recalc SUM total_cost/price GROUP BY type, UPDATE total_materials_cost etc + total_cost/price + approved_by/at quando aprovado.
- `handleItems`: POST valida type enum 10 valores, description 500, quantity>=0, unit 50, unit_cost>=0, unit_price>=0, equipment_id, supplier 200, notes 500, total_cost=qty*unit_cost total_price=qty*unit_price INSERT RETURNING * + UPDATE orçamentos totais por tipo SUM, GET lista items ORDER BY created_at.
- `server.mjs`: import createTechnicalBudgetApi, instancia technicalBudgetApi, rotas /api/crm/technical-budgets, /:id, /:id/items, API_PATH_MATCH expandido.

### UI
- `src/app/admin/ti/TechnicalBudgetClient.tsx`
- Form criar orçamento técnico: companyId UUID, title, warranty_description, maintenance_description.
- Lista orçamentos: título, status, custo total, preço total, materiais, equipamento, mão obra, instalação, desloc, infra, licenças, garantia, manut, botão Ver itens.
- Form adicionar item: type select 10 valores, description 500, quantity numeric, unit, unit_cost, unit_price, supplier, notes.
- Lista itens: tipo, descrição, qtd, un, custo unit/total, preço total, fornecedor.
- Integrado em `src/app/admin/ti/page.tsx`.

### Migrate script
- `scripts/migrate-site-visual.mjs`: 001-020.

## Validação
- npm test: 46 pass 0 fail 4 skipped.
- npx next build: Next 16.3.6, 55 páginas (inclui /admin/ti com TechnicalBudgetClient, /admin/crm, /servicos).
- Migrações idempotentes 001-020.

## Critério de aceite CRM-15
- Orçamento técnico com materiais, equipamentos, mão de obra, instalação, deslocamento, infraestrutura, licenças, garantia e manutenção: implementado via totais por tipo + type enum em items.
- Campos: description 500, equipment_id FK crm_equipment, quantity numeric, unit, unit_cost/total_cost/unit_price/total_price, supplier_name, notes.
- Totais recalculados por tipo via SUM GROUP BY type, total_cost/price agregados.
- Status rascunho/em_revisao/aprovado/arquivado com approved_by/at quando aprovado.
- API com filtros companyId/opportunityId/status, audit.
- UI com criação e listagem e adição item por tipo.
- Sem preço fictício, sem promessa, sem dado real inventado.

## Próximo passo
CRM-16 parâmetros tributos/custos/jornada versionados.

## Produção
Não liberada, noindex mantido.
