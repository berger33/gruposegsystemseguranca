# F1 lote 2 — SEC-11..SEC-15, PLT-02, PLT-04 (auditoria consultável e fila notificações)

Data: 2026-09-28T05:00Z
Branch: arena/01a0e621-gruposegsystemseguranca

## Objetivo
Finalizar F1 (SEC-11 a SEC-15) e implementar PLT básico de auditoria e notificações.

## SEC-11 — Separar prévias e recursos reais
Aceite: Nenhuma simulação concede permissão ou informa envio inexistente.

Antes:
- /admin/tema botão "Ativar" dizia "todos os clientes veem a mudança imediatamente" mas só alterava documentElement local.
- /admin/funcionarios dizia "Migração 007 aplicada" presumindo execução.
- /admin/marcelo listava recursos como se fossem reais.

Agora:
- /admin/tema reescrito: banner "Prévia local — sem persistência global", botão "Pré-visualizar (local)", texto explica publicação autorizada e rollback em PUB-07 ainda não implementado, sem envio.
- /admin/visual já tinha "Seleção administrativa pausada" e "somente neste navegador (modo de demonstração)" — mantido, adicionado aviso em /admin/ti.
- /admin/funcionarios: banner "Prévia — recurso em modelagem, sem persistência garantida", lista "Migração 007 modelada — execução verificável via runner 001-011, não presumida", "Sem envio fictício".
- /admin/marcelo: banner "Prévia — painel descritivo, sem dados reais", cada card marcado "(futuro)" ou "(prévia local)" ou "(condicional)", explicita dependências F3/F4/F7/PLT-04, "Nenhuma simulação informa envio inexistente".

Verificado: nenhum botão concede permissão real, nenhum texto promete envio de e-mail/entrega quando não há provedor.

## SEC-12 — Privacidade e declarações de aprovação verificáveis
Aceite: Minuta explicitamente pendente enquanto faltar aprovação; texto completo antes de publicar.

Antes:
- /privacidade dizia "Política de Privacidade — Aprovada" e "Minuta validada pelo proprietário. Esta versão é a oficial." — violação, pois não há aprovação formal.

Agora:
- Reescrito como "Política de Privacidade — Minuta (não aprovada)" com banner amarelo "Aviso — Minuta pendente de aprovação formal", estado pendente, noindex mantido, base legal, retenção (12 meses auditoria, CFTV sensível), encarregado a definir (D-11), direitos titular, compartilhamento e segurança (RBAC, sessão segura, CSRF, auditoria), consentimento, próximos passos para aprovação. Data ISO dinâmica.

Verificado: texto completo, mas explicitamente não oficial, sem declaração definitiva de conformidade.

## SEC-13 — Segurança de sessão, CSRF, origem e erros
Aceite: Cookies seguros em produção, origem/CSRF em mutações, JSON limitado, métodos corretos, erro sem stack/segredo.

Implementado:
- server.mjs: SESSION_COOKIE HttpOnly SameSite Lax Max-Age, Secure quando NODE_ENV=production ou X-Forwarded-Proto=https com TRUST_PROXY=true (cookieSecure), sign HMAC SHA256, timingSafeEqual, expiração verificada, roles válidas.
- sameOrigin(req): verifica Origin vs Host, usa X-Forwarded-Host quando TRUST_PROXY=true, retorna false se ausente — usado em todas mutações POST/PUT/PATCH/DELETE (lead, admin, auth, client).
- readJson(req, maxBytes): MAX_BODY_BYTES 8*1024 default, limite por endpoint: client-space upload 15*1024*1024, client-security 15KB via ctx.readJson(req, limit), admin-rbac 15KB.
- Métodos corretos: 405 com Allow header.
- Erros genéricos: json() com error codes (invalid_request, same_origin_required, etc), sem stack, sem segredos, X-Content-Type-Options nosniff, Referrer-Policy no-referrer, Cache-Control no-store.
- clientIp(req): usa X-Forwarded-For quando TRUST_PROXY=true, senão remoteAddress, documentado em .env.example TRUST_PROXY=false.

Verificado: typecheck ok, build ok, testes de unidade não quebram.

## SEC-14 — Auditoria durável e operacional
Aceite: Alterações sensíveis rastreáveis; indisponibilidade de auditoria não gera falsa segurança.

Implementado:
- auth_access_audit com categorias fechadas, sem segredos (nunca gravar senhas/tokens), id BIGINT identity, actor_kind, actor_id, action, target, result, detail_category, created_at.
- Ações expandidas em 011: audit_query, audit_export, invite_rate_limited, notification_enqueue/send/failed/dead/retry, além de todas anteriores (login, mfa, email_change, permission_grant/revoke, etc).
- audit() em cada módulo com try/catch, console.error mas não quebra resposta — indisponibilidade não gera falsa segurança.
- Índices: time, actor, action_time, target, result.
- Retenção 12 meses documentada em data_retention_policies (011) com descrição, sem exclusão automática ainda (prevista).
- PLT-02 adiciona consulta e exportação auditadas.

Verificado: 011 idempotente, lista em migrate script, build ok.

## SEC-15 — Proteção de abuso e identidade
Aceite: Limites de login/convite/formulário/reenvio, respostas antienumeração, proxy/IP confiável definido.

Implementado:
- Login throttle por conta+origem: auth_login_throttle com email, origin_hash (hashOrigin(clientIp)), failures, locked_until, last_failure_at, delays 1/5/15 min após 5ª falha, zera após sucesso ou 24h.
- Resend 5/24h 2min: resendPolicyAllows em client-auth-core.
- Lead rate limit IP: LEAD_WINDOW_MS 10min, LEAD_MAX_ATTEMPTS 5 em server.mjs.
- MFA attempts 5: auth_mfa attempts_since_verified.
- Invite rate limit novo: INVITE_WINDOW_MS 60min, INVITE_MAX_PER_IP 10, INVITE_MAX_PER_ADMIN 20, Map in-memory inviteAttemptsByIp e inviteAttemptsByAdmin, audit invite_rate_limited quando excede, 429 com Retry-After 3600.
- Respostas antienumeração: /api/auth/recover retorna genérica "Se o e-mail existir, enviaremos...", /api/auth/invite/inspect genérico.
- Proxy/IP confiável: TRUST_PROXY env boolean, clientIp() e sameOrigin() e cookieSecure() usam X-Forwarded-* apenas quando TRUST_PROXY=true, documentado em .env.example.

Verificado: testes unitários ok, build ok.

## PLT-02 — Auditoria consultável
Requisito: consultável por autor/ação/objeto/período/resultado, acesso restrito e exportação auditada.

Implementado:
- Migração 011: índices adicionais, ações audit_query/export, tabela data_retention_policies.
- admin-audit-api.mjs: handleAuditList GET /api/admin/audit com query actorKind, actorId, action, target, result, detail_category, from, to, limit (max 200), offset, valida enums, parseDate, WHERE dinâmico, COUNT total, audita audit_query com filtros truncados.
- handleAuditExport POST /api/admin/audit/export com body filters + format json/csv, limit 1000, audita audit_export com contagem e formato, retorna JSON ou CSV com Content-Disposition attachment.
- Acesso restrito: requireAdminSession (marcelo/ti/admin/rh), sameOrigin, 401/403.
- Sem segredos: só campos audit, sem senhas/tokens.
- AuditClient.tsx em /admin/ti: filtros, tabela, botão Exportar JSON (auditado), mensagem retenção 12 meses.

Evidência: build ok, typecheck ok, 46 testes pass.

Pendente: teste integração DB real.

## PLT-04 — Fila durável de notificações
Requisito: destinatário autorizado, deduplicação, tentativas, backoff, falha final e reprocessamento.

Implementado:
- Migração 011: notification_queue com id UUID, dedup_key TEXT unique where not null, recipient_kind enum client/staff/lead/system/marcelo/ti/admin/rh, recipient_id TEXT, recipient_email VARCHAR(254), channel enum email/whatsapp/sms/push/webhook/internal, template 1-100, payload JSONB, status queued/sending/sent/failed/dead, attempts, max_attempts 1-20 default 5, next_attempt_at, last_error 1000, created_by, created_by_id, created_at, sent_at, updated_at, índices status_next, recipient, channel, created, trigger updated_at.
- notification-queue.mjs: enqueue() valida recipient_kind, channel, template, payload, dedup_key, recipient_email, recipient_id, exige recipient para non-system, INSERT ... ON CONFLICT (dedup_key) WHERE dedup_key IS NOT NULL DO NOTHING RETURNING *, retorna dedup flag + existing, audit notification_enqueue; list() com filtros status/channel/recipientKind limit/offset; processNext() SELECT ... FOR UPDATE SKIP LOCKED WHERE status IN (queued,failed) AND next_attempt_at <= NOW() ORDER BY next_attempt_at LIMIT batchSize, update status sending attempts+1, tenta enviar via mailer (nodemailer) se channel email e recipient_email e mailer configurado, senão not_configured -> failed com backoff 1m/5m/15m/60m/240m, se attempts >= max_attempts -> dead, audit send/failed/dead; retry() update status queued next_attempt_at NOW where status failed/dead, audit retry.
- admin-notifications-api.mjs: handleList GET, handleEnqueue POST, handleRetry POST /:id/retry, handleProcess POST /process (só ti/admin/marcelo), sameOrigin + admin session, validações.
- server.mjs: instancia notificationQueue, adminNotificationsApi, rotas /api/admin/notifications, /:id/retry, /process, API_PATH_MATCH expandido.
- NotificationsClient.tsx em /admin/ti: form enqueue com recipientKind, recipientEmail, channel, template, dedupKey, payload JSON, botões Enfileirar e Processar fila, tabela com status, tentativas, próxima tentativa, retry, aviso sem envio real até provedor configurado (D-08).

Sem envio fictício: quando mailer null ou not_configured, marca failed com last_error not_configured, não promete entrega, backoff até dead, reprocessável via retry.

Verificado: build ok, typecheck ok.

Pendente: integração real com SMTP/WhatsApp provedor, teste DB real.

## Validação
- npm test: 46 pass 0 fail 4 skipped (integração requer DB)
- typecheck: ok
- build: ok (Next 16.3.6, 51 páginas)
- Migração 011 idempotente, incluída em runner

## Bloqueios
- PG real ausente sandbox (docker/psql/apt sem rede)
- SMTP real, CNPJ, logotipo, política aprovada, hospedagem pendentes (D-01..D-13)

## Próximo passo
- PLT-03 integrações status configurado/não configurado/falha, último processamento, erros sanitizados e teste de conexão
- PUB-01..PUB-04 site e captação, CRM-01..CRM-10
- Testar integração real PG loopback quando disponível
