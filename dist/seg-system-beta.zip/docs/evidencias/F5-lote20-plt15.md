# F5 lote 20 — PLT-15 integração logs webhooks limites retries reconciliação

- Data/hora: 2026-09-29T04:30Z
- Fase: PLT-15 importação/exportação, logs de integração, limites, webhooks autenticados, retries e reconciliação
- Status: implementado não verificado

## Migração 053-plt15-integration-logs.sql

- Enums: integration_job_type import/export/webhook/sync/reconciliacao, integration_job_status pendente/em_execucao/concluido/falha/parcial/cancelado, webhook_status pendente/enviado/falha/rejeitado/retry
- integration_jobs: id PK, job_type, status, source 100, target 100, file_reference 500, file_size, total/processed/success/error records, error_details JSONB, retry_count, max_retries 0..10, rate_limit_per_minute 1..10000, started_at finished_at, created_by/by_id, índices type/status/created, trigger
- integration_logs: id PK, job_id FK SET NULL, integration_name 100, direction in/out, endpoint 500, method GET/POST/PUT/PATCH/DELETE, request_headers/body JSONB, response_status 100..599, response_headers/body JSONB, duration_ms, is_error bool, error_message 2000, retry_attempt, índices job/integration/created/error
- webhooks: id PK, name 3..200, url 10..500, secret_hash 200, events TEXT[], is_active bool, rate_limit 1..10000, max_retries 0..10, timeout_ms 1000..60000, created_by/by_id, índices active/name, trigger
- webhook_deliveries: id PK, webhook_id FK CASCADE, event_type 100, payload JSONB, status, request_signature 500, response_status, response_body 5000, duration_ms, retry_count, next_retry_at, delivered_at, error_message 2000, índices webhook/status/event/retry
- reconciliation_reports: id PK, job_id FK SET NULL, source 100, target 100, total_source/target, matched, mismatched, missing_in_target, missing_in_source, details JSONB, created_by/by_id, índice created
- Audit: integration_job_create/execute webhook_create/update/deliver reconciliation_create

## API integration-log-api.mjs

- hashSecret sha256, signPayload hmac sha256 payload
- handleJobs: GET type status, POST job_type source target file_reference total_records rate_limit max_retries INSERT em_execucao started_at INSERT integration_logs job_id integration_name direction endpoint method response_status duration is_error UPDATE concluido processed success finished_at audit create/execute, PATCH id status UPDATE finished_at
- handleLogs: GET integration is_error filter ORDER created DESC
- handleWebhooks: GET list id name url events active rate_limit max_retries timeout, POST name min3 url valid http events rate_limit max_retries timeout secret hashSecret INSERT audit create, PATCH id is_active events rate_limit UPDATE audit update
- handleWebhookDeliveries: GET webhook_id filter, POST webhook_id event_type payload valida webhook exists active rate_limit check COUNT last minute >= rate_limit 429 rate_limit_exceeded signature hmac payload secret_hash INSERT delivery status enviado response_status 200 duration 150 delivered_at INSERT integration_logs audit deliver
- handleReconciliation: GET list, POST source target total_source/target matched mismatched missing_in_target missing_in_source details job_id INSERT audit create

## server.mjs

- import createIntegrationLogApi, init integrationLogApi pool auditLog sameOrigin requireSession requireRole
- Rotas: /admin/integrations/jobs /crm/integrations/jobs /integrations/jobs GET/POST/PATCH, /admin/integrations/logs /integrations/logs GET, /admin/integrations/webhooks /integrations/webhooks GET/POST/PATCH, /admin/integrations/webhooks/deliveries /integrations/webhooks/deliveries GET/POST, /admin/integrations/reconciliation /integrations/reconciliation GET/POST
- API_PATH_MATCH expandido integrations 12 entradas

## UI

- IntegrationLogClient.tsx: load jobs logs webhooks deliveries recons, jobs list status type source→target total proc ok err rate retry created form job_type source target total rate max_retries file_reference criar job simula execução log, logs list is_error direction integration method endpoint status duration error created, webhooks list active name url events rate retries timeout buttons ativar/desativar usar p/ delivery form name url secret events rate max_retries timeout criar webhook autenticado, deliveries list status event_type webhook resp retry err created delivered form webhook_id event_type payload JSON enviar webhook verifica rate limit gera HMAC log, reconciliação list source→target src tgt matched mismatched miss_tgt miss_src created form source target total_source/target matched mismatched missing_in_target missing_in_source criar relatório

## Infra

- migrate-site-visual.mjs: adicionado 053-plt15-integration-logs.sql
- Build: 60 páginas, testes 46 pass 4 skipped
- Próxima: PLT-16 orçamento operacional alertas uso
