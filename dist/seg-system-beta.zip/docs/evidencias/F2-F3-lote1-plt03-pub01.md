# F2/F3 lote 1 — PLT-03 integrações status + PUB-01 catálogo único

Data: 2026-09-28T05:30Z
Branch: arena/01a0e621-gruposegsystemseguranca

## PLT-03 — Integrações com status configurado/não configurado/falha, último processamento, erros sanitizados e teste de conexão

### Migração 012
- Tabela `integrations`:
  - `id TEXT PK`
  - `provider TEXT CHECK IN ('smtp','whatsapp','payment','nfe','llm','calendar','storage','sms','push','webhook','other')`
  - `name TEXT 1-100`
  - `status TEXT CHECK IN ('not_configured','configured','failure','testing') DEFAULT not_configured`
  - `config_sanitized JSONB` sem segredos (host [configured]/[not_configured], etc)
  - `last_check_at, last_success_at, last_failure_at, last_error_sanitized 1000 chars sanitizado sem stack/segredos, last_processed_at, created_at, updated_at`
  - Índices provider+status, status+updated_at
  - Trigger updated_at
- `service_catalog` também criado nesta migração (PUB-01)
- Auditoria expandida para `integration_check/test/update` e `catalog_*`

### integrations-api.mjs
- `sanitizeError(err)`: corta 1000 chars, remove password=/token=/key=/secret= com [redacted], remove stack (só primeira linha)
- `sanitizeConfig(config)`: redige chaves que contenham password/secret/token/key
- `ensureDefaultIntegrations(db)`: cria registros padrão se não existirem: smtp, whatsapp, payment, nfe, llm, calendar, storage; atualiza SMTP status baseado em `MAIL_HOST` e `MAIL_FROM` env, config sanitizada com [configured]/[not_configured]
- `handleList`: GET /api/admin/integrations?provider=&status=, sameOrigin, admin session, valida enums, chama ensureDefault, SELECT com filtros, audit integration_check
- `handleTest`: POST /api/admin/integrations/:id/test, sameOrigin, admin, verifica existência, testa por provider:
  - smtp: verifica env, tenta criar nodemailer transporter e verify(), status configured se sucesso, failure com erro sanitizado se falha, not_configured se env ausente
  - outros: not_configured com mensagem "Provedor X não configurado — aguardando D-08 e validação comercial"
  - UPDATE status, last_check_at, last_success_at, last_failure_at, last_error_sanitized, audit integration_test com category status
- `handleUpdate`: PUT/PATCH /api/admin/integrations/:id, cria se não existir quando provider válido, atualiza name/provider, audit integration_update

### Integração server.mjs
- Import `createIntegrationsApi` e `createServiceCatalogApi`
- Instâncias `integrationsApi` e `serviceCatalogApi`
- Rotas:
  - GET /api/admin/integrations
  - POST /api/admin/integrations/:id/test
  - PUT/PATCH /api/admin/integrations/:id
  - GET /api/catalog e /api/services (público)
  - GET /api/catalog/:id e /api/services/:id
- API_PATH_MATCH expandido

### UI
- `IntegrationsClient.tsx` em /admin/ti:
  - Lista integrações com provider, status (cor: configured verde, failure vermelho, not_configured amarelo), config sanitizada, último check/sucesso/falha/processamento, erro sanitizado em destaque vermelho, botão Testar conexão (sanitizado)
  - Acesso restrito admin/ti, mesma origem, sem segredos

## PUB-01 — Catálogo único dos seis serviços validados

### Requisitos
- Catálogo único dos seis serviços validados no projeto
- Cada item tem descrição, público, perguntas de qualificação e flag de publicação
- Cerca elétrica ou novos serviços entram somente após validação comercial

### Implementação arquivo
- `src/lib/service-catalog.mjs` enriquecido:
  - Antes: name, short, question
  - Agora: id, name, short, description (full), audience, questions array, question (compatibilidade), isPublished, isValidated, validationNote
  - 6 serviços: seg_desarmada, monitoramento_24h, cftv, portaria, limpeza, supervisao — todos isPublished true, isValidated true, sem cerca elétrica
  - PROPERTY_TYPES também enriquecido com id e questions array
  - Funções: isPublicService filtra isPublished !== false, isPropertyType, findService, findPropertyType, getPublishedServices(), getServiceById(id), buildRequestSummary (compatível)

### Implementação DB
- Tabela `service_catalog` em 012:
  - id TEXT PK, name UNIQUE 1-100, short_description 1-300, full_description 1-2000, target_audience 1-500, qualification_questions JSONB, is_published bool, is_validated bool, validation_note, created_at, updated_at
  - Índice published+validated, trigger updated_at
  - INSERT 6 serviços validados com ON CONFLICT DO UPDATE (idempotente)

### API
- `service-catalog-api.mjs`:
  - handleList GET /api/catalog?includeUnpublished=&onlyValidated= (default includeUnpublished false, onlyValidated true)
  - Tenta DB, se falha (database_not_configured) fallback para arquivo FALLBACK_SERVICES filtrando isPublished/isValidated, retorna source fallback/database
  - handleGet GET /api/catalog/:id (id ou name), tenta DB, fallback arquivo
  - Público, sem auth, sem segredos

### UI pública
- `/servicos/page.tsx`:
  - Metadata SEO, lista PUBLIC_SERVICES filtrando isPublished && isValidated
  - Cada card: nome, resumo, descrição completa, público, perguntas qualificação ul, links /orcamento?servico= e /simulador?servico=, ID/publicado/validado
  - Seção "Como pedir orçamento" explica PUB-03 mesma API leads com protocolo, consentimento, origem/campanha, antispam, e PUB-04 visita estados depende confirmação humana

### UI admin
- `CatalogClient.tsx` em /admin/ti:
  - GET /api/catalog, grid com descrição curta/completa/público/perguntas, flags validado/publicado, total esperado 6

### Validação
- npm test 46 pass 4 skipped
- typecheck ok
- build ok Next 16.3.6, 52 páginas incluindo /servicos
- Migração 012 idempotente, runner 001-012

### Correção técnica adicional
- Integration tests falhavam com "Cannot find package @next/env" em Next 16.3.6 (Next 16 remove @next/env como pacote separado mas ainda depende dele internamente)
- Corrigido: testes reescritos para import dinâmico com fallback no-op via top-level await, e instalação explícita @next/env@16.3.6 para Next build (next/package.json dependencies @next/env)
- Agora tests 46 pass 4 skipped (integração requer DB loopback) e build ok

## Bloqueios
- PG real ausente sandbox (docker/psql/apt sem rede) — integração DB real ainda pendente
- SMTP real, CNPJ, logotipo, política aprovada, hospedagem pendentes (D-01..D-13)

## Próximo passo
- PUB-02 páginas por serviço e segmento, contato claro, FAQ revisada
- PUB-03/04 orçamento e visita integrados (já parcialmente), visita estados
- CRM-01..CRM-10 cadastro central empresas/contatos, funil
- PLT-05/06 notificações painel e observabilidade
