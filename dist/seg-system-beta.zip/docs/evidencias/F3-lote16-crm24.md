# F3 lote 16 — CRM-24 relatórios

Data: 2026-09-28T11:45Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 54e05ee (CRM-23)

## Requisito
CRM-24: relatórios de conversão por etapa/origem, ciclo de vendas, tarefas atrasadas, motivos de perda, pipeline por período e cenário. Previsão ponderada é estimativa identificada.

## Implementação
### Migração 028
- `db/migrations/028-crm24-reports.sql`
- `crm_report_snapshots` id UUID PK, report_type conversion/sales_cycle/overdue_tasks/loss_reasons/pipeline/weighted_forecast/conversion_origin/pipeline_period/pipeline_scenario, period_start/end DATE, filters JSONB, data JSONB, is_estimate bool true, note 1000, created_by/by_id, índices type/period
- Índices: crm_opps_stage_origin_idx (stage,origin,created_at), crm_opps_loss_reason_idx (loss_reason) WHERE NOT NULL, crm_opps_stage_changed_idx (stage_changed_at), crm_tasks_overdue_idx (due_date,status) WHERE aberta/em_andamento
- Auditoria crm_report_view, crm_report_snapshot

### API
- `src/server/report-api.mjs`
- STAGE_PROBABILITY: novo 10%, qualificacao 20%, vistoria 40%, proposta_elaboracao 50%, proposta_enviada 60%, negociacao 80%, ganho 100%, perdido 0%
- `handleConversion` GET periodStart/end/origin, stage COUNT SUM GROUP BY stage, origin COUNT won lost SUM GROUP BY origin, total won conversionRate
- `handleSalesCycle` GET AVG EXTRACT EPOCH stage_changed_at-created_at /86400 avg_days_to_current_stage avg_days_to_won avg_days_to_lost, byStage AVG GROUP BY stage
- `handleOverdueTasks` GET limit 200 JOIN opportunities/companies WHERE due_date<NOW() status aberta/em_andamento ORDER BY due_date, COUNT total
- `handleLossReasons` GET WHERE stage=perdido loss_reason NOT NULL GROUP BY loss_reason COUNT SUM, totalLost
- `handlePipeline` GET periodStart/end groupBy WHERE stage NOT IN ganho/perdido forecast_date filtros, byStage COUNT SUM AVG GROUP BY stage, byPeriod date_trunc month GROUP BY month, byScenario service_name/service_id GROUP BY service, total COUNT SUM, isEstimate true
- `handleWeightedForecast` GET WHERE stage NOT IN ganho/perdido estimated_value NOT NULL, calcula weighted = estimated*probabilidade, totalEstimated totalWeighted byStage COUNT SUM estimated probability weighted, opportunities detailed 100, probabilities map, note ESTIMATIVA identificada
- `handleAllReports` GET summary total won lost total_value overdue_tasks pipeline_value + reports list

- `server.mjs` rotas `/api/crm/reports`, `/conversion`, `/sales-cycle`, `/overdue-tasks`, `/loss-reasons`, `/pipeline`, `/weighted-forecast`, API_PATH_MATCH expandido

### UI
- `src/app/admin/ti/ReportClient.tsx`
- Fetch todos relatórios, resumo total/won/lost/total_value/overdue/pipeline
- Tabelas conversão por etapa/origem, ciclo vendas média dias, tarefas atrasadas 20, motivos perda, pipeline por etapa/período/cenário, previsão ponderada com probabilidades e aviso ESTIMATIVA identificada em destaque amarelo

## Previsão ponderada como estimativa identificada
- Probabilidades por etapa definidas em STAGE_PROBABILITY, exibidas na UI e na API com note explícito "Previsão ponderada é ESTIMATIVA identificada, não garantia"
- isEstimate true, is_estimate_identified true, note com probabilidades e aviso não é garantia de faturamento
- UI destaca em fundo amarelo com texto ESTIMATIVA

## Validação
- npm test 46 pass 4 skipped
- npx next build ok 59 páginas (Next 16.3.6)
- migrate-site-visual 001-028

## Próximo
CRM-25..27 metas comissões, CON-01..CON-11 contratos e implantação, PLT-05..18
