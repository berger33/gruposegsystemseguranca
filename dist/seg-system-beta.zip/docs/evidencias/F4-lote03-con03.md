# F4 lote 03 — CON-03 estados, transições, assinatura vs ativação operacional

Data: 2026-09-28T14:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit: c4c073b -> atual (CON-03)

## Requisito
CON-03: estados rascunho, em revisão, aguardando assinatura, ativo, suspenso e encerrado; transições autorizadas e data de efeito. Não confundir assinatura com ativação operacional.

## Implementação

### Migração 034
- `db/migrations/034-con03-contract-status-transitions.sql`
- ALTER TYPE `crm_contract_status` ADD VALUE `em_revisao`, `aguardando_assinatura` (com exception duplicate_object)
- Colunas `crm_contracts`:
  - `signed_at TIMESTAMPTZ` — data/hora assinatura
  - `signed_by TEXT 1..120` — quem assinou
  - `signed_by_id UUID FK auth_identities`
  - `operational_activated_at TIMESTAMPTZ` — ativação operacional distinta
  - `current_status_effective_date DATE` — data de efeito do status atual
  - `suspension_reason TEXT 1..1000`
  - `closure_reason TEXT 1..1000`
  - `status_changed_at TIMESTAMPTZ`
  - `status_changed_by TEXT 1..80`
  - `status_changed_by_id UUID`
  - Índices: `signed_at`, `operational_activated_at`, `current_status_effective_date`
- Tabela `crm_contract_status_history`:
  - `id UUID PK`
  - `contract_id UUID FK CASCADE`
  - `previous_status crm_contract_status`
  - `next_status crm_contract_status NOT NULL`
  - `effective_date DATE NOT NULL` — data de efeito obrigatória
  - `reason TEXT 1..1000`
  - `is_signature_event BOOL default false`
  - `is_operational_activation BOOL default false`
  - `signed_at TIMESTAMPTZ`, `operational_activated_at TIMESTAMPTZ`
  - `changed_by TEXT 80 NOT NULL`, `changed_by_id UUID`
  - `created_at TIMESTAMPTZ default NOW()`
  - Índices: `(contract_id, effective_date DESC)`, `(next_status, effective_date)`, partial signature, partial activation
- Auditoria: `crm_contract_status_change`, `crm_contract_signed`, `crm_contract_activated`, `crm_contract_suspended`, `crm_contract_closed`

### API contract-status-api.mjs
- `handleStatusHistory` GET `/api/crm/contracts/:id/status-history`
  - Retorna contrato com `status`, `signed_at`, `signed_by`, `operational_activated_at`, `current_status_effective_date`, `suspension_reason`, `closure_reason`
  - Lista histórico ordenado por `effective_date DESC`
  - `allowed_transitions` baseado no status atual
  - `all_statuses`: rascunho, em_revisao, aguardando_assinatura, ativo, suspenso, encerrado, cancelado
  - Nota: assinatura distinta de ativação operacional
- `handleStatusTransition` POST `/api/crm/contracts/:id/status`
  - Body: `next_status` enum, `effective_date` DATE obrigatória (valida future <=1 ano), `reason`, `is_signature_event`, `is_operational_activation`, `signed_by`, `suspension_reason`, `closure_reason`, `signed_at` opcional
  - Validação `ALLOWED_TRANSITIONS`:
    - rascunho → em_revisao, cancelado
    - em_revisao → rascunho, aguardando_assinatura, cancelado
    - aguardando_assinatura → em_revisao, ativo, cancelado
    - ativo → suspenso, encerrado, cancelado
    - suspenso → ativo, encerrado, cancelado
    - encerrado, cancelado → terminal []
  - Regra assinatura vs ativação:
    - Se `current=aguardando_assinatura` e `next=ativo`, exige `signed_at` já existente ou `is_signature_event` ou `signed_at` no body, senão 409 `signature_required_before_activation`
    - `is_signature_event` marca assinatura, seta `signed_at`, `signed_by`
    - `is_operational_activation` só permitido para `ativo`, seta `operational_activated_at = effective_date`
    - Quando `ativo` vindo de `aguardando_assinatura`, seta `operational_activated_at`
  - Transação: BEGIN, INSERT histórico, UPDATE contrato `status`, `current_status_effective_date`, `status_changed_at/by`, `signed_at/by`, `operational_activated_at`, `suspension_reason`, `closure_reason`, COMMIT
  - Auditoria: status_change, signed, activated, suspended, closed
- `handleSignatureEvent` POST `/api/crm/contracts/:id/signature`
  - Registra assinatura separada sem mudar status (útil para distinguir)
  - Só permitido em `aguardando_assinatura` ou `ativo`
  - Body: `signed_at`, `signed_by`, `reason`
  - INSERT histórico com `previous_status=next_status=current`, `is_signature_event=true`
  - UPDATE contrato `signed_at`, `signed_by`
  - Auditoria signed

### contract-api.mjs PATCH atualizado
- `ALL_STATUSES` inclui `em_revisao`, `aguardando_assinatura`
- Se `status` no body, exige `effective_date`, valida `ALLOWED_TRANSITIONS`, verifica assinatura obrigatória antes ativação, INSERT histórico, UPDATE com `current_status_effective_date`, `operational_activated_at`, `suspension_reason`, `closure_reason`
- Senão mantém update normal para outros campos
- Auditoria `crm_contract_status_change`

### server.mjs
- Import `createContractDetailsApi`, `createContractStatusApi`
- Instancia `contractDetailsApi`, `contractStatusApi`
- Rotas:
  - `/api/crm/contracts/:id/posts` (CON-02)
  - `/:id/sla`, `/:id/obligations`, `/:id/exclusions`, `/:id/schedule`
  - `/api/crm/contracts/:id/status-history` GET (CON-03)
  - `/api/crm/contracts/:id/status` POST (CON-03)
  - `/api/crm/contracts/:id/signature` POST (CON-03)

### UI ContractStatusClient.tsx
- `contract_id` input + Carregar status/histórico
- Mostra contrato: id, status, efeito, assinatura (data + por), ativação operacional, suspensão, encerramento
- Mostra permitidas a partir do status atual + todos
- Form transição: `next_status` select (rascunho, em_revisao, aguardando_assinatura, ativo, suspenso, encerrado, cancelado), `effective_date` YYYY-MM-DD *, `reason`, `signed_by`, `suspension_reason`, `closure_reason`, checkboxes `is_signature_event`, `is_operational_activation`, botão Transitar
- Regras descritas
- Form assinatura separada: `signed_at`, `signed_by`, `reason`, botão Registrar assinatura (não ativa operacionalmente)
- Histórico lista: previous→next efeito assinatura/ativação motivo por data

### migrate-site-visual.mjs
- Inclui `034-con03-contract-status-transitions.sql`, log 001-034

## Validação
- `npm test`: 50 total, 46 pass, 4 skipped, 0 fail
- `npx next build`: 59 páginas (inclui /admin/ti com ContractStatusClient), Next 16.3.6, sem erros
- Migração idempotente com IF NOT EXISTS e exception duplicate_object para enum ADD VALUE
- Transições autorizadas com data de efeito obrigatória, assinatura distinta de ativação operacional verificada

## Decisões
- DT-92: criar migração 034
- DT-93: implementar contract-status-api
- DT-94: integrar server.mjs, contract-api PATCH, UI

## Próximo passo
- CON-04 aditivos e reajustes com base, vigência, justificativa, aprovação e histórico
