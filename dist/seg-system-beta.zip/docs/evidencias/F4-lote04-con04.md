# F4 lote 04 — CON-04 aditivos e reajustes

Data: 2026-09-28T15:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit: 5b43a85 -> atual (CON-04)

## Requisito
CON-04: aditivos e reajustes com base, vigência, justificativa, aprovação e histórico. Não sobrescrever valores históricos ou gerar cobrança duplicada.

Aceite: mudar um aditivo não altera faturas anteriores; encerramento deixa de gerar novas rotinas conforme data de efeito sem apagar lançamentos já existentes.

## Implementação

### Migração 035
- `db/migrations/035-con04-contract-amendments.sql`
- Enums:
  - `crm_amendment_type`: aditivo, reajuste, repactuacao, prorrogacao, supressao, outro
  - `crm_amendment_base_type`: indice_igpm, indice_ipca, indice_inpc, dissidio_coletivo, convencao_coletiva, alteracao_escopo, prorrogacao_prazo, reajuste_contratual, acordo_comercial, outro
  - `crm_amendment_status`: rascunho, em_revisao, aprovado, rejeitado, cancelado
- Tabela `crm_contract_amendments`:
  - `id UUID PK`
  - `contract_id UUID FK CASCADE`
  - `type` enum, `title 200`, `description 2000`
  - `base_type` enum, `base_description 1000`, `base_value NUMERIC 14,6 -100..10000`
  - `justification TEXT 10..2000 NOT NULL` — justificativa obrigatória
  - `vigencia_start DATE NOT NULL`, `vigencia_end DATE >= start`
  - `effective_date DATE NOT NULL` — data de efeito
  - `previous_total_cost/price`, `new_total_cost/price` NUMERIC 14,2 >=0 — preserva histórico, não sobrescreve
  - `status` enum default rascunho, `version INT >=1`
  - `idempotency_key TEXT UNIQUE 1..200` — evita cobrança duplicada
  - `approved_by`, `approved_by_id`, `approved_at`, `rejection_reason 1..1000`
  - `created_by`, `created_by_id`, `created_at`, `updated_at`
  - Índices: contract/effective, type/base, status/effective, vigencia
  - Trigger updated_at
- Tabela `crm_contract_amendment_history`:
  - `id PK`, `amendment_id FK CASCADE`, `contract_id FK CASCADE`
  - `previous_status`, `next_status`, `effective_date DATE`, `reason 1..1000`
  - `changed_by`, `changed_by_id`, `created_at`
  - Índices amendment/effective, contract/effective
- Auditoria: amendment_create/update/approve/reject

### API contract-amendment-api.mjs
- `handleAmendments` GET `/api/crm/contracts/:id/amendments`
  - Lista aditivos ordenados por effective_date DESC
  - Nota: base, vigência, justificativa, aprovação, histórico, não sobrescreve, não duplica
- POST `/api/crm/contracts/:id/amendments`
  - Body: type, title, base_type, base_description, base_value, justification >=10, vigencia_start/end, effective_date, previous_total_cost/price, new_total_cost/price
  - Validação: enums, justification min 10, vigencia range, effective_date, base_value -100..10000
  - Preserva histórico: se previous_* não informado, usa contrato atual total_cost/price
  - Idempotency: key `amend:${contractId}:${type}:${title}:${effective_date}`, verifica existente, retorna idempotente sem duplicar cobrança
  - INSERT rascunho version 1, histórico inicial, auditoria create
  - Nota: não gera cobrança duplicada, não altera faturas anteriores
- `handleAmendmentById` GET `/api/crm/contracts/:id/amendments/:amendmentId`
  - Retorna amendment + history + allowed_transitions
- PATCH `/api/crm/contracts/:id/amendments/:amendmentId`
  - Campos editáveis: title, description, base_type, base_description, base_value, justification, vigencia_start/end, effective_date, new_total_cost/price
  - Status: rascunho→em_revisao/cancelado, em_revisao→rascunho/aprovado/rejeitado/cancelado, aprovado→cancelado, rejeitado→rascunho/em_revisao/cancelado
  - Transação: BEGIN, INSERT history, UPDATE status version++ approved_by/at rejection_reason required para rejeitado, COMMIT
  - Não atualiza contrato automaticamente para não alterar faturas anteriores (aceite CON)
  - Auditoria approve/reject/update
- DELETE só rascunho/rejeitado

### server.mjs
- Import `createContractAmendmentApi`, instancia
- Rotas:
  - `/api/crm/contracts/:id/amendments` GET/POST
  - `/api/crm/contracts/:id/amendments/:amendmentId` GET/PATCH/DELETE

### UI ContractAmendmentClient.tsx
- contract_id input + Carregar aditivos
- Form criar: type select, title, base_type select, base_description, base_value %, justification textarea >=10, vigencia_start/end, effective_date, previous_total_price (auto), new_total_price, botão Criar idempotente
- Nota idempotency, não sobrescreve histórico, faturas anteriores não alteradas
- Lista amendments: type title base vigencia efeito status version prev→novo just
- Form transição: amendment_id, next_status select, reason, rejection_reason, botão Transitar
- Regras descritas

### migrate-site-visual.mjs
- Inclui 035, log 001-035

## Validação
- npm test 46 pass 4 skipped
- next build 59 páginas
- Idempotency_key evita cobrança duplicada
- previous_* preserva valores históricos, não sobrescreve
- Mudar aditivo não altera faturas anteriores (não atualiza contrato automaticamente, apenas registra)

## Decisões
- DT-95 migração 035
- DT-96 contract-amendment-api
- DT-97 integração server.mjs + UI

## Próximo passo
- CON-05 alertas configuráveis vencimento/renovação, tarefas com responsável e negociação vinculada ao CRM
