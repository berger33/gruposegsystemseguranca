# F0 — Inventário do estado atual (SEC-01)
Data: 2026-09-28
Branch: arena/01a0e621-gruposegsystemseguranca
Commit inicial: 49d366cd9335ca33fe9703a397dc0488b6468ef8 (referência do plano)
Commit atual: (ver git log)
Repositório: berger33/gruposegsystemseguranca

## Objetivo
Mapear rotas, APIs, tabelas, jobs, permissões e documentação no commit atual, classificando como real/parcial/prévia/ausente e registrando divergências com a documentação histórica.

## Rotas Next.js (src/app)

| Rota | Estado | Observação |
|---|---|---|
| / (layout 06) | real | Padrão, formulário integrado à API /api/leads |
| /layout-01 .. /layout-10 | real (prévias estáticas) | Preservadas, mas sem backend; /layout-06 é padrão |
| /simulador | real | 4 etapas, grava via mesma API de leads, sem preço |
| /orcamento | parcial | Confirmação local sem gravação, preço ilustrativo, divergência catálogo (SEC-10) |
| /privacidade | parcial | Minuta, sem aprovação formal (SEC-12) |
| /cliente (antiga) | prévia | Informativa, sem auth |
| /cliente/acesso, /cliente/painel, /cliente/conta, /cliente/contratos, /cliente/documentos, /cliente/chamados | prévia | Protótipos em memória, sem persistência |
| /cliente/entrar, /cliente/convite, /cliente/confirmar-email, /cliente/recuperar-senha, /cliente/redefinir-senha | real | Etapa 1 verificada, com integração real |
| /cliente/alterar-email, /cliente/seguranca | parcial/prévia | UI existe, mas API backend incompleta (SEC-07) |
| /cliente/app, /cliente/app/contratos, /cliente/app/documentos, /cliente/app/chamados, /cliente/app/portal | real | Etapa 2 verificada, com vínculo verificado |
| /admin/leads | real | Lista leads + auditoria |
| /admin/clientes | real | Cadastros, vínculos, contratos, documentos, chamados |
| /admin/funcionarios | prévia | Descritiva, modelagem 007 pronta mas sem UI funcional |
| /admin/marcelo | prévia | Descritiva, dashboard futuro |
| /admin/ti | prévia | Descritiva, RBAC/auditoria modelo |
| /admin/tema, /admin/visual | parcial | Theme engine local, não persistido global (SEC-11) |
| /admin/portal, /admin/portal/convites, /admin/portal/solicitacoes, /admin/portal/autocadastro, /admin/portal/permissoes, /admin/portal/alertas | prévia | Protótipos em memória, sem envio real |

## APIs (server.mjs + src/server/*)

| Endpoint | Método | Estado | Auth | Observação |
|---|---|---|---|---|
| /api/site-visual | GET/PUT | real | admin session (marcelo/ti) | Config global, auditada |
| /api/leads | POST | real | rate limit IP, sameOrigin | Validação pura + DB + SMTP opcional |
| /api/admin/session | GET/POST/DELETE | real | token compartilhado (marcelo/ti) | SEC-04/SEC-05 pendente: ainda usa tokens compartilhados |
| /api/admin/leads | GET | real | admin session | Lista leads |
| /api/admin/leads/:id | PATCH | real | admin session | Atualiza status + auditoria |
| /api/auth/login, /api/auth/logout, /api/auth/me | POST/POST/GET | real | client session | Etapa 1, throttle, sessões revogáveis |
| /api/auth/invite/inspect, /api/auth/invite/accept | GET/POST | real | token hash | Convite 7 dias, uso único |
| /api/auth/confirm-email, /api/auth/confirm-email/resend | POST | real | token hash / email | 7 dias, 5 reenvios/24h |
| /api/auth/recover, /api/auth/reset | POST | real | token hash | 1h, resposta genérica, revoga sessões |
| /api/admin/invites | GET/POST | real | admin session | Emite convite client, hash token, SMTP opcional |
| /api/admin/invites/:id | DELETE | real | admin session | Revoga idempotente |
| /api/client/accounts, /api/client/contracts, /api/client/documents, /api/client/documents/:id/download, /api/client/tickets | GET/POST | real | client session + grant ativo + account active | Etapa 2, deny-by-default, mas com falhas abertas em unidade/contrato (SEC-02) |
| /api/client/security/mfa/verify | POST | parcial/bugado | client session | Usa req.json/res.status incompatível, TOTP demonstrativo (SEC-06) |
| /api/client/security/email-change | POST/PUT/DELETE | parcial/bugado | client session | Não verifica senha atual corretamente, fluxo incompleto (SEC-07) |
| /api/admin/identities | GET | real | admin session | Busca identidades client |
| /api/admin/client-accounts, /api/admin/client-accounts/:id | GET/POST/PATCH | real | admin session | Cadastro central |
| /api/admin/grants, /api/admin/grants/:id | GET/POST/DELETE | real | admin session | Vínculo com motivo obrigatório |
| /api/admin/contracts, /api/admin/contracts/:id | GET/POST/PATCH | real | admin session | Valida serviço contra catálogo |
| /api/admin/documents, /api/admin/documents/:id/download | GET/POST | real | admin session | Upload base64, storage privado |
| /api/admin/tickets, /api/admin/tickets/:id | GET/PATCH | real | admin session | Status + auditoria |

## Tabelas (db/migrations)

| Migração | Tabelas | Estado |
|---|---|---|
| 001-site-visual.sql | site_visual_config, site_visual_audit | real, idempotente |
| 002-public-leads.sql | public_leads, public_lead_status_audit | real |
| 003-client-access.sql | auth_identities, auth_credentials, auth_sessions, auth_invites, auth_email_tokens, auth_login_throttle, auth_access_audit | real, verificada por integração |
| 004-client-space.sql | client_accounts, client_access_grants, client_contracts, client_documents, client_tickets, client_ticket_status_audit | real, verificada |
| 005-client-security.sql | client_access_grants cols contract_scope_mode, allowed_contract_ids, unit_account_id, client_access_grant_contracts, auth_mfa, auth_email_change | real, mas runner não aplicava (SEC-08) |
| 006-admin-identities.sql | auth_identities kind=staff, auth_invites role, auth_staff_profiles, auditoria ampliada | real, mas runner não aplicava + constraints reaplicação |
| 007-opcao-b-funcionarios.sql | staff_posts, staff_assignments, staff_scale_rules, staff_time_entries, staff_shift_handover | real, modelagem, sem UI |

Jobs/workers: não há fila durável (PLT-04 pendente). SMTP via nodemailer, sem fila.

## Permissões

| Sistema | Estado |
|---|---|
| Admin via SITE_ADMIN_TOKEN_MARCELO/TI | real, mas compartilhado, sem conta individual (SEC-04/SEC-05) |
| Staff via auth_identities kind=staff + auth_staff_profiles | parcial: schema existe, mas login ainda não usa (server.mjs não integra) |
| Client via auth_identities kind=client + grant | real, deny-by-default, mas com falhas abertas (SEC-02) |
| RBAC detalhado (domain.action) | ausente: só roles marcelo/ti, sem permissões granulares (PLT-01) |
| Auditoria | real, mas retenção 12 meses não ativa (PLT-02) |

## Documentação

| Doc | Estado |
|---|---|
| README.md | real, reconciliado com links do plano |
| docs/PLANO-MESTRE-IMPLEMENTACAO.md | incorporado de branch documental |
| docs/PROMPT-MASTER-ARENA.md | incorporado |
| docs/CONTROLE-IMPLEMENTACAO.md | incorporado, 222 IDs |
| docs/DECISOES-IMPLEMENTACAO.md | criado nesta execução (F0) |
| docs/plano-produto.md, portal-acesso-e-seguranca.md, etc | histórico, com divergências registradas no plano cap 3 |
| docs/evidencias/ | iniciado nesta execução |

## Divergências com documentação histórica (cap 3 do plano)

- README anterior afirmava telas como ativas que eram prévias; corrigido com distinção real/prévia.
- server.mjs ainda usa tokens compartilhados, mas docs já mencionavam RBAC individual — divergência confirmada.
- client-space-api tinha falhas silenciosas que ampliavam escopo — corrigir nesta execução.
- client-security-api usava API incompatível (req.json/res.status) — bug confirmado.
- migrate script listava só 001-004 — divergência com 005-007 existentes.
- /orcamento com preço ilustrativo — não é fluxo real.
- /admin/tema com atributo local — não equivale a publicação global.
- /privacidade com minuta não aprovada — pendente.

## Testes

| Suíte | Comando | Resultado esperado | Estado atual |
|---|---|---|---|
| Unitários puros | npm test | 46 testes (plano) | Verificar no ambiente |
| Integração lead | RUN_DATABASE_INTEGRATION=1 npm run test:integration | 34 asserções em 3 suítes | Requer PostgreSQL loopback + captura SMTP |
| client-auth-core | npm test | validadores | ok |
| client-space-core | npm test | validadores | ok |
| client-security integration | RUN_DATABASE_INTEGRATION=1 | MFA, email change, vínculo restrito | Simula consultas sem exercitar todas alegações (SEC-09) |

Sem DATABASE_URL loopback, integrações fazem skip — nada provado.

## Próximo passo (F0 → F1)

- Corrigir SEC-02 (deny-by-default) e SEC-03 (documentos por contrato)
- Corrigir SEC-08 (runner migrações)
- Corrigir SEC-06/SEC-07 (MFA e troca e-mail) com biblioteca mantida
- Corrigir SEC-04/SEC-05 (auth individual staff)
- Atualizar CONTROLE-IMPLEMENTACAO.md com estados verificados
