# F5 lote 18 — PLT-13 gestão configurações flags manutenção rollout

- Data/hora: 2026-09-29T03:30Z
- Fase: PLT-13 gestão de configurações, flags, manutenção, rollout e reversão; negócio separado infraestrutura
- Status: implementado não verificado

## Migração 051-plt13-config-flags.sql

- Enums: config_category negocio/infra/seguranca/operacao/comercial/financeiro/rh/outro, config_flag_status ativo/inativo/em_teste/depreciado, maintenance_status agendado/em_execucao/concluido/cancelado/falha, rollout_status rascunho/aprovado/em_rollout/concluido/revertido/falha
- config_flags: id PK, key 200, category, status, value JSONB, default_value JSONB, description 10..2000, is_secret bool, is_business bool, environment all/development/homologation/production, rollout_percentage 0..100, allowed_roles TEXT[], created_by/by_id updated_by/by_id, UNIQUE(key,environment), índices key/category/status/env, trigger
- config_history: id PK, flag_id FK CASCADE, previous/next value, previous/next status, reason 1000, changed_by/by_id, índices flag/created
- maintenance_windows: id PK, title 10..200, description 20..2000, status, scheduled_start/end, actual_start/end, affected_services TEXT[], is_business_impact bool, notification_sent bool, rollback_plan 2000, created_by/by_id, índices status/scheduled, trigger, CHECK end>start
- rollout_plans: id PK, flag_id FK SET NULL, title 10..200, description 20..2000, status, current_percentage 0..100, target_percentage 0..100, steps JSONB, rollback_to JSONB, approved_by/by_id/at, started_at finished_at, created_by/by_id, índices flag/status, trigger
- Seed 5 flags: catalogo_publicacao_automatica negocio {"enabled":false}, orcamento_aprovacao_desconto_alcada negocio {"limite_percentual":15}, retencao_logs_seguranca_meses seguranca {"meses":12}, manutencao_modo infra {"enabled":false}, feature_plantao_troca negocio {"enabled":true} ON CONFLICT DO NOTHING
- Audit: config_flag_create/update/rollback maintenance_create/update rollout_create/approve/execute/rollback

## API config-api.mjs

- ALLOWED_MAINT agendado->[em_execucao,cancelado] em_execucao->[concluido,falha] falha->[agendado]
- ALLOWED_ROLLOUT rascunho->[aprovado,falha] aprovado->[em_rollout,revertido,falha] em_rollout->[concluido,revertido,falha] concluido->[revertido] revertido->[rascunho]
- handleFlags: GET filtros category status environment is_business mask secrets value->{masked:true}, POST valida key min3 category status description min10 env rollout_percentage value object secret_cannot_be_business upsert ON CONFLICT key+env INSERT history audit create
- handleFlagById: GET flag+history mask secret, PATCH valida status value rollout_percentage UPDATE history INSERT audit update, POST rollback history_id valida rollback para previous_value/status history INSERT audit rollback
- handleMaintenance: GET list, POST valida title min10 description min20 schedule required invalid_schedule affected_services is_business_impact rollback_plan INSERT audit create, PATCH id next_status valida transition allowed reason UPDATE actual_start/end audit update
- handleRollouts: GET list, POST valida flag_id title min10 description min20 target_percentage steps INSERT audit create, PATCH id next_status current_percentage valida transition allowed UPDATE approved_by/at started_at finished_at se revertido busca config_history último previous_value rollback flag value audit approve/execute/rollback

## server.mjs

- import createConfigApi, init configApi pool auditLog sameOrigin requireSession requireRole
- Rotas: /admin/config/flags /crm/config/flags /config/flags GET/POST, /:id GET/PATCH/POST rollback, /admin/config/maintenance /crm/config/maintenance /config/maintenance GET/POST/PATCH, /admin/config/rollouts /crm/config/rollouts /config/rollouts GET/POST/PATCH
- API_PATH_MATCH expandido config 12 entradas

## UI

- ConfigClient.tsx: load flags maintenances rollouts, list flags [NEGOCIO]/[INFRA] category key status env pct secreto value, form criar flag key category status env rollout is_business is_secret description value JSON upsert, flag selecionada history previous→next value por reason rollback button, manutenção list status title schedule impact affected_services buttons iniciar concluir cancelar form title affected_services schedule start/end is_business_impact description rollback_plan agendar, rollout list status title current→target flag buttons aprovar rollout 50% concluir 100% reverter form flag_id target title description steps JSON criar, aviso negócio separado infra secret masking history rollback manutenção rollback_plan rollout reversão automática valor anterior

## Infra

- migrate-site-visual.mjs: adicionado 051-plt13-config-flags.sql
- Build: 60 páginas, testes 46 pass 4 skipped
- Próxima: PLT-14 revisão dependências lockfile vulnerabilidades CI
