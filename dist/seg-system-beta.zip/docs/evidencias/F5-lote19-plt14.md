# F5 lote 19 — PLT-14 revisão dependências lockfile vulnerabilidades CI

- Data/hora: 2026-09-29T04:00Z
- Fase: PLT-14 revisão de dependências, lockfile, vulnerabilidades, atualizações e CI
- Status: implementado não verificado

## Migração 052-plt14-dependencies.sql

- Enums: dependency_audit_status pendente/em_analise/aprovado/rejeitado/corrigido, dependency_severity info/low/moderate/high/critical, dependency_update_type major/minor/patch/security
- dependency_audits: id PK, audit_date, total/prod/dev dependencies, vulnerabilities info/low/moderate/high/critical, outdated_count, audit_raw JSONB, status, reviewed_by/by_id/at, notes 2000, created_by/by_id, índices date/status
- dependency_vulnerabilities: id PK, audit_id FK CASCADE, package_name 200, severity, title 5..500, url 500, vulnerable_versions 200, patched_versions 200, recommendation 1000, status, fixed_in_version 100, índices audit/package/severity
- dependency_updates: id PK, package_name 200, current_version 100, latest_version 100, update_type, is_breaking bool, changelog_url 500, status, approved_by/by_id/at, applied_at, notes 1000, índices package/status/type, trigger
- Audit: dependency_audit_create/review update_approve/apply

## API dependency-api.mjs

- handleAudits: GET list, POST total/prod/dev vulnerabilities info/low/moderate/high/critical outdated audit_raw notes INSERT audit create, PATCH id status notes UPDATE reviewed_by/at audit review
- handleVulns: GET audit_id filter ORDER severity critical>high>moderate>low
- handleUpdates: GET list, POST package_name current_version latest_version update_type is_breaking changelog_url notes INSERT, PATCH id status notes UPDATE approved_by/at applied_at audit approve/apply
- handleLockfile: GET fs read package-lock.json lockfileVersion packagesCount + package.json dependencies devDependencies scripts

## server.mjs

- import createDependencyApi, init dependencyApi pool auditLog sameOrigin requireSession requireRole
- Rotas: /admin/dependencies/audits /crm/dependencies/audits /dependencies/audits GET/POST/PATCH, /admin/dependencies/vulnerabilities /dependencies/vulnerabilities GET, /admin/dependencies/updates /dependencies/updates GET/POST/PATCH, /admin/dependencies/lockfile /dependencies/lockfile GET
- API_PATH_MATCH expandido dependencies 12 entradas

## CI

- .github/workflows/ci.yml: on push branches main arena/* pull_request main, jobs test runs-on ubuntu-latest steps checkout@v4 setup-node@v4 node 20 cache npm Install npm ci Audit npm audit --audit-level=high audit --json Typecheck npm run typecheck Tests npm test Build npx next build Check migrations grep 052-plt14 Check lockfile cat package-lock lockfileVersion npm ls, security job checkout Check secrets BEGIN PRIVATE KEY sk_live Verify .env not committed
- npm audit 2026-09-29: 0 vulnerabilities info 0 low 0 moderate 0 high 0 critical total 77 prod 31 dev 7 optional 40 peer 0, lockfileVersion 3

## UI

- DependencyClient.tsx: load audits vulns updates lockfile, lockfile pre JSON, audits list status date total prod dev vuln i/l/m/h/c outdated por buttons aprovar corrigido form total prod dev high critical outdated notes registrar audit atual, vulns list severity package title vulnerable→patched status, updates list status type package current→latest breaking buttons aprovar aplicado form package_name type current latest breaking notes registrar, CI descrição workflow

## Infra

- migrate-site-visual.mjs: adicionado 052-plt14-dependencies.sql
- Build: 60 páginas, testes 46 pass 4 skipped
- Próxima: PLT-15 importação/exportação logs integração limites webhooks
