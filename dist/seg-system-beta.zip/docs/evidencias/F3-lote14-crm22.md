# F3 lote 14 — CRM-22 aceite por link seguro expirável vinculado à versão

Data: 2026-09-28T11:15Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: c99e909 (CRM-21)

## Requisito
CRM-22: aceite por link seguro, expirável e vinculado à versão, se adotado; decisão jurídica sobre valor do aceite registrada. Não chamar clique simples de assinatura qualificada.

## Implementação
### Migração 026
- `db/migrations/026-crm22-acceptance-link.sql`
- `crm_proposal_acceptance_links` id UUID PK, proposal_id FK CASCADE, proposal_version int, token_hash VARCHAR 64 UNIQUE (sha256), token_prefix 4-20, recipient_email 5-320, recipient_name 200, expires_at TIMESTAMPTZ CHECK future, status ativo/usado/expirado/revogado, is_used bool, used_at, used_ip_hash 64, used_user_agent 500, legal_value_note 2000, legal_decision_by 200, legal_decision_by_id UUID, legal_decision_at TIMESTAMPTZ, is_qualified_signature bool false, is_simple_click bool true, CHECK is_simple_click=false OR is_qualified_signature=false, CHECK expires future, created_by/by_id, índices token_hash/proposal/version/recipient/status/expires, trigger updated_at, auditoria crm_acceptance_link_create/used.

### API
- `src/server/proposal-acceptance-api.mjs`
- `generateSecureToken()` randomBytes 32 base64url, `hashToken()` sha256, `tokenPrefix()` 8 chars.
- `handleLinks`:
  - GET filtros proposalId/status count+list limit 200, ordena expires_at.
  - POST valida proposal_id UUID, proposal_version int optional, recipient_email 5-320 regex, recipient_name 200, expires_days 1-90 default 7, legal_value_note 10-2000, acceptance_note 2000.
  - Verifica proposta existe, resolve version = input or proposal.version, verifica snapshot preservado SELECT crm_proposal_versions WHERE proposal_id+version, se não existe retorna `version_not_preserved_cannot_create_secure_link` 409.
  - INSERT ativo com token_hash UNIQUE, token_prefix, recipient, expires_at NOW+expires_days, status ativo, is_used false, is_qualified false, is_simple true, legal_value_note default decisão jurídica explícita: "Decisão jurídica: aceite por link seguro expirável vinculado à versão vX representa manifestação de vontade para contratação, não se confunde com assinatura qualificada ICP-Brasil. Valor do aceite: aceitação da proposta na versão vinculada, sujeita a contrato posterior. Responsável jurídico a validar."
  - Retorna token apenas uma vez, secureLink `/proposta/aceite/:token`, note aceite simples não assinatura qualificada, audit create.
- `handleAcceptByToken`:
  - GET token raw, hash sha256, SELECT link, verifica expires_at NOW > expires marca expirado UPDATE status expirado, se status != ativo retorna link_not_active ou expired, busca snapshot preservado, se não existe 409 version_not_preserved, retorna proposal_id version recipient legal_value_note is_qualified false is_simple true snapshot.
  - POST valida confirm true, signer_name 1-200, acceptance_note 2000, hash token, SELECT link, verifica expires ativo, verifica proposta status enviada/aprovada_para_envio se não 409 proposal_not_in_sendable_status, verifica version mismatch link proposal_version vs proposal.version se diferente retorna version_mismatch_link_bound_to_version 409, marca usado UPDATE is_used true used_at NOW used_ip_hash sha256(clientIp) used_user_agent 500 status usado, UPDATE crm_proposals SET status aceita WHERE id=proposal_id AND status IN (enviada, aprovada_para_envio), INSERT crm_proposal_signatures accepted_via_secure_link com is_qualified false, webhook_payload JSONB {token_prefix, acceptance_note, legal_value_note, is_qualified false, is_simple true, ip_hash, user_agent, secure_link}, audit used.
- `handleLinkById` GET/PATCH legal_value_note 10-2000.

- `server.mjs` integra createProposalAcceptanceApi, rotas `/api/crm/proposal-acceptance-links`, `/:id`, `/api/crm/proposals/accept/:token` público (sem sameOrigin para GET/POST aceitação mas com audit IP hash), API_PATH_MATCH expandido.

### UI
- `src/app/admin/ti/ProposalAcceptanceClient.tsx`
- Form criar link seguro expirável vinculado à versão proposal_id/version/recipient_email/name/expires_days/legal_value_note/acceptance_note, token mostrado apenas uma vez com secureLink, ações view token GET e aceitar token POST com signer_name prompt, lista links tabela proposta v/token prefix/destinatário/expira/status/usado/jurídico/qualificada?/clique simples? com cores ativo amarelo usado verde expirado vermelho.

## Decisão jurídica
- legal_value_note registrada por link, default explícito que aceite simples não é assinatura qualificada ICP-Brasil, valor do aceite é manifestação de vontade para contratação na versão vinculada, sujeita a contrato posterior, responsável jurídico a validar.
- is_qualified_signature=false, is_simple_click=true, CHECK garante não confundir clique simples com qualificada.
- Nota em todas respostas API: "aceite simples não assinatura qualificada, decisão jurídica registrada em legal_value_note".

## Segurança
- Token 32 bytes random, base64url, hash sha256 armazenado, token mostrado apenas uma vez.
- token_prefix 8 chars para identificação sem expor token.
- expires_at CHECK future, status ativo/usado/expirado/revogado, is_used flag.
- used_ip_hash sha256(clientIp) + used_user_agent 500 para auditoria sem expor IP puro.
- Snapshot preservado obrigatório para criar link (version_not_preserved_cannot_create_secure_link), vinculação à versão com version_mismatch_link_bound_to_version.
- Proposta deve estar enviada/aprovada_para_envio para aceitar.
- Sem simulação de assinatura qualificada.

## Validação
- npm test 46 pass 4 skipped
- npx next build ok 59 páginas (Next 16.3.6)
- migrate-site-visual 001-026

## Próximo
CRM-23..27 proposta aceita cria contrato idempotente, relatórios, CON-01..CON-11, PLT-05..18.
