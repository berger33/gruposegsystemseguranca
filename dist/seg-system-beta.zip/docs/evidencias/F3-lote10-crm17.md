# Evidência F3 lote 10 — CRM-17 cenários preço/margem

Data: 2026-09-28T09:30Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 49d366cd -> HEAD atual
Objetivo: CRM-17 cenários de preço e margem, separando margem de markup. Para tributos proporcionais à receita e margem sobre receita, simulação pode usar preço = custo / (1 - taxa - margem), somente sob premissas explícitas, denominador válido e aprovação contábil. Não impor essa fórmula a todos os regimes.

## Implementação

### Migração 022
- `db/migrations/022-crm17-price-scenarios.sql`
- Tipos: crm_price_formula_type margem_receita/markup_custo/custom/outro, crm_price_scenario_status rascunho/em_revisao/aprovado/arquivado.
- `crm_price_scenarios`: id UUID PK, company_id/opportunity_id/technical_budget_id/labor_budget_id FK SET NULL, title 200, description 2000, base_cost 14,2 >=0, tax_rate 8,6 0..1, margin_percent -100..100, markup_percent -100..500, price_calculated/price_by_margin_formula/price_by_markup 14,2 >=0, formula_type enum, premises 2000 CHECK (formula_type != margem_receita OR char_length(premises)>=10), denominator_valid bool, denominator_value 10,6, tax_is_proportional_to_revenue bool, margin_is_on_revenue bool, requires_accounting_approval bool default true, approval_status enum default rascunho, version int, approved_by/at/role, accounting_approved_by/at/note 1000, notes 2000, created_by/by_id, created_at/updated_at, índices company/opportunity/tech/labor/status/formula, trigger updated_at.

### API
- `src/server/price-scenario-api.mjs`
- `calcPrices`: price_by_markup = cost * (1+markup/100), price_by_margin = cost / (1 - tax_rate - margin_dec) se denominator>0.000001, denominator_valid bool, price_calculated conforme formula_type.
- `handleScenarios`: GET valida admin+sameOrigin filtros companyId/opportunityId/techBudgetId/laborBudgetId/status/formula_type count+list ORDER BY created_at DESC limit 200, POST valida title 200 base_cost>=0 tax_rate 0..1 (se >1 assume % e converte /100) margin -100..100 markup -100..500 formula enum premises>=10 se margem_receita senão 400 premises_required_for_margin_formula, denominator_valid check senão invalid_denominator_for_margin_formula, INSERT rascunho version 1 RETURNING *, audit create.
- `handleScenarioById`: GET, PATCH recalc com essential_check: SELECT COUNT(*) FROM crm_cost_parameters WHERE is_essential=true AND approval_status!='aprovado' -> se >0 bloqueia aprovação 409 essential_params_missing_cannot_approve_official_price, para margem_receita com requires_accounting_approval exige accounting_approval_note>=10 senão accounting_approval_required_for_margin_formula, version++ updated_at approved_by/at/role accounting_approved_by/at/note, audit status_aprovado/update.
- Separação margem vs markup explícita: dois campos price_by_margin_formula e price_by_markup, formula_type escolhe qual usar, não impõe fórmula a todos regimes.

### Server
- `server.mjs`: import createPriceScenarioApi, instancia, rotas /api/crm/price-scenarios, /:id, API_PATH_MATCH expandido.

### UI
- `src/app/admin/ti/PriceScenarioClient.tsx`
- Form criar cenário: title, base_cost, tax_rate % (ex 10 para 10%), margin % sobre receita, markup % sobre custo, formula_type select margem_receita/markup_custo/custom/outro, tax_is_proportional checkbox, margin_is_on_revenue checkbox, company_id/technical_budget_id/labor_budget_id opcionais, premises textarea obrigatório para margem_receita, notes.
- Lista: total, tabela título/custo/taxa/margem/markup/fórmula/denom/valid/preço margem/markup/calc/status/premises.
- Mensagem explica fórmula só sob premissas explícitas, denominador válido, aprovação contábil.

### Migrate script
- `scripts/migrate-site-visual.mjs`: 001-022.

## Validação
- npm test: 46 pass 0 fail 4 skipped.
- npx next build: Next 16.3.6, 59 páginas.
- Migrações idempotentes 001-022.
- Fórmula margem_receita: preço = custo / (1 - taxa - margem) só quando tax_is_proportional && margin_is_on_revenue && premises>=10 && denominator>0 && aprovação contábil, não imposta a todos regimes (markup_custo usa custo*(1+markup)).

## Critério de aceite CRM-17
- Cenários preço/margem separando margem de markup: implementado via price_by_margin_formula vs price_by_markup e formula_type.
- Para tributos proporcionais à receita e margem sobre receita, simulação pode usar preço = custo / (1 - taxa - margem): implementado em calcPrices com tax_rate decimal e margin_dec, denominator_valid check.
- Somente sob premissas explícitas, denominador válido e aprovação contábil: CHECK premises>=10 para margem_receita, invalid_denominator_for_margin_formula, accounting_approval_required_for_margin_formula.
- Não impor fórmula a todos regimes: formula_type outro/custom/markup_custo permitidos, cada cenário escolhe fórmula.

## Próximo passo
CRM-18 alçadas desconto.

## Produção
Não liberada, noindex mantido.
