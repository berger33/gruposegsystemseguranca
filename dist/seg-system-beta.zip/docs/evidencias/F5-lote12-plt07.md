# F5 Lote 12 — PLT-07 Healthcheck Liveness Readiness — Evidência

Data: 2026-09-28T23:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Base: 7e1a5c8 (PLT-06)

## Objetivo PLT-07
Healthcheck/liveness/readiness, degradação explícita de dependências e painel operacional restrito.

## Migração 045
- Enums: health_status healthy/degraded/unhealthy/unknown, dependency_type database/storage/email/whatsapp/payment/nfe/llm/queue/other
- Tabelas:
  - operational_health_checks: check_name 100, dependency_type, status, latency_ms, is_degraded bool, degradation_reason 1000, error_sanitized 1000, metadata JSONB, checked_at, índices name/status/dep
  - operational_status: overall_status, is_degraded, degraded_dependencies TEXT[], checks JSONB, created_at índice created
- Auditoria: healthcheck_query/ready/live (mantido no CHECK ampliado)

## API healthcheck-api.mjs
- sanitizeError remove password/token/secret
- checkDatabase: SELECT 1, latency, healthy/unhealthy, degraded true se falha, error_sanitized sem segredos
- checkQueue: COUNT queued notification_queue, degraded se >100, metadata queued
- checkIntegrations: COUNT total failures WHERE status failure, degraded se failures>0, metadata total failures
- checkObservability: getMetrics 5xx>5 degraded, metadata http_5xx jobs_failed
- runAllChecks: Promise.all checks, overall healthy/degraded/unhealthy, is_degraded, degraded_dependencies map name, timestamp uptime
- handleLive: 200 { status healthy, check liveness, timestamp uptime, note liveness processo }
- handleReady: runAllChecks, dbCheck healthy? ready true else false, statusCode 200 se ready mesmo degraded, 503 se not ready, INSERT health_checks e operational_status async, return ready, note Ready com degradação explícita / Not ready crítica falhou
- handleHealth: operational panel? verifica sameOrigin e admin/ti restricted se /api/admin/ ou /operational, audit healthcheck_query, return runAllChecks + note healthcheck degradação explícita sem segredos painel restrito
- handleOperationalHistory: sameOrigin admin/ti, limit 50, SELECT checks status_history ORDER BY DESC, note histórico healthcheck painel restrito

- Rotas server.mjs: /api/health/live /liveness /health/live, /api/health/ready /readiness /health/ready, /api/health /health /healthcheck, /api/admin/operational /admin/health /crm/operational (history=true -> handleOperationalHistory), /operational/history
- API_PATH_MATCH expandido health/operational

## Server.mjs integração observabilidade mantida
- getObservability lazy, getPool wrapPool, notificationQueue observability, routeApi wrapper requestId correlationId X-Request-Id/Correlation-Id writeHead capture status try routing catch 500 finally recordHttp session ip ua path duration

## UI HealthcheckClient
- type health/live/ready/operational, load fetch /api/health etc, msg overall degraded ready uptime
- Grid checks: name dependency status degraded latency degradation_reason error_sanitized metadata
- JSON raw slice 5000
- Histórico: checks list checked_at name dependency_type status degraded latency degradation_reason, status_history overall degraded deps

## Validação
- npm test 46 pass 4 skipped
- npx next build 59 páginas OK
- migrate-site-visual 001-045

## Próximos
- PLT-08 backup criptografia retenção restauração testada isolado
- PLT-09 privacidade completa inventário bases destinatários prazos contatos direitos revisão competente
- PLT-10..18
