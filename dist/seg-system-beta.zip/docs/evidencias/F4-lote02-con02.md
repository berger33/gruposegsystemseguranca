# F4 lote 02 — CON-02 itens recorrentes/avulsos, postos/turnos, SLA, obrigações, exclusões, cronograma

Data: 2026-09-28T13:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: db293dc (CON-01)

## Requisito
CON-02: itens recorrentes e avulsos, postos/turnos contratados, SLA, obrigações de cada parte, exclusões e cronograma.

## Implementação
### Migração 033
- `db/migrations/033-con02-contract-posts-sla.sql`
- Tipos: crm_post_shift diurno/noturno/12x36_dia/12x36_noite/24x48/comercial/madrugada/outro, crm_sla_service vigilancia/portaria/limpeza/monitoramento/manutencao/atendimento/outro, crm_obligation_party contratante/contratada/ambas
- `crm_contract_posts` id UUID PK, contract_id FK CASCADE, title 200, description 1000, shift, quantity 1..100, schedule JSONB dias/inicio/fim, location 200, unit_id FK SET NULL, is_24h bool, recurrence_type recorrente/avulso/implantacao/outro, índices contract/unit, trigger
- `crm_contract_sla` id UUID PK, contract_id FK CASCADE, service_type, description 1000, response_time_minutes, resolution_time_minutes, availability_percent, penalty_description 1000, índices contract/service, trigger
- `crm_contract_obligations` id UUID PK, contract_id FK CASCADE, party, title 200, description 2000, due_date DATE, status pendente/em_andamento/concluida/atrasada/cancelada, índices contract/party/status, trigger
- `crm_contract_exclusions` id UUID PK, contract_id FK CASCADE, description 2000, category 100, índices contract
- `crm_contract_schedule` id UUID PK, contract_id FK CASCADE, milestone 200, description 1000, planned_date DATE, completed_date DATE, status planejado/em_andamento/concluido/atrasado/cancelado, responsible_name 120, índices contract/planned/status, trigger
- Auditoria: post_create/update/remove, sla_create/update, obligation_create/update, exclusion_create, schedule_create/update

### API
- `src/server/contract-details-api.mjs`
- `handlePosts` GET list, POST title 200 shift enum quantity 1..100 location unit_id is_24h recurrence_type schedule JSONB, DELETE id
- `handleSla` GET list, POST service_type enum description 1000 response/resolution/availability/penalty
- `handleObligations` GET list, POST party contratante/contratada/ambas title 200 description 2000 due_date
- `handleExclusions` GET list, POST description 2000 category, DELETE
- `handleSchedule` GET list, POST milestone 200 planned_date DATE responsible_name, PATCH milestone/description/planned_date/completed_date/status/responsible_name

- `server.mjs` rotas `/api/crm/contracts/:id/posts`, `/:id/sla`, `/:id/obligations`, `/:id/exclusions`, `/:id/schedule`

### UI
- `src/app/admin/ti/ContractDetailsClient.tsx`
- Input contract_id, load
- Forms: posto title/shift/quantity/location/recurrence_type, SLA service_type/description/response/availability, obrigação party/title/description/due_date, exclusão description/category, cronograma milestone/planned_date/responsible_name
- Listas correspondentes

## Itens recorrentes e avulsos
- contract_items já tinha recurrence_type recorrente/avulso/implantacao/outro
- contract_posts também tem recurrence_type para postos recorrentes/avulsos/implantação
- UI distingue recorrente/avulso/implantacao/outro

## Validação
- npm test 46 pass 4 skipped
- npx next build ok 59 páginas (Next 16.3.6)
- migrate-site-visual 001-033

## Próximo
CON-03..CON-11, PLT-05..18
