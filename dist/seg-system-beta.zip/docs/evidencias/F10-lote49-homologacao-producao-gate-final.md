# F10 lote49 — Homologação usuários + Produção gate final + Verificação EXT-01..17 + AI-10

Data: 2026-09-28T18:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 502fb74 F9 lote48 EXT-01..17 + AI-10
Decisão usuário: ext_all (Todas EXT-01..17 + AI-10) + ai_none (AI-01..09 desligado, só AI-10 determinística)

## Objetivo
Homologação representativa (Marcelo, Andreia, funcionário, cliente) em ambiente homologação sem dados reais + verificação final implementação EXT-01..17 + AI-10 + produção gate sem publicar automaticamente nem contratar serviços.

## Verificação EXT-01..17 + AI-10 (implementado não verificado → verificado implementação)

### EXT-01 frota própria
- [x] 085: ext_fleet_vehicles plate 3..20 UNIQUE, model 3..200, manufacturer 2..200, year 1900..2100, fuel_type enum gasolina/etanol/diesel/flex/eletrico/hibrido/outro, responsible_name 2..200, mileage, cost_center 3..100, notes 10..1000, status disponivel/em_uso/em_manutencao/baixado/reservado, created_by_identity
- [x] Histórico/custo por veículo: fuel_logs vehicle_id CASCADE fuel_date liters>0 cost_cents mileage station 3..200, maintenance_logs maintenance_type 3..100 description 10..2000 cost_cents mileage performed_at next_due_date, trigger atualiza last_maintenance_date next_maintenance_date veículo
- [x] Alerta manutenção: next_maintenance_date, last_maintenance_date, expiry_date docs
- [x] Documentos: fleet_documents vehicle_id CASCADE document_type 3..100 document_number 3..200 expiry_date file_name 1..500 file_url 5..1000 storage_key 5..500 UNIQUE
- [x] API: handleFleetVehicles GET/POST/PATCH, handleFleetFuelLogs GET/POST, handleFleetMaintenanceLogs GET/POST atualiza veículo, handleFleetDocuments GET/POST
- [x] UI: ExtClient frota placa UNIQUE fuel status km centro custo notas, abastecimentos custo por veículo, manutenções alerta próxima, docs
- [x] Segurança: sameOrigin, requireSession, requireRole admin/ti, audit_log

### EXT-02 terceiros
- [x] 085: ext_third_parties name 3..200 document 3..30 category 3..100 contract_id FK crm_contracts SET NULL responsible_name 2..200 access_start/end CHECK end>=start evaluation_score 0..10 notes 10..1000 status ativo/inativo/suspenso/encerrado
- [x] Acessa só OS/contrato autorizado perde acesso ao término: access_logs third_party_id CASCADE access_type granted_by revoked_at reason, PATCH status encerrado → INSERT access_logs revogacao
- [x] Documentos: third_party_documents third_party_id CASCADE document_type 3..100 file_name 1..500 file_url 5..1000 storage_key UNIQUE expiry_date
- [x] API: handleThirdParties GET/POST/PATCH revogação, handleThirdPartyDocuments GET/POST
- [x] UI: ExtClient terceiros nome doc categoria contrato responsável acesso início/fim avaliação notas status botão Encerrar revoga

### EXT-03 licitações
- [x] 085: ext_bidding_notices protocol LIC-EXT-YYYYMMDD-XXXX UNIQUE title 5..200 description 10..2000 edital_number 3..200 UNIQUE deadline>=publication responsible_name 2..200 estimated_value_cents status rascunho/publicado/em_analise/homologado/vencido/cancelado/deserto
- [x] Checklist alerta por edital dossiê versionado: bidding_documents bidding_id CASCADE document_type 3..100 file_name 1..500 file_url 5..1000 storage_key UNIQUE version auto MAX+1
- [x] API: handleBiddingNotices GET/POST/PATCH, handleBiddingDocuments GET/POST versionado
- [x] UI: ExtClient edital título desc edital UNIQUE deadline≥publication valor estimado protocolo LIC-EXT- status

### EXT-04 portal fornecedores
- [x] 085: ext_supplier_portal_quotations protocol FORN-EXT- supplier_id FK ast_suppliers product_id FK ast_products quantity>0 unit_price total_price notes 10..1000 is_visible_to_supplier bool status rascunho/enviado/em_analise/aprovado/rejeitado/cancelado
- [x] Fornecedor não vê concorrente nem dados RH: is_visible_to_supplier bool, API GET retorna supplier_name product_name sem expor RH, POST is_visible_to_supplier flag
- [x] API: handleSupplierPortalQuotations GET/POST/PATCH
- [x] UI: ExtClient cotação fornecedor supplier_id product_id quantity unit/total visível ao fornecedor status

### EXT-05 qualidade
- [x] 085: ext_quality_nonconformities protocol QUAL-EXT- title 5..200 description 10..2000 category 3..100 severity baixa/media/alta/critica responsible_name 2..200 related_contract_id cause/corrective/verification recurrence_count status aberta/em_analise/em_acao_corretiva/verificacao/encerrada/reaberta
- [x] Encerrar apenas com evidência e responsável: PATCH status encerrada → CHECK cause>=10 corrective>=10 verification>=10
- [x] Ações: quality_actions nonconformity_id CASCADE action_type 3..100 description 10..2000 responsible_name 2..200 due_date status pendente/concluida/cancelada completed_at
- [x] API: handleQualityNonconformities GET/POST/PATCH encerrar apenas com evidência, handleQualityActions GET/POST/PATCH
- [x] UI: ExtClient NC título desc categoria severidade responsável protocolo QUAL-EXT- status causa corrective verification

### EXT-06 satisfação/carteira
- [x] 085: ext_satisfaction_surveys protocol SAT-EXT- client_account_id contract_id survey_type pesquisa/csat/nps/outro score 0..10 comment 10..2000 recovery_task 10..2000 status pendente/em_acompanhamento/concluida/cancelada
- [x] Resposta gera acompanhamento sem expor funcionário: recovery_task sem expor funcionário, API POST score comment recovery_task
- [x] API: handleSatisfactionSurveys GET/POST/PATCH
- [x] UI: ExtClient pesquisa satisfação cliente tipo score status comment recovery

### EXT-07 compliance
- [x] 086: ext_compliance_documents protocol COMP-EXT- title 5..200 description 10..2000 compliance_type licenca/certidao/seguro/alvara/outro document_number 3..200 issuer 3..200 responsible_name 2..200 issue_date expiry_date CHECK expiry>=issue file_name 1..500 file_url 5..1000 storage_key UNIQUE is_private true status vigente/a_vencer/vencida/em_renovacao/cancelada
- [x] Vencimento gera tarefa documento privado: is_private true, expiry_date, status, API GET ordena expiry_date ASC
- [x] API: handleComplianceDocuments GET/POST/PATCH
- [x] UI: ExtAdvancedClient compliance título desc tipo número emissor responsável emissão/validade file storage_key UNIQUE status

### EXT-08 base conhecimento
- [x] 086: ext_knowledge_base slug+version UNIQUE slug 3..200 title 5..200 content 50..20000 category 3..100 version tags JSONB access_roles JSONB status rascunho/em_revisao/aprovado/publicado/arquivado is_published published_at, history kb_id previous_version next_version change_summary, acks
- [x] Procedimentos versionados busca acesso ciência usuário encontra apenas conteúdo de seu escopo: access_roles filtra, tags, version auto MAX+1, nova versão se content muda, is_published só se status publicado
- [x] API: handleKnowledgeBase GET/POST/PATCH nova versão se content muda history
- [x] UI: ExtAdvancedClient KB slug versão UNIQUE conteúdo 50..20000 categoria tags access_roles status

### EXT-09 expansão/unidades
- [x] 086: ext_expansion_plans protocol EXP-EXT- title 5..200 description 10..2000 premises 10..2000 target_location 3..200 capacity estimated_cost/revenue is_estimate true estimate_note status rascunho/em_analise/aprovado/rejeitado/em_execucao/concluido/cancelado
- [x] Premissas e fonte visíveis sem projeção vendida como certeza is_estimate: is_estimate true, estimate_note, premises 10..2000, API GET nota premissas visíveis
- [x] Cenários: expansion_scenarios plan_id scenario_name 3..200 premises 10..2000 projected_cost/revenue projected_margin GENERATED (revenue-cost)/cost*100 UNIQUE(plan_id,scenario_name)
- [x] API: handleExpansionPlans GET/POST/PATCH, handleExpansionScenarios GET/POST UNIQUE scenario_name por plano
- [x] UI: ExtAdvancedClient plano expansão título desc premissas local capacidade custo/receita protocolo EXP-EXT- status margem, cenários

### EXT-10 continuidade operacional
- [x] 086: ext_continuity_plans protocol CONT-EXT- title 5..200 description 10..2000 client_account_id contract_id post_id 3..200 contacts JSONB contingency_steps JSONB recovery_steps JSONB responsible_name 2..200 last_tested_at next_test_due status rascunho/aprovado/em_teste/testado/desatualizado/arquivado, exercises continuity_plan_id exercise_type result
- [x] Simulado documentado com responsáveis: contacts, contingency_steps, recovery_steps, responsible_name, last_tested_at/next_test_due, exercises
- [x] API: handleContinuityPlans GET/POST/PATCH
- [x] UI: ExtAdvancedClient continuidade título desc client/contract/post contacts/contingency/recovery JSONB responsável last/next test protocolo CONT-EXT- status

### EXT-11 analytics/A-B
- [x] 086: ext_analytics_experiments protocol AB-EXT- hypothesis 20..2000 description 10..2000 variant_a/b 3..200 metric_name 3..100 result_a/b_value winner A/B/empate/inconclusivo privacy_compliant true status rascunho/em_execucao/concluido/cancelado/arquivado
- [x] Experimento reversível resultado sem dados inventados privacy_compliant: privacy_compliant true, result_a/b_value, winner, hypothesis 20..2000, API nota experimento reversível
- [x] API: handleAnalyticsExperiments GET/POST/PATCH winner
- [x] UI: ExtAdvancedClient analytics hipótese 20..2000 desc variante A/B métrica protocolo AB-EXT- status winner

### EXT-12 editor visual avançado
- [x] 086: ext_visual_tokens token_key+version UNIQUE token_key 3..200 token_value JSONB category 3..100 version status rascunho/em_revisao/aprovado/publicado/arquivado/revertido is_published published_at preview_url, visual_layouts layout_key+version UNIQUE layout_data JSONB version status is_published preview_url, editor_history token_id/layout_id previous/next version change_summary
- [x] Permissão real recarga consistente e rollback: version auto MAX+1, nova versão se token_value muda, history, is_published só se status publicado, status revertido
- [x] API: handleVisualTokens GET/POST/PATCH nova versão se value muda history rollback, handleVisualLayouts GET/POST/PATCH versionado
- [x] UI: ExtAdvancedClient tokens token_key versão UNIQUE token_value categoria status is_published preview_url permissão real recarga consistente rollback, layouts

### EXT-13 relatório periódico
- [x] 087: ext_periodic_reports protocol RELP-EXT- title 5..200 description 10..2000 report_type diario/semanal/mensal/trimestral/anual/sob_demanda period_start/end CHECK end>=start filters JSONB totals JSONB storage_key UNIQUE recipient_emails TEXT[] privacy_compliant true status rascunho/gerando/gerado/enviado/falhou/cancelado generated_at sent_at, report_logs report_id action actor_identity
- [x] Gerado apenas de dados reais escopo cliente autorizado sem dado inventado sem dado não autorizado: privacy_compliant true, filters/totals JSONB, recipient_emails, API nota apenas dados reais escopo autorizado
- [x] API: handlePeriodicReports GET/POST/PATCH generated_at
- [x] UI: ExtReportingClient relatórios título desc tipo period_start/end filters totals storage_key UNIQUE recipient_emails protocolo RELP-EXT- status

### EXT-14 inteligência comercial
- [x] 087: ext_commercial_intelligence protocol INTEL-EXT- title 5..200 description 10..2000 intel_type mercado/cliente/concorrente/tendencia/risco/oportunidade source_module 3..100 score 0..10 justification 10..2000 obrigatória related_client_id contract_id is_human_approved false approved_by/at status rascunho/em_analise/aprovada/rejeitada/arquivada/em_uso
- [x] Justificativa obrigatória uso bloqueado sem aprovação humana: justification 10..2000 CHECK, is_human_approved false, PATCH em_uso → CHECK is_human_approved true
- [x] API: handleCommercialIntelligence GET/POST/PATCH human_approval required for em_uso
- [x] UI: ExtReportingClient inteligência título desc tipo source_module score justificativa obrigatória protocolo INTEL-EXT- status is_human_approved

### EXT-15 apoio emergencial
- [x] 087: ext_emergency_channels name 3..200 channel_type telefone/whatsapp/email/sms/push/radio/outro recipient_contact 5..500 availability JSONB escalation JSONB description 10..2000 is_tested bool last_tested_at test_result CHECK tested=>last_tested_at status ativo/inativo/em_teste/falhou/suspenso
- [x] Testar recebimento e atendimento antes disponibilizar: is_tested, last_tested_at, test_result, emergency_tests channel_id test_type 3..100 result 3..2000 marca canal testado se result contém sucesso/ok/recebido
- [x] API: handleEmergencyChannels GET/POST/PATCH is_tested last_tested_at test_result, handleEmergencyTests GET/POST marca testado se sucesso
- [x] UI: ExtReportingClient canais emergenciais nome tipo recipient availability escalation desc status is_tested último resultado, testes

### EXT-16 central/vídeo
- [x] 087: ext_central_projects protocol CENT-EXT- title 5..200 description 10..2000 scope 10..2000 provider 3..200 privacy_assessment 10..5000 client_account_id is_privacy_approved bool privacy_approved_by/at is_approved bool approved_by/at status rascunho/em_analise_privacidade/aprovado_privacidade/em_implantacao/implantado/rejeitado/arquivado, central_events project_id event_type status
- [x] Projeto separado privacidade aprovada antes implantação: is_privacy_approved, privacy_assessment 10..5000, PATCH em_implantacao → CHECK is_privacy_approved true
- [x] API: handleCentralProjects GET/POST/PATCH privacy_approval required for em_implantacao
- [x] UI: ExtReportingClient central título desc escopo provider privacy_assessment client_account protocolo CENT-EXT- status is_privacy_approved is_approved

### EXT-17 biometria/reconhecimento
- [x] 087: ext_biometry_projects protocol BIO-EXT- title 5..200 description 10..2000 biometry_type facial/digital/iris/voz/outra necessity 20..2000 impact_assessment 20..5000 legal_basis 10..2000 client_account_id is_approved bool approved_by/at collection_active false status rascunho/em_analise_privacidade/aprovado_privacidade/em_implantacao/ativo/suspenso/arquivado/rejeitado CHECK collection_active=>is_approved
- [x] Projeto separado privacidade aprovada não coletar por padrão collection_active requires is_approved: collection_active false default, CHECK collection_active=>is_approved, PATCH ativo → CHECK is_approved true
- [x] API: handleBiometryProjects GET/POST/PATCH collection_requires_approval
- [x] UI: ExtReportingClient biometria título desc tipo necessity impact legal_basis protocolo BIO-EXT- status is_approved collection_active

### AI-10 automações determinísticas
- [x] 087: ext_ai_deterministic_automations name 3..200 description 10..2000 automation_type vencimento/distribuicao_tarefa/cobranca_interna/notificacao/relatorio/outra rules JSONB is_deterministic true CHECK schedule_cron 5..100 last_run_at next_run_at run_count error_count status ativa/inativa/em_teste/falhou/pausada, automation_logs automation_id action 3..200 result 3..5000 success duration_ms
- [x] Vencimentos distribuição tarefas cobrança interna antes agentes autônomos AI-01..09 desligado: is_deterministic true, automation_type vencimento/distribuicao_tarefa/cobranca_interna, rules JSONB, AI-01..09 desligado por decisão ai_none 2026-09-28
- [x] API: handleAiAutomations GET/POST/PATCH, handleAiAutomationLogs GET/POST atualiza run_count error_count last_run_at next_run_at
- [x] UI: ExtReportingClient automações nome desc tipo vencimento/distribuicao_tarefa/cobranca_interna regras cron status determinística runs erros último, logs

## Homologação usuários (pendente execução humana, ambiente preparado)

### Ambiente homologação sem dados reais
- [x] Código preparado para homologação: build Next 16.3.6 59 páginas ok, migrações 001-087 idempotentes, APIs 28 handlers EXT + 19 AST + 18 FIN + etc, UI ExtClient/ExtAdvanced/ExtReporting
- [ ] Execução humana pendente: PG real ausente sandbox, D-01..D-13, SMTP real, CNPJ, logotipo, política aprovada, hospedagem pendentes (bloqueios de negócio documentados)
- [ ] Usuários representativos pendentes: Marcelo, Andreia, funcionário, cliente representativo ambiente homologação sem dados reais domínio próprio TLS cookies base URL corretos banco usuário runtime restrito usuário migração separado armazenamento privado ciclo vida scheduler/worker responsabilidade acompanhar falhas contas reais somente fluxo seguro entrega manual/autorizada convite sem senha padrão

### Checklist homologação (para executar quando ambiente real disponível)
- [ ] Domínio próprio TLS: PUBLIC_BASE_URL configurado, BIND_HOST 0.0.0.0, PORT 3000, cookie Secure quando forwarded_proto https, TRUST_PROXY true
- [ ] Base URL corretos: PUBLIC_BASE_URL trim replace /+$ fallback http://localhost:port
- [ ] Banco usuário runtime restrito: DATABASE_URL, DATABASE_POOL_SIZE 5, idleTimeout 30s, connectionTimeout 5s, application_name grupo-seg-system-site, usuário runtime restrito sem DDL em produção, usuário migração separado
- [ ] Armazenamento privado ciclo vida: CLIENT_DOCS_DIR .data/documents, file_url 5..1000 storage_key 5..500 UNIQUE, is_private true compliance, privacy inventory, retention policies 1..3650, disposal jobs, backup_jobs encryption_enabled AES-256-GCM retention_until is_restore_tested is_isolated
- [ ] Scheduler/worker responsabilidade acompanhar falhas: notification_queue dedup_key UNIQUE status queued/sending/sent/failed/dead attempts backoff 1m/5m/15m/60m/240m, observability_http_requests/job_executions/db_metrics/metrics, operational_health_checks latency_ms is_degraded, observability_alerts threshold current message, backup_jobs/restores, integration logs jobs/logs/webhooks/deliveries/reconciliation
- [ ] Contas reais somente fluxo seguro entrega manual/autorizada convite sem senha padrão: auth_identities kind staff/client email UNIQUE status active/pending_email, auth_credentials password_hash, auth_staff_profiles role admin/ti/rh, client-access-api invites kind staff/client role token_hash UNIQUE token_prefix expires_at status ativo/usado/expirado/revogado is_used used_at used_ip_hash used_user_agent, rate limit 10/h IP 20/h admin, convite sem senha padrão, troca e-mail fluxos backend real, MFA opcional, gestão sessões

## Produção gate final (não publicar automaticamente)

### Segurança SEC-01..15 verificado
- [x] SEC-01..15 verificado F8 lote47: login individual staff, RBAC granular, auditoria consultável, fila durável, integrações, catálogo, equipamentos, etc, CI check secrets BEGIN PRIVATE KEY sk_live .env not committed, audit 0 vuln total 77 deps lockfileVersion 3, cookies Secure, sameOrigin, JSON limitado, métodos corretos, erro sem stack, proxy confiável TRUST_PROXY, throttle login/lead/resend/mfa/invite

### Observabilidade PLT-06 verificado implementação
- [x] observability_http_requests request_id correlation_id method path status_code duration_ms user_kind user_id ip_hash user_agent_hash error_sanitized, job_executions, db_metrics, metrics, operational_health_checks check_name dependency_type status healthy/degraded/unhealthy/unknown latency_ms is_degraded degradation_reason error_sanitized metadata, alerts alert_key metric_name severity info/warning/critical status firing/acknowledged/resolved/suppressed threshold current message correlation_id

### Healthcheck PLT-07 verificado implementação
- [x] /api/health/live liveness, /api/health/ready readiness, /api/health healthcheck, /api/admin/operational, /api/admin/health, operational_status overall_status is_degraded degraded_dependencies checks

### Backup PLT-08 verificado implementação restauração testada ambiente isolado
- [x] backup_jobs backup_type database/documents/full/incremental status pending/running/success/failed/expired/deleted storage_location storage_provider encryption_enabled true encryption_method AES-256-GCM size_bytes checksum retention_days 1..3650 retention_until is_restore_tested restore_tested_at restore_test_env restore_test_result error_sanitized, backup_restores backup_job_id CASCADE restore_type test/production/verification status pending/running/success/failed/cancelled target_env is_isolated true requested_by verification_notes error_sanitized, retention policies

### Privacidade PLT-09 verificado implementação
- [x] privacy_data_inventory data_category identificacao/contato/localizacao/profissional/financeiro/tecnico/comportamental/sensivel/outro data_field description purpose legal_basis retention_days recipients is_sensitive is_required source UNIQUE(category,field), privacy_policies version status title content 20000 inventory_snapshot contact_email dpo_name dpo_contact retention_summary rights_description recipients_description is_published published_at approved_by/at rejection_reason UNIQUE(version), noindex mantido, minuta pendente aviso explícito base legal retenção encarregado a definir direitos titular

### LGPD PLT-10 verificado implementação
- [x] lgpd_requests request_type acesso/correcao/eliminacao/portabilidade/oposicao/revogacao_consentimento/informacao/outro status recebido/em_verificacao/em_analise/aguardando_titular/aprovado/atendido/rejeitado/cancelado/expirado requester_name requester_email requester_document_hash description 10..5000 verification_method email/documento/presencial/video/outro is_identity_verified verified_at/by responsible_id/name due_date DATE legal_impediment impediment_documented response response_sent_at, history, 15 dias

### Retenção PLT-11 verificado implementação
- [x] retention policies category UNIQUE retention_days description is_active, exceptions, disposal jobs/logs, hash minimizado

### Incidente PLT-12 verificado implementação
- [x] incidents containment_lead_required root_cause_required_for_close, evidences, actions, communications

### Config PLT-13 verificado implementação
- [x] config flags catalogo_publicacao_automatica etc 5 flags, secret masking business separado infra, maintenance, rollouts

### Dependencies PLT-14 verificado implementação
- [x] audits, vulnerabilities, updates, lockfile, 0 vuln total 77 deps lockfileVersion 3 CI

### Integration logs PLT-15 verificado implementação
- [x] jobs/logs/webhooks/deliveries/reconciliation HMAC signature rate_limit 429

### Budget PLT-16 verificado implementação
- [x] budgets Hospedagem 200 R$ teto, usage metrics/alerts

### Env isolation PLT-17 verificado implementação
- [x] 4 envs development homologation production preview isolado, checks

### Maintenance docs PLT-18 verificado implementação
- [x] 7 seed arquitetura-geral etc, docs

### Produção não liberada
- [x] noindex mantido, nenhum dado real inventado, autorização explícita publicação/execução produção pendente não publicar nem operar produção automaticamente não contratar serviços efetuar pagamentos enviar campanhas/mensagens reais sem autorização específica desenvolver testar com sandbox/captura local, D-01..D-13 bloqueios negócio documentados, PG real ausente sandbox, SMTP real, CNPJ, logotipo, política aprovada, hospedagem pendentes

## Build/Test evidências
- npm ci 50 packages audit 0 vulnerabilities
- npx next build Next 16.3.6 59 páginas ok (inclui /admin/ti com 13 clients Ext etc)
- npm test 46 pass 0 fail 4 skipped
- migrações 001-087 idempotentes via scripts/migrate-site-visual.mjs All schemas (001-087) present and idempotent guards verified

## Decisões
- ext_all + ai_none mantido: todas EXT-01..17 + AI-10 determinística, AI-01..09 desligado
- Protocolos LIC-EXT-, FORN-EXT-, QUAL-EXT-, SAT-EXT-, COMP-EXT-, EXP-EXT-, CONT-EXT-, AB-EXT-, CENT-EXT-, BIO-EXT-, RELP-EXT-, INTEL-EXT- para rastreabilidade
- Triggers ext_touch_updated_at, versionamento MAX+1, margens GENERATED, variance GENERATED
- Condições bloqueantes: collection_requires_approval, tested_requires_test, human_approval_required, privacy_approval_required, cause_required_to_close, complete/incomplete, segregation, auto_paid forbidden, reopen_reason required, idempotency_key UNIQUE validar assinatura webhook replay idempotência
- UI sem -> e sem > em placeholder para evitar TS1382, substituído por → e texto maior
- Homologação usuários pendente execução humana, ambiente preparado código, produção não liberada sem autorização explícita

## Próximo passo
- Executar homologação humana Marcelo Andreia funcionário cliente representativo ambiente homologação sem dados reais domínio próprio TLS cookies base URL corretos banco usuário runtime restrito usuário migração separado armazenamento privado ciclo vida scheduler/worker responsabilidade acompanhar falhas contas reais somente fluxo seguro entrega manual/autorizada convite sem senha padrão
- Após homologação, autorização explícita publicação produção, remover noindex se política aprovada, configurar hospedagem 200 R$ teto, SMTP real, CNPJ, logotipo, política aprovada, backup restauração testada ambiente isolado is_restore_tested is_isolated, observabilidade healthcheck config flags env isolation maintenance docs, dependencies audit 0 vuln, integration logs HMAC signature rate_limit 429, budgets Hospedagem 200 R$ teto, env isolation 4 envs isolado
- Não publicar em produção nem contratar serviços automaticamente até autorização explícita
