# F2 lote 1 — RBAC granular + orçamento consolidado (SEC-10, PLT-01, SEC-08)

Data: 2026-09-28T04:30Z
Branch: arena/01a0e621-gruposegsystemseguranca

## Objetivo
- SEC-10: consolidar /orcamento à mesma API de /simulador, remover preço fictício, sem modo admin público, só confirmar após persistência.
- PLT-01: diretório de usuários, papéis, escopos, convites, suspensão/revogação e revisão periódica de acesso.
- SEC-08: manter migrações rastreadas executáveis incluindo 010.

## SEC-10 — orçamento consolidado

Arquivo: `src/app/orcamento/page.tsx` reescrito completo.

Antes:
- Confirmação local sem gravação em DB.
- Exibia faixa R$ ilustrativa com cálculo fictício.
- Tinha toggle "Modo visitante / Configuração (dono)" público.

Agora:
- Importa `PUBLIC_SERVICES`, `PROPERTY_TYPES`, `buildRequestSummary` de `src/server/service-catalog.mjs` (catálogo único 6 serviços validados).
- Usa `service-catalog` para filtrar `isPublic !== false`.
- Formulário com consentimento obrigatório, requestKind `quote` ou `visit`, `propertyType`, `services` (multi-select checkboxes), `summary` gerado via `buildRequestSummary`.
- POST para `/api/leads` com body `{ name, phone, email, channel, message: summary, consent: true, requestKind, propertyType, services, origin, campaign }`.
- Só confirma após `res.ok` e exibe protocolo retornado (`protocolo` da API), mensagem "Entrou na fila de atendimento em /admin/leads. Visita depende de confirmação humana".
- Sem preço fictício, sem toggle público.
- Mensagem antispam: deduplicação controlada via API (lead rate limit IP já existente).

Critério aceite:
- Só confirmar após persistência ✓ (usa resposta da API)
- Preço fictício ausente do fluxo real ✓ (removido)
- Sem modo administrativo público ✓ (removido)

## PLT-01 — RBAC granular

### Migração 010
Arquivo: `db/migrations/010-rbac-permissions.sql`

- `auth_permissions`:
  - `id UUID PK`
  - `identity_id UUID FK auth_identities(id)`
  - `permission TEXT CHECK permission ~ '^[a-z_]+\.[a-z_\.]+$'` (domain.action)
  - `scope_type TEXT CHECK IN ('global','own','team','unit','account','contract','organization')`
  - `scope_id UUID NULL`
  - `granted_at TIMESTAMPTZ default now()`
  - `granted_by UUID FK auth_identities`
  - `granted_by_role TEXT`
  - `reason TEXT 1-500 NOT NULL`
  - `revoked_at, revoked_by, revoke_reason`
  - `UNIQUE (identity_id, permission, scope_type, COALESCE(scope_id,'00000000-0000-0000-0000-000000000000')) WHERE revoked_at IS NULL`
  - Índices: identity_id, permission, scope_type, scope_id, active

- `auth_access_reviews`:
  - `id UUID PK`
  - `reviewed_at TIMESTAMPTZ`
  - `reviewed_by UUID FK`
  - `target_identity_id UUID FK`
  - `decision TEXT keep/revoke/adjust`
  - `notes TEXT`

- `auth_access_audit`:
  - ALTER TYPE CHECK adiciona `permission_grant`, `permission_revoke`, `access_review`

- Incluída em `scripts/migrate-site-visual.mjs` lista 001-010.

### rbac.mjs
Arquivo: `src/server/rbac.mjs`

- `KNOWN_PERMISSIONS` 29 entradas:
  - admin.users.read/write, admin.invites.issue/revoke, admin.audit.read, admin.permissions.grant/revoke, admin.access_review, client.accounts/contracts/documents/tickets read/write, documents.download, leads.read/write, site.visual.read/write, employees.read/write/health.read, proposals.approve_discount, payroll.export
- `isValidPermission(permission)` valida regex + lista conhecida (avisa se fora lista mas permite, para extensão futura)
- `isValidScopeType`
- `hasPermission(db, identityId, permission, { scopeType, scopeId })`:
  - Busca em `auth_permissions` onde `revoked_at IS NULL`, permission = X, scope_type = requested ou global, scope_id = requested ou NULL.
  - Retorna true se encontrou.
  - Deny-by-default.
  - Bypass provisório: se `identityId` é admin/ti (via `auth_identities.role` ou `auth_staff_profiles.role`), retorna true até que todos os staff tenham permissões granulares. Isso mantém compatibilidade durante migração.
- `grantPermission(db, { identityId, permission, scopeType, scopeId, grantedBy, grantedByRole, reason })`:
  - Valida permission, scopeType, scopeId UUID se presente, reason 1-500.
  - Upsert idempotente via ON CONFLICT? Na implementação atual faz INSERT com verificação de existência ativa; se já existe retorna existente.
  - Insere em `auth_access_audit` action `permission_grant` com actor, target_identity_id, reason, without secrets.
- `revokePermission(db, { permissionId, revokedBy, revokeReason })`:
  - Valida UUID, revokeReason 1-500.
  - UPDATE set revoked_at=now(), revoked_by, revoke_reason where revoked_at IS NULL.
  - Audita `permission_revoke`.

### admin-rbac-api.mjs
Arquivo: `src/server/admin-rbac-api.mjs`

- `handleListPermissions(req,res,ctx)`:
  - sameOrigin, requireAdminSession (admin/ti), retorna `{ permissions: [...active], knownPermissions, session: { identityId, role } }`.
  - Filtros opcionais `?identity=&permission=` com validação UUID e permission.
  - Audita `permission_list`? Na prática lista não sensível, mas poderia auditar read.

- `handleGrantPermission`:
  - POST /api/admin/permissions
  - sameOrigin, admin session, JSON 15KB.
  - Body: identityId UUID, permission string válida, scopeType enum, scopeId UUID opcional, reason 1-500 obrigatório.
  - Chama `grantPermission`, retorna 201 com permission.
  - Erros: 400 invalid, 403 not admin, 404 identity not found.

- `handleRevokePermission`:
  - DELETE /api/admin/permissions/:id (ou POST com _method)
  - Body reason obrigatório.
  - Chama `revokePermission`.

- `handleAccessReviews`:
  - GET lista reviews, POST cria review com decision keep/revoke/adjust, notes opcional, audita access_review.

- Todos os handlers verificam `ctx.adminSession` ou `ctx.clientSession` conforme plano? Aqui só admin.

### Integração server.mjs

- Import `createAdminRbacApi`
- Criação `adminRbacApi = createAdminRbacApi({ dbPool, siteVisual, mailer, ... })`
- Rotas:
  - GET /api/admin/permissions -> handleListPermissions
  - POST /api/admin/permissions -> handleGrantPermission
  - DELETE /api/admin/permissions/:uuid -> handleRevokePermission
  - GET /api/admin/access-reviews -> handleAccessReviews GET
  - POST /api/admin/access-reviews -> handleAccessReviews POST
- `API_PATH_MATCH` expandido com `/api/admin/permissions/*` e `/api/admin/access-reviews`.

### UI TI

- `src/app/admin/ti/RbacClient.tsx` client component:
  - Fetch /api/admin/permissions, exibe tabela permissões ativas, knownPermissions.
  - Form grant: identityId (UUID input), permission select (knownPermissions), scopeType select, scopeId optional, reason textarea.
  - Revoke: prompt reason, DELETE com body reason.
  - Mostra sessão atual identityId/role.
- `src/app/admin/ti/page.tsx` reescrito para importar RbacClient e listar poderes implementados (login staff, convites staff, RBAC granular, auditoria, revisão periódica).

- `src/app/admin/convite/page.tsx` criado com Suspense wrapper para aceitar convite staff (usa /api/auth/invite/inspect e /api/auth/invite/accept). Corrige build error useSearchParams needing Suspense.

## SEC-08 — migrações

- 010 adicionada, idempotente, sem DROP perigoso.
- `scripts/migrate-site-visual.mjs` lista inclui 010.
- `npm run typecheck` ok, `npm test` 46 pass 0 fail 4 skipped (integração requer DATABASE_URL loopback), `npm run build` ok.

## Validação

- `npm test` 2026-09-28: 46 pass, 0 fail, 4 skipped (client-security integration requer PG real)
- `npm run typecheck`: ok
- `npm run build`: ok (Next 15, 49 páginas, incluindo /admin/convite com Suspense)
- Manual:
  - /orcamento agora chama /api/leads e só confirma após persistência, sem preço fictício.
  - /admin/ti carrega RbacClient (requer sessão admin, sameOrigin).
  - /api/admin/permissions requer admin session, valida UUID, permission regex, reason 1-500.

## Bloqueios

- PG real ausente no sandbox: docker, docker compose, psql ausentes, apt sem rede (deb.debian.org Connection failed). Não foi possível testar integração real com RUN_DATABASE_INTEGRATION=1.
- Mitigação: instalado @electric-sql/pglite (50 packages) como alternativa WASM para testes locais, ainda não integrado aos testes de integração que esperam DATABASE_URL loopback. Próximo passo: adaptar testes para usar pglite ou documentar necessidade PG real em CI.
- SMTP real, CNPJ, logotipo, política aprovada ainda pendentes (D-01..D-13).

## Próximo passo

- Implementar fila de notificações PLT-04 (jobs, retry, idempotência).
- Revisar privacidade e tema (SEC-11/12) com aprovação formal.
- Testar integração RBAC com PG real quando disponível, e remover bypass provisório admin/ti após todos staff terem permissões granulares.
- Implementar rate limit para convites e proxy confiável documentado (SEC-15).
