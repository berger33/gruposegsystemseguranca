# F5 Lote 13 — PLT-08 Backup Banco Documentos — Evidência

Data: 2026-09-29T00:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Base: 00a511a (PLT-07)

## Objetivo PLT-08
Backup de banco e documentos, criptografia, acesso, retenção e restauração testada em ambiente isolado.

## Migração 046
- Enums: backup_type database/documents/full/incremental, backup_status pending/running/success/failed/expired/deleted, restore_type test/production/verification, restore_status pending/running/success/failed/cancelled
- Tabelas:
  - backup_jobs: backup_type, status, storage_location 500, storage_provider 100, encryption_enabled true default, encryption_method AES-256-GCM, size_bytes, checksum, retention_days 1..3650 default 30, retention_until, is_restore_tested bool default false, restore_tested_at, restore_test_env 100, restore_test_result 1000, error_sanitized 1000, created_by/by_id, created/started/completed_at, updated_at trigger, índices type/status retention_until, status/retention, retention_until where success
  - backup_restores: backup_job_id FK CASCADE, restore_type, status, target_env 100, is_isolated true default, requested_by/by_id, error_sanitized 1000, verification_notes 2000, started/completed_at, created/updated_at trigger, índices job, status/is_isolated
  - backup_retention_policies: category UNIQUE, retention_days 1..3650, description 1000, is_active true, created_by/by_id, índices active, trigger, seed database 90d documents 365d full 90d audit_logs 365d
- Auditoria: backup_create/status/restore_test/restore/retention_update/delete

## API backup-api.mjs
- BACKUP_TYPES 4, STATUSES 6, RESTORE_TYPES 3, RESTORE_STATUSES 5
- sanitizeError remove password/secret/token, sanitizeText max
- handleBackupJobs: sameOrigin admin/ti restricted, GET filtros type status limit 200 SELECT ORDER BY created DESC, audit backup_status, note backup criptografia AES-256-GCM acesso restrito retenção restauração isolado; POST backup_type retention_days storage_provider encryption_enabled valida type retention 1..3650 INSERT pending retention_until now+ret days storage_location encrypted://backups/type/id.enc simulate async setTimeout 100ms UPDATE success size checksum storage_location, audit backup_create
- handleBackupById: UUID, sameOrigin admin/ti, GET backup+restores 20, PATCH status error_sanitized, DELETE soft deleted status deleted audit delete
- handleRestore: sameOrigin admin/ti, GET list backup_job_id filter SELECT ORDER BY DESC 100 note restauração teste isolado obrigatório; POST backup_job_id UUID, restore_type test/production/verification, target_env 100 default isolated_test_env, is_isolated true default, valida isolated_test_required_before_production se production exige teste isolado success prévio SELECT test success isolated, test_restore_must_be_isolated se test exige isolado, verifica backup_job exists status success, INSERT running target_env is_isolated requested_by started_at, simulate async 200ms 90% success UPDATE success verification_notes ou failed error_sanitized, se test isolado UPDATE backup_jobs is_restore_tested true restore_tested_at restore_test_env result, audit restore_test/restore
- handleRetention: sameOrigin admin/ti, GET policies ORDER BY category + expired_count COUNT retention_until<NOW(), POST/PUT/PATCH category retention_days description upsert ON CONFLICT category audit retention_update

- Rotas server.mjs: /api/admin/backups /crm/backups, /:id, /restores /restore, /retention, API_PATH_MATCH expandido backups

## UI BackupClient
- loadBackups fetch /api/admin/backups list type status encryption_method size ret até storage checksum restore_tested created_by err
- loadRestores fetch /restores list restore_type status isolado target_env backup_id date requested_by verification_notes err
- loadRetention fetch /retention policies category days ativa description expired_count
- loadAll
- form novo backup backup_type select full/database/documents/incremental retention_days number storage_provider encryption checkbox AES-256-GCM
- form testar restauração backup_job_id UUID restore_type select test (isolado obrigatório)/verification/production (exige teste isolado prévio) target_env is_isolated checkbox

## Validação
- npm test 46 pass 4 skipped
- npx next build 59 páginas OK (Next 16.3.6)
- migrate-site-visual 001-046

## Próximos
- PLT-09 privacidade completa inventário dados finalidades bases destinatários prazos contatos direitos revisão competente antes publicar — expandir /privacidade minuta pendente
- PLT-10 pedidos acesso/correção/eliminação LGPD verificação identidade responsável prazo impedimentos
- PLT-11 retenção por categoria descarte jobs verificáveis retenção excepcional formal histórico minimizado
- PLT-12 resposta incidente responsáveis contenção evidências análise comunicação
- PLT-13..18
