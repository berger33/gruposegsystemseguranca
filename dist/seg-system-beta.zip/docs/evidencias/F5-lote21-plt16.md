# F5 lote 21 — PLT-16 orçamento operacional alertas uso

- Data/hora: 2026-09-29T05:00Z
- Fase: PLT-16 orçamento operacional e alertas de uso de armazenamento, mensagens, IA, banco e infraestrutura
- Status: implementado não verificado

## Migração 054-plt16-operational-budget.sql

- Enums: budget_category armazenamento/mensagens/ia/banco/infra/licencas/outro, usage_metric storage_gb/messages_count/ia_tokens/db_gb/bandwidth_gb/cpu_hours/api_calls/outro, alert_severity info/warning/critical
- operational_budgets: id PK, name 3..200, category, period_start/end DATE CHECK end>=start, budgeted_amount DECIMAL 12,2, currency BRL, actual_amount DECIMAL, alert_threshold_percent 1..100, is_active bool, notes 2000, created_by/by_id, índices category/period/active, trigger
- usage_metrics: id PK, metric, category, measured_at, value DECIMAL 12,4, unit 20, source 100, details JSONB, índices metric/category/measured
- usage_alerts: id PK, budget_id FK SET NULL, metric, category, severity, title 5..200, message 10..2000, threshold_value DECIMAL, current_value DECIMAL, is_acknowledged bool, acknowledged_by/at, índices budget/metric/severity/created
- Seed 5 budgets: Hospedagem base mensal infra 200.00 80% notes teto R$200/mês não cobre todo ecossistema, Armazenamento documentos armazenamento 100.00, Mensagens SMTP/WhatsApp mensagens 150.00, IA tokens mensal ia 300.00, Banco PostgreSQL banco 150.00 ON CONFLICT DO NOTHING
- Audit: budget_create/update usage_metric_create alert_ack

## API budget-api.mjs

- handleBudgets: GET category active filter, POST name min3 category period required invalid_period budgeted_amount currency threshold notes INSERT audit create, PATCH id actual_amount is_active notes UPDATE check threshold pct=actual/budgeted*100 if pct>=threshold INSERT usage_alerts budget_id metric outro category severity critical if pct>=100 else critical if >=90 else warning title Orçamento X em pct% message atingiu limite, audit update
- handleMetrics: GET list, POST metric category value unit source details INSERT audit create check budgets active current period category if value>=threshold INSERT usage_alerts budget_id metric category severity warning/critical title Uso metric em category alto message métrica valor unit atingiu limite threshold para orçamento
- handleAlerts: GET list, PATCH id is_acknowledged acknowledged_by/at audit ack

## server.mjs

- import createBudgetApi, init budgetApi pool auditLog sameOrigin requireSession requireRole
- Rotas: /admin/budgets /crm/budgets /budgets GET/POST/PATCH, /admin/usage/metrics /usage/metrics GET/POST, /admin/usage/alerts /usage/alerts GET/PATCH
- API_PATH_MATCH expandido budgets usage 9 entradas

## UI

- BudgetClient.tsx: load budgets metrics alerts, budgets list ativo category name budgeted atual pct thresh period notes buttons +10 uso simular 90% form name category budgeted period_start/end threshold notes criar, metrics list metric category value unit source measured form metric category value unit source registrar métrica gera alerta se exceder, alerts list severity category metric title curr thresh created ack button color critical red warning orange

## Infra

- migrate-site-visual.mjs: adicionado 054-plt16-operational-budget.sql
- Build: 60 páginas, testes 46 pass 4 skipped
- Próxima: PLT-17 isolamento dev/homolog/prod previews sem dados reais
