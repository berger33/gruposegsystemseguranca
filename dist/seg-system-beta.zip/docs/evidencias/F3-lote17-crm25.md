# F3 lote 17 — CRM-25 metas e comissões versionadas

Data: 2026-09-28T12:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: c01c3bf (CRM-24)

## Requisito
CRM-25: metas e comissões versionadas; base de cálculo (contratado/faturado/recebido), período, cancelamento e aprovação configuráveis, sem pagamento automático.

## Implementação
### Migração 029
- `db/migrations/029-crm25-goals-commissions.sql`
- Tipos: crm_goal_status rascunho/ativo/atingida/nao_atingida/cancelada, crm_commission_base contratado/faturado/recebido, crm_commission_period mensal/trimestral/semestral/anual/por_contrato, crm_commission_cancel_rule mantem/estorna_proporcional/estorna_total/recalcula, crm_commission_status rascunho/pendente_aprovacao/aprovada/rejeitada/cancelada/estornada
- `crm_goals` id UUID PK, responsible_id FK, responsible_name 120, title 200, description 1000, period_start/end DATE CHECK end>=start, target_value 14,2, target_type contratado/faturado/recebido, status rascunho/ativo/atingida/nao_atingida/cancelada, version 1, created_by/by_id, approved_by/by_id/at, índices responsible/period/status, trigger
- `crm_commission_rules` id UUID PK, name 200, description 1000, base_type contratado/faturado/recebido, period_type mensal/trimestral/semestral/anual/por_contrato, percent 0..100, cancel_rule, requires_approval bool, approver_role 80, min/max value, status rascunho/ativa/inativa, version, created_by/by_id, approved_by/at, índices base/status, trigger
- `crm_commissions` id UUID PK, rule_id FK RESTRICT, goal_id/opportunity_id/contract_id/company_id FK SET NULL, responsible_id/name, base_type, base_value, percent, calculated_value, period_start/end DATE, status rascunho/pendente_aprovacao/aprovada/rejeitada/cancelada/estornada, cancel_reason 500, approval_notes 1000, approved_by/at, is_paid false, paid_at, paid_note 500, version, created_by/by_id, índices rule/goal/responsible/status/period, trigger
- Auditoria crm_goal_create/update/status, crm_commission_rule_create/update/status, crm_commission_create/update/status

### API
- `src/server/commission-api.mjs`
- `handleGoals` GET filtros responsible/status count+list, POST title 200 target_value period_start/end target_type contratado/faturado/recebido responsible_id/name INSERT rascunho version 1
- `handleGoalById` GET/PATCH title/description/target_value/status rascunho/ativo/atingida/nao_atingida/cancelada version++ approved_by/at
- `handleRules` GET filtros status/base_type count+list, POST name 200 base_type contratado/faturado/recebido period_type mensal/trimestral/semestral/anual/por_contrato percent 0..100 cancel_rule mantem/estorna_proporcional/estorna_total/recalcula requires_approval approver_role min/max INSERT rascunho version 1
- `handleRuleById` GET/PATCH name/description/percent/status rascunho/ativa/inativa version++ approved
- `handleCommissions` GET filtros rule/goal/responsible/status count+list total_value SUM calculated_value note sem pagamento automático is_paid false por padrão, POST rule_id UUID goal/opportunity/contract/company/responsible UUID base_value period_start/end verifica rule existe status ativa calcula calculated_value base_value*percent/100 INSERT status pendente_aprovacao se requires_approval senão aprovada version 1 is_paid false
- `handleCommissionById` GET/PATCH status rascunho/pendente_aprovacao/aprovada/rejeitada/cancelada/estornada cancel_reason required para cancelada/estornada approval_notes, is_paid bool true requer status aprovada senão 409 commission_not_approved_cannot_pay paid_at NOW paid_note version++ audit note sem pagamento automático is_paid manual requer aprovação

- `server.mjs` rotas `/api/crm/goals`, `/:id`, `/api/crm/commission-rules`, `/:id`, `/api/crm/commissions`, `/:id`

### UI
- `src/app/admin/ti/CommissionClient.tsx`
- Forms criar meta title/target_value/period_start/end/target_type/responsible_name lista metas
- Criar regra name/base_type/period_type/percent/cancel_rule/requires_approval/approver_role lista regras
- Criar comissão rule_id/base_value/period_start/end/responsible_name lista comissões id/regra/base tipo/valor/%/calculado/período/status/pago? ações Aprovar e Pagar manual verifica aprovada
- Sem pagamento automático: is_paid false por padrão, pagamento manual registrado via PATCH com paid_note

## Sem pagamento automático
- is_paid false default, paid_at null
- PATCH is_paid true requer status aprovada, senão 409 commission_not_approved_cannot_pay
- Pagamento manual registrado com paid_note, audit, não há job automático de pagamento
- Regra requires_approval configurável, approver_role configurável, cancel_rule configurável mantem/estorna_proporcional/estorna_total/recalcula

## Validação
- npm test 46 pass 4 skipped
- npx next build ok 59 páginas (Next 16.3.6)
- migrate-site-visual 001-029

## Próximo
CRM-26..27 integrações e importações, CON-01..CON-11 contratos e implantação, PLT-05..18
