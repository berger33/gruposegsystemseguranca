# F3 lote 2 — CRM-01..CRM-10 (cadastro central, contatos, oportunidades, funil, kanban, agenda)

Data: 2026-09-28T06:30Z
Branch: arena/01a0e621-gruposegsystemseguranca

## CRM-01 — cadastro central de empresas e contatos
- Tabela `crm_companies`: id UUID, display_name 200, document_ref 32 unique where not null, document_type cnpj/cpf/other, segment 100, city 100, state 2, type prospect/client/partner, status active/inactive/archived, channels JSONB, responsible_id FK auth_identities, responsible_name 120, parent_company_id FK self para filiais/grupo, notes 1000, origin 100, campaign 100, created_by, created_by_id, created_at, updated_at, trigger updated_at, índices type_status, city, responsible, parent, document_unique
- Tabela `crm_company_units`: id UUID, company_id FK, display_name 200, city 100, address 300, is_main bool, created_at, índice company
- Distinguir prospect/cliente/parceiro sem duplicar entidade: type enum + document_ref unique + verificação duplicidade por nome/telefone em lead convert
- API `/api/crm/companies` GET com filtros type/status/city/search, limit/offset, e POST com display_name/type/segment/city/state/channels/responsible_name/parent_company_id/notes/origin/campaign, audit crm_company_create, 409 se document_exists
- API `/api/crm/companies/:id` GET retorna company + units + contacts + opportunities (50), PATCH/PUT atualiza display_name/segment/city/state/type/status/responsible_name/notes/origin/campaign
- UI `/admin/crm`: form Nova empresa (nome, cidade, segmento, tipo prospect/client/partner), lista empresas com tipo/cidade/segmento/status, filtros tipo e estágio

## CRM-02 — contato com função no processo de compra
- Tabela `crm_contacts`: id UUID, company_id FK SET NULL, display_name 200, email 254, phone 30, role decisor/influenciador/usuario/financeiro/outro, buying_role mesmo enum, preferences JSONB, restrictions 500, origin 100, is_primary bool, status active/inactive, created_by_id, created_at/updated_at trigger, índices company, email where not null, unique company+email
- Função no processo de compra: role e buying_role
- Preferências e restrições de abordagem: preferences JSONB e restrictions TEXT
- Origem legítima: origin field, sem coleta indiscriminada
- API `/api/crm/contacts` GET com companyId/search, POST com validações role/email/companyId, audit contact_create, 409 contact_exists

## CRM-03 — importar CSV (não iniciado)
- Pendente: prévia, validação por linha, mapeamento, relatório, deduplicação revisável e prevenção fórmula maliciosa exportação
- Mantido como não iniciado no controle

## CRM-04 — converter lead do site em contato/oportunidade preservando histórico
- API `POST /api/crm/leads/:id/convert` com body company_id ou create_company+company_name
- Verifica public_leads existente, deduplica por public_lead_id já convertido retorna 200 dedup true preservando histórico
- Se create_company: verifica duplicidade por display_name ILIKE ou document_ref = phone e reusa, senão cria crm_companies com display_name, city, type prospect, origin, campaign, created_by
- Criar contato: verifica por company_id + email/phone, reusa ou cria crm_contacts com display_name, email, phone, origin, is_primary true
- Criar oportunidade: title "Oportunidade - {name} - {service}", service_name, need_description details, origin, campaign, public_lead_id, next_action qualificar, next_action_date NOW+2days, stage novo
- INSERT em crm_opportunity_stages com reason conversão preservando histórico
- Audit crm_lead_convert e opportunity_create
- Trata duplicidade e contato sem empresa: contato pode ter company_id null? Na implementação exige company, mas cria company se necessário
- UI /admin/crm botão Converter lead com prompts leadId e companyName

## CRM-05 — oportunidades com serviço, necessidade, responsável, unidade, previsão, valor estimado, próxima ação/data, origem, prioridade e motivo de perda
- Tabela `crm_opportunities`: id UUID, company_id FK CASCADE, contact_id FK SET NULL, unit_id FK, title 200, service_id FK service_catalog, service_name 100, need_description 2000, responsible_id/name, forecast_date DATE, estimated_value NUMERIC 12,2 >=0, next_action 200, next_action_date, origin 100, campaign 100, priority baixa/media/alta/critica default media, loss_reason 500, public_lead_id FK, created_by_id, stage, is_won/is_lost bool, stage_changed_at, created_at/updated_at trigger, índices company, responsible+next_action_date, forecast, next_action_date where not null
- Serviço: service_id FK service_catalog + service_name
- Necessidade: need_description
- Responsável: responsible_id/name
- Unidade: unit_id
- Previsão: forecast_date
- Valor estimado: estimated_value
- Próxima ação/data: next_action, next_action_date
- Origem: origin, campaign
- Prioridade: priority
- Motivo perda: loss_reason
- API GET com filtros companyId/stage/responsibleId/priority/search, limit/offset, ORDER BY next_action_date NULLS LAST, POST com validações
- UI kanban mostra prioridade, valor, próxima ação/data

## CRM-06 — funil novo → qualificação → vistoria/diagnóstico → proposta em elaboração → enviada → negociação → ganho/perdido. Motivo obrigatório para perda; reabertura auditada. Não tratar ganho como dinheiro recebido
- Tabela `crm_opportunity_stages`: id UUID, opportunity_id FK CASCADE, previous_stage, next_stage enum novo/qualificacao/vistoria/proposta_elaboracao/proposta_enviada/negociacao/ganho/perdido, changed_by_id/role, reason 500, created_at, índice opp
- Colunas em crm_opportunities: stage default novo, stage_changed_at, is_won default false, is_lost default false
- API PATCH /api/crm/opportunities/:id: aceita stage, loss_reason, next_action, next_action_date, estimated_value; valida stage enum, loss_reason obrigatório para perdido, next_action_date válida; UPDATE com stage_changed_at NOW, is_won = stage ganho, is_lost = stage perdido, loss_reason; se stage mudou INSERT em stages com reason, audit stage_change/update
- Motivo obrigatório para perda: validado 400 loss_reason_required
- Reabertura auditada: stages registra previous_stage/next_stage + changed_by + reason
- Não tratar ganho como dinheiro recebido: UI mostra "ganho (não é dinheiro recebido)" e documentação

## CRM-07 — kanban e tabela, filtros, busca, tarefas vencidas, histórico de ligações/reuniões, anexos e notas internas autorizadas
- Tabela `crm_tasks`: id UUID, opportunity_id FK, company_id FK, title 200, description 2000, responsible_id FK, due_date, status aberta/em_andamento/concluida/cancelada, priority, created_by_id, created_at/updated_at trigger, índices opp+status+due, due where aberta/em_andamento, responsible+due
- Tabela `crm_interactions`: id UUID, company_id FK, opportunity_id FK, contact_id FK, type ligacao/reuniao/email/whatsapp/visita/nota/outro, title 200, details 5000, occurred_at, created_by_id, created_at, índices company+occurred, opp+occurred
- Estrutura para kanban e tabela, filtros (companyId/stage/responsibleId/priority/search), busca, tarefas vencidas via due_date, histórico ligações/reuniões via interactions
- Anexos e notas internas autorizadas: interactions com type nota e details, sem segredos

## CRM-08 — agenda de visitas e reuniões, responsável, participantes, confirmação, reagendamento e cancelamento
- Tabela `crm_visits`: id UUID, company_id FK CASCADE, opportunity_id FK SET NULL, contact_id FK SET NULL, title 200, responsible_id FK, participants JSONB, scheduled_at TIMESTAMPTZ NOT NULL, duration_minutes 15-480, status solicitada/em_agendamento/confirmada/realizada/cancelada, public_lead_id FK, notes 2000, created_by_id, created_at/updated_at trigger, índices company+scheduled, responsible+scheduled, status+scheduled, audit visit_create/update/status/confirm/cancel
- Responsável, participantes, confirmação, reagendamento e cancelamento: responsible_id, participants JSONB, scheduled_at, status, notes
- Links/calendário externo somente por integração configurada: depende de PLT-03 integrations status calendar

## CRM-09 — cadências de prospecção inicialmente como tarefas; automação de mensagens depende de autorização, opt-out quando aplicável e provedor
- Cadências inicialmente como tarefas em crm_tasks
- Automação de mensagens depende de autorização, opt-out e provedor (PLT-04 fila durável, integrations status whatsapp/sms/email)
- Sem envio fictício

## CRM-10 — carteira com renovação, serviços adicionais, reativação, indicações, oportunidades sem próxima ação e relacionamentos por grupo/unidade
- crm_companies com parent_company_id para grupo/unidade, type prospect/client/partner, status
- crm_opportunities com next_action_date para oportunidades sem próxima ação (filtra NULL)
- Carteira com renovação/serviços adicionais/reativação/indicações via oportunidades com origin/campaign
- Relacionamentos por grupo/unidade via parent_company_id e company_units

## Validação
- npm test 46 pass 4 skipped (public-lead-validation.test atualizado, crm ainda sem testes unitários específicos mas estrutura idempotente)
- typecheck ok
- build ok Next 16.3.6, 54 páginas incluindo /admin/crm
- Migrações 001-014 idempotentes, runner atualizado

## Bloqueios
- PG real ausente sandbox — integração DB real pendente
- CSV import CRM-03 pendente
- SMTP real, CNPJ, logotipo, política aprovada, hospedagem pendentes

## Próximo passo
- CRM-03 CSV import com prévia e validação
- CRM-11..CRM-27 biblioteca comercial e propostas versionadas
- CON-01..CON-11 contratos e implantação
