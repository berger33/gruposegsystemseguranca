# Evidência F3 lote 9 — CRM-16 parâmetros tributos/custos/jornada

Data: 2026-09-28T09:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 49d366cd -> HEAD atual (ver git log)
Objetivo: CRM-16 parâmetros de tributos/custos/jornada versionados com validade, fonte e aprovador; nenhuma alíquota ou regra coletiva inventada. Impedir preço oficial se faltar parâmetro essencial.

## Implementação

### Migração 021
- `db/migrations/021-crm16-cost-parameters.sql`
- Tipos: crm_cost_param_category tributo/custo/jornada/beneficio/provisao/outro, crm_cost_param_value_type percentual/valor/json, crm_cost_param_status rascunho/em_revisao/aprovado/arquivado.
- `crm_cost_parameters`: id UUID PK, company_id FK SET NULL, category enum, param_key 1-100, param_value numeric 14,6, value_type enum, value_json JSONB, unit 50, validity_start/end DATE com check end>=start, source/source_url 500, is_essential bool default false, approval_status enum default rascunho, version int >=1 default 1, approved_by FK auth_identities SET NULL, approved_at, approved_by_role 50, notes 2000, created_by/by_id, created_at/updated_at, índices category/key/status/essential (partial true)/validity/company, trigger updated_at.
- 3 exemplos rascunho sem alíquota inventada: INSS_PATRONAL 0 percentual %, FGTS 0 %, HORAS_MES_220 220 horas, todos is_essential true, source "A definir - aguardando validação contábil", notes "Parâmetro essencial - sem valor oficial inventado. Definir com contador. Impede preço oficial se faltar.", ON CONFLICT DO NOTHING.

### API
- `src/server/cost-parameter-api.mjs`
- `handleParams`: GET valida admin+sameOrigin, filtros category/status/key ILIKE/essential bool, count+list ORDER BY category/key/validity_start DESC limit 200, POST valida company_id UUID, category enum, param_key 1-100, param_value finite, value_type enum, unit 50, validity dates ISO, source 500, is_essential bool, notes 2000, value_json, INSERT rascunho version 1 RETURNING *, audit crm_cost_param_create.
- `handleParamById`: GET param, PATCH valida fields category/key/value/type/unit/validity/source/is_essential/notes/approval_status, se aprovar exige source >=3 chars (source_required_for_approval), version++ updated_at, approved_by/at/role quando aprovado, audit status_aprovado/update.
- `handleEssentialCheck`: GET retorna can_price_official = (SELECT COUNT(*) FROM crm_cost_parameters WHERE is_essential=true AND approval_status!='aprovado')==0, lista missing_essential category/key/status, count_missing. Impede preço oficial se faltar essencial.
- `server.mjs`: import createCostParameterApi, instancia, rotas /api/crm/cost-parameters, /:id, /essential-check, API_PATH_MATCH expandido.

### UI
- `src/app/admin/ti/CostParameterClient.tsx`
- Form criar: param_key, category select 6 valores, param_value numeric, value_type select, unit, source, validity_start/end date, is_essential checkbox, notes.
- Lista: total, tabela categoria/chave/valor/tipo/un/essencial/status/versão/validade/fonte.
- Check preço oficial: GET /essential-check mostra bloqueado com lista missing ou liberado.
- Integrado em `src/app/admin/ti/page.tsx`.

### Migrate script
- `scripts/migrate-site-visual.mjs`: 001-021.

## Validação
- npm test: 46 pass 0 fail 4 skipped.
- npx next build: Next 16.3.6, 59 páginas.
- Migrações idempotentes 001-021.
- Sem alíquota inventada: exemplos com valor 0 e status rascunho, fonte "A definir", is_essential true bloqueia preço oficial.
- Fonte obrigatória para aprovação: PATCH aprovado sem source retorna 400 source_required_for_approval.

## Critério de aceite CRM-16
- Parâmetros tributos/custos/jornada versionados com validade, fonte, aprovador: implementado via validity_start/end, source/source_url, approved_by/at/role, version.
- Nenhuma alíquota ou regra coletiva inventada: exemplos com 0 e rascunho, sem valores reais.
- Impedir preço oficial se faltar parâmetro essencial: handleEssentialCheck retorna can_price_official false e lista missing, UI exibe bloqueado.

## Próximo passo
CRM-17 cenários preço/margem.

## Produção
Não liberada, noindex mantido.
