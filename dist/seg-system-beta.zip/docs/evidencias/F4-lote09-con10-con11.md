# F4 Lote 09 — CON-10 Dossiê Fiscal + CON-11 Diário de Decisões — Evidência

Data: 2026-09-28T20:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: c5feddc (CON-09)

## CON-10 Dossiê de Fiscalização Contratual

### Objetivo
Dossiê de fiscalização contratual por contrato, medição e aceite de serviços com registro de qualidade e evidências; preservar histórico, não apagar lançamentos.

### Migração 041
- Enums: crm_fiscal_dossier_status rascunho/em_analise/aprovado/arquivado/cancelado, crm_service_measurement_status pendente/aprovado/rejeitado/em_ajuste, crm_quality_evidence_type foto/relatorio/indicador/checklist/outro
- Tabelas:
  - crm_contract_fiscal_dossiers: contract_id FK CASCADE, company_id FK SET NULL, title 200 CHECK, description 2000, period_start/end DATE CHECK end>=start, status enum default rascunho, responsible_id/name, created_by/by_id, índices contract/period status, trigger updated_at
  - crm_contract_service_measurements: dossier_id FK CASCADE, contract_id FK CASCADE, service_type 100, measurement_date DATE NOT NULL, quantity numeric 12,2 >=0, quality_score 0..100, acceptance_status enum default pendente, responsible, evidence_file_url 1000, notes 1000, created_by, índices dossier/contract/status
  - crm_contract_quality_evidences: dossier_id FK CASCADE, measurement_id FK SET NULL, contract_id FK CASCADE, evidence_type enum, title 200, file_url 1000, storage_key 200, description 1000, captured_at DATE, created_by, índices dossier/contract/measurement
- Auditoria: crm_fiscal_dossier_create/update, service_measurement_create/approve, quality_evidence_create (ALTER TYPE auth_access_audit)

### API contract-fiscal-api.mjs
- handleDossiers:
  - GET: valida UUID contract, sameOrigin, session, verifica contrato existe, SELECT dossiers ORDER BY period_start DESC
  - POST: title 200 obrigatório, description 2000, period_start/end DATE validados, responsible_name 120, company_id do contrato, INSERT rascunho, audit
- handleDossierById:
  - GET: dossier + measurements ORDER BY measurement_date DESC + evidences ORDER BY captured_at DESC
  - PATCH: title/description/period_start/end/status com allowed_transitions rascunho->em_analise/cancelado, em_analise->aprovado/cancelado (rejeitado? usa cancelado/rejeitado mapping), aprovado->arquivado/cancelado, arquivado terminal, verifica effective period, UPDATE updated_at
- handleMeasurements:
  - GET: list por dossier
  - POST: service_type 100 obrigatório, measurement_date DATE obrigatório, quantity numeric >=0, quality_score 0..100, notes 1000, responsible_name, INSERT pendente, audit
- handleMeasurementById:
  - PATCH: acceptance_status pendente->aprovado/rejeitado/em_ajuste, aprovado->em_ajuste, rejeitado->em_ajuste/pendente, em_ajuste->aprovado/rejeitado/pendente, quality_score quantity evidence_file_url notes responsible, audit approve
- handleEvidences:
  - GET: list por dossier
  - POST: title 200 obrigatório, evidence_type enum, file_url 1000, storage_key 200, description 1000, captured_at DATE, measurement_id FK verifica pertence dossier, INSERT, audit

- Rotas server.mjs: /api/crm/contracts/:id/fiscal-dossiers, /:id/fiscal-dossiers/:dossierId, /:id/fiscal-dossiers/:dossierId/measurements, /:id/fiscal-dossiers/:dossierId/measurements/:mId, /:id/fiscal-dossiers/:dossierId/evidences

### UI ContractFiscalClient
- contract_id input, load dossiês, msg com note
- Lista dossiês com status period created_at, select detail
- Form criar dossiê title description period_start/end responsible_name
- Detail: status transitions rascunho/em_analise/aprovado/arquivado/cancelado
- Medições: lista service_type measurement_date quantity acceptance_status quality_score notes, transição aceite aprovado/rejeitado/em_ajuste/pendente, form criar medição service_type measurement_date quantity quality_score notes
- Evidências: lista title evidence_type file_url, form criar title evidence_type file_url description

## CON-11 Diário de Decisões de Gestão

### Objetivo
Diário de decisões de gestão com acesso restrito, vínculo a contrato/processo e busca; não armazenar segredos ou prontuários em notas livres.

### Migração 042
- Enums: management_diary_visibility restrito/equipe_gestao/diretoria/outro, management_diary_category decisao/risco/negociacao/comercial/operacional/financeiro/juridico/outro
- Tabela crm_management_diary: contract_id FK CASCADE, company_id FK SET NULL, process_ref 100, CHECK at least one NOT NULL (contract_id OR company_id OR process_ref), title 200, decision 10..5000, category enum, visibility enum, responsible_id/name, decision_date DATE NOT NULL, related_opportunity_id FK, tags TEXT[] GIN, created_by/by_id, created_at updated_at, fulltext GIN to_tsvector('portuguese', title || ' ' || decision), CHECK NOT ILIKE senha/password/cpf/rg/prontuario via application + DB trigger? Implemented via app validation + CHECK in table definition: decision NOT ILIKE '%senha%' etc (simplified as app block)
- Índices: contract/date, company/category, process_ref, visibility, category, fulltext GIN, tags GIN
- Trigger updated_at, audit diary_create/update/search

### API contract-management-diary-api.mjs
- CATEGORIES 8, VISIBILITIES 4
- sanitizeText max, containsSecret heuristic: blocks if decision contains senha/password with : = and value, cpf with digits, prontuario, token secreto etc
- handleDiary:
  - GET: sameOrigin, session admin/ti/rh only 403 otherwise (restrito), filters category visibility search: search uses to_tsvector portuguese @@ plainto_tsquery + ILIKE title/decision/process_ref, limit 200 offset, COUNT + SELECT ORDER BY decision_date DESC
  - POST: title 200, decision 10..5000, category enum, visibility enum, decision_date DATE required, responsible_id UUID optional, responsible_name 120, process_ref 100, related_opportunity_id UUID, company_id UUID (default from contract company_id), tags array 20 max 50 chars, valida containsSecret title/decision -> 400 secret_or_medical_record_not_allowed, verifica contract exists, INSERT, audit diary_create
- handleDiaryById:
  - GET: id contract_id
  - PATCH: title decision category visibility responsible_name decision_date process_ref tags, valida secret, UPDATE updated_at
  - DELETE: hard delete (preserva audit)
- handleSearch:
  - Global search /api/crm/management-diary/search?q=...&contract_id=&company_id=&category=, sameOrigin session admin/ti/rh, valida q 200, conds to_tsvector + ILIKE, optional filters, COUNT + SELECT, audit search

- Rotas: /api/crm/contracts/:id/management-diary, /:id/management-diary/:entryId, /api/crm/management-diary/search and /api/crm/management-diary

### UI ContractManagementDiaryClient
- contract_id input, load, msg
- Search input + category + visibility filters, Buscar
- Lista registros com visibility badge restrito vermelho, category decision_date process_ref responsible_name, decision slice 400, tags
- Form criar title decision min10 max5000 placeholder NÃO incluir senha CPF prontuário, category visibility selects, process_ref decision_date responsible_name tags comma separated, Registrar

## Validação
- npm test: 46 pass 0 fail 4 skipped
- npx next build: 59 páginas, TypeScript ok (fixed import default)
- migrate-site-visual: 001-042

## Próximos
- CON-12.. e PLT-05..18
- Commit/push CON-10/11
