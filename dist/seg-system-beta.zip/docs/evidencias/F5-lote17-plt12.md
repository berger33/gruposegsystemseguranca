# F5 lote 17 — PLT-12 resposta a incidente

- Data/hora: 2026-09-29T03:00Z
- Fase: PLT-12 resposta a incidente com responsáveis, contenção, evidências, análise e comunicação
- Status: implementado não verificado

## Migração 050-plt12-incident-response.sql

- Enums: incident_type vazamento_dados/acesso_nao_autorizado/perda_dados/indisponibilidade/malware/phishing/violacao_privacidade/outro, incident_severity baixa/media/alta/critica, incident_status aberto/em_contencao/em_analise/em_remediacao/aguardando_comunicacao/comunicado/encerrado/reaberto, evidence_type log/print/relatorio/depoimento/arquivo/outro, action_type contencao/erradicacao/recuperacao/comunicacao/analise/prevencao/outro
- security_incidents: id PK, type severity status title 10..200 description 20..5000 detected_at reported_at contained_at resolved_at affected_data_categories privacy_data_category[] affected_records_estimate affected_systems TEXT[] responsible_id/name containment_lead_id/name dpo_notified bool dpo_notified_at authority_notified/at data_subjects_notified/at root_cause 2000 impact_assessment 2000 remediation_plan 2000 lessons_learned 2000 created_by/by_id updated_by/by_id índices type/severity/status/detected/responsible trigger
- incident_evidences: id PK incident_id FK CASCADE evidence_type title 3..200 description 2000 file_reference 500 checksum 128 collected_at/by/by_id índices incident/type
- incident_actions: id PK incident_id FK CASCADE action_type title 3..200 description 10..2000 status pendente/em_execucao/concluida/cancelada assigned_to_id/name due_at completed_at created_by/by_id índices incident/status/assigned trigger
- incident_communications: id PK incident_id FK CASCADE recipient_type dpo/autoridade/titular/interno/cliente/outro recipient_contact 320 subject 5..200 content 20..5000 sent_at/by/by_id is_confirmed confirmation_at índices incident/type
- incident_history: id PK incident_id FK CASCADE previous/next status reason 2000 changed_by/by_id índice incident
- Audit: incident_create/update/contain/evidence_add/action_create/complete/communicate/close

## API incident-api.mjs

- ALLOWED: aberto->[em_contencao,em_analise,encerrado] em_contencao->[em_analise,em_remediacao,encerrado] em_analise->[em_remediacao,aguardando_comunicacao,encerrado] em_remediacao->[aguardando_comunicacao,comunicado,encerrado] aguardando->[comunicado,encerrado] comunicado->[encerrado,reaberto] encerrado->[reaberto] reaberto->[em_contencao,em_analise,em_remediacao]
- handleIncidents: GET filtros type severity status, POST valida type severity title min10 description min20 affected_categories/records/systems responsible INSERT aberto history audit create
- handleIncidentById: GET incident+evidences+actions+communications+history, PATCH valida transition containment_lead_required para em_contencao root_cause_required_for_close para encerrado severity valida UPDATE responsible containment_lead root_cause impact remediation lessons history INSERT audit contain/close/update
- handleEvidences: POST valida incident_id evidence_type title min3 checksum sha256 file_reference INSERT audit evidence_add
- handleActions: POST valida incident_id action_type title min3 description min10 due_at INSERT audit action_create, PATCH status concluida/cancelada UPDATE completed_at audit action_complete
- handleCommunications: POST valida incident_id recipient_type subject min5 content min20 INSERT sent_at now UPDATE incident dpo_notified/at authority_notified/at data_subjects_notified/at conforme recipient_type audit communicate

## server.mjs

- import createIncidentApi, init incidentApi pool auditLog sameOrigin requireSession requireRole
- Rotas: /admin/incidents /crm/incidents /security/incidents GET/POST, /:id GET/PATCH, /admin/incidents/evidences POST, /admin/incidents/actions POST/PATCH, /admin/incidents/communications POST
- API_PATH_MATCH expandido incidents 6 entradas

## UI

- IncidentClient.tsx: load incidents list status severity type title resp containment dpo aut, form novo incidente type severity title responsible estimate description, detail status severity title description responsible containment dpo authority titulares root cause impact remediation lessons, form atualizar next_status severity containment_lead responsible reason root_cause impact remediation lessons, evidências list type title checksum por collected_at form evidence_type title file_reference description add checksum automático, ações list status type title resp due concluir button form action_type title assigned due description create, comunicações list recipient_type subject para por sent_at form recipient_type contact subject content registrar atualiza flags, histórico transições previous→next por reason

## Infra

- migrate-site-visual.mjs: adicionado 050-plt12-incident-response.sql
- Build: 60 páginas, testes 46 pass 4 skipped
- Próxima: PLT-13 gestão configurações flags
