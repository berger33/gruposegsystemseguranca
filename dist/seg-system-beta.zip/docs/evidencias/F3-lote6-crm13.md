# F3 lote 6 — CRM-13 vistoria com checklist por serviço

Data: 2026-09-28T07:45Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 5832daa (CRM-12) -> novo com CRM-13

## Objetivo
CRM-13: vistoria com checklist por serviço, quantidades, cobertura/turnos, infraestrutura, fotos autorizadas, limitações e responsável técnico.

## Implementação

### Migração 018-crm13-inspection.sql
- `crm_inspection_templates`: id TEXT PK, service_id FK service_catalog, name 200, description 1000, checklist JSONB array {id, question, type, required}, is_active, version, created_at/updated_at, índice service/is_active, trigger updated_at
- `crm_inspections`: id UUID PK, company_id FK CASCADE, opportunity_id FK SET NULL, unit_id FK SET NULL, template_id FK, service_id FK, title 200, status rascunho/em_andamento/concluida/cancelada, responsible_id FK auth_identities, responsible_name 120, scheduled_at, completed_at, coverage JSONB, quantities JSONB, infrastructure JSONB, limitations 2000, photos JSONB array {file_name, authorized bool, description} com authorized flag para fotos autorizadas, notes 2000, created_by, created_by_id, created_at/updated_at, índices company/opportunity/service/responsible/status, trigger updated_at
- `crm_inspection_answers`: id UUID PK, inspection_id FK CASCADE, item_id 100, question 500, answer 2000, quantity INT >=0, observed 1000, photo_ref 500, created_at/updated_at, índice inspection/item, unique inspection+item, trigger updated_at
- Templates iniciais por serviço:
  - tpl_seg_desarmada: Segurança Desarmada — cobertura_area text required, turnos text required, qtd_profissionais quantity required, infra_energia text, riscos text, fotos_autorizadas photos
  - tpl_cftv: CFTV — qtd_cameras quantity required, cobertura text required, infra_rede text required, armazenamento LGPD text required, acesso_remoto text, limitacoes text, fotos photos
  - tpl_portaria: Portaria — entradas quantity required, turnos_portaria text required, controle_veiculos text, infra_portaria text
- Auditoria: crm_inspection_create/update/status/answer

### inspection-api.mjs
- `handleTemplates` GET /api/crm/inspection-templates?serviceId=: admin session + sameOrigin + GET, query is_active true + service_id opcional, retorna templates
- `handleInspections` GET: filtros companyId/opportunityId/serviceId/status, limit/offset, count/list; POST: company_id UUID obrigatório, title 200 obrigatório, opportunity_id/unit_id/template_id/service_id opcionais, responsible_name 120, limitations/notes 2000, scheduled_at date, coverage/quantities/infrastructure JSONB, photos array 20 max com file_name 200, authorized bool, description 500, INSERT RETURNING *, se template_id cria answers vazios baseados no checklist do template (INSERT ON CONFLICT DO NOTHING), audit create
- `handleInspectionById` GET: retorna inspection + answers; PATCH: status rascunho/em_andamento/concluida/cancelada, responsible_name, limitations, notes, coverage, quantities, infrastructure, photos com authorized flag, UPDATE RETURNING *, se concluida set completed_at NOW(), audit status/update
- `handleAnswer` POST/PUT/PATCH /api/crm/inspections/:id/answers: item_id 100 obrigatório, answer 2000, quantity int >=0, observed 1000, photo_ref 500, busca existing answer por inspection+item, UPDATE COALESCE ou INSERT com question buscado do template checklist, audit answer

### server.mjs
- Importa createInspectionApi, instancia inspectionApi, rotas /api/crm/inspection-templates, /api/crm/inspections, /inspections/:id, /inspections/:id/answers, API_PATH_MATCH expandido

### InspectionClient.tsx (/admin/ti)
- Form criar vistoria com companyId UUID, serviceId, title, templateId select, responsible
- Lista templates com checklist items id/question/type/required
- Lista vistorias com tabela título/serviço/status/responsável/cobertura/quantidades/infra/limitações/fotos autorizadas count (authorized true / total)
- Texto explica tabelas, checklist por serviço, fotos autorizadas com authorized flag, responsável técnico

### scripts/migrate-site-visual.mjs
- 001-018, log All schemas (001-018)

## Validação
- npm test 46 pass 0 fail 4 skipped
- next build ok Next 16.3.6 54 páginas incluindo /admin/ti com InspectionClient
- Templates validados: 3 templates com checklist por serviço

## Aceite CRM-13
- Vistoria com checklist por serviço: sim, crm_inspection_templates por service_id com checklist JSONB, templates iniciais seg_desarmada, cftv, portaria
- Quantidades: quantities JSONB + crm_inspection_answers quantity
- Cobertura/turnos: coverage JSONB (ex: turnos, áreas)
- Infraestrutura: infrastructure JSONB
- Fotos autorizadas: photos JSONB array com authorized bool, somente autorizadas consideradas válidas, UI mostra count autorizadas/total
- Limitações: limitations TEXT 2000
- Responsável técnico: responsible_id FK + responsible_name 120

## Bloqueios
- PG real ausente sandbox: migração idempotente
- Fotos reais não armazenadas, apenas metadados com authorized flag, upload real depende de storage configurado (PLT-03)
- Ligação com oportunidade/empresa/unidade via FKs

## Próxima ação
- CRM-14 orçamento mão de obra com composição cobertura, salários, custos, benefícios, provisões, substituição, supervisão, uniforme/EPI, deslocamento, materiais, indiretos
- CRM-15 orçamento técnico com materiais, equipamentos, mão de obra, instalação, deslocamento, infraestrutura, licenças, garantia, manutenção
- CRM-16 parâmetros tributos/custos/jornada versionados
- CRM-17 cenários preço/margem
- CRM-18 alçadas desconto
- CON-01..11 contratos e implantação
