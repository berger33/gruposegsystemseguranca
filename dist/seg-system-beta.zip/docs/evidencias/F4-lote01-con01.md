# F4 lote 01 — CON-01 contrato ligado à empresa, unidades, proposta/versão, serviços, responsáveis, vigência, valor e documentos

Data: 2026-09-28T12:45Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 68b51a7 (CRM-27)

## Requisito
CON-01: contrato ligado à empresa, unidades, proposta/versão, serviços, responsáveis, vigência, valor e documentos. Admissão de cadastro manual com origem identificada.

## Implementação
### Migração 032
- `db/migrations/032-con01-contract-units-docs.sql`
- Adiciona colunas em `crm_contracts`: responsible_id FK auth_identities, responsible_name 120, starts_on DATE, ends_on DATE CHECK end>=start, origin_details 500, service_summary 2000, índices vigencia (starts_on,ends_on), origin, responsible
- `crm_contract_units` id UUID PK, contract_id FK CASCADE, unit_id FK CASCADE, role 100, notes 500, UNIQUE(contract_id,unit_id), índices contract/unit
- `crm_contract_responsibles` id UUID PK, contract_id FK CASCADE, responsible_id FK, responsible_name 120, role 100, is_primary bool, UNIQUE(contract_id,responsible_id,role), índices contract/responsible
- `crm_contract_documents` id UUID PK, contract_id FK CASCADE, title 200, category 100, file_url 1000, storage_key 200, description 1000, uploaded_by/by_id, índices contract/category
- Auditoria: crm_contract_unit_add/remove, crm_contract_responsible_add/remove, crm_contract_document_upload

### API
- `src/server/contract-api.mjs`
- `handleContracts` POST:
  - Se proposal_id: idempotente CRM-23 (proposal:UUID:vN)
  - Senão CON-01 manual: company_id UUID, title 200, responsible_id/name, starts_on/ends_on DATE, total_price/cost, origin manual/importacao/crm_proposal_acceptance, origin_details required para manual (origem identificada), service_summary 2000, notes
  - Cria proposta dummy rascunho se proposal_id não informado para vincular contrato manual (origem identificada), com snapshot dummy, assim contrato ligado à empresa, unidades, proposta/versão, serviços, responsáveis, vigência, valor e documentos, com origem manual identificada
  - idempotencyKey manual:company:title:timestamp, INSERT crm_contracts com responsible_id/name starts_on/ends_on origin_details service_summary, cria implantação planejada
- `handleContractById` GET: retorna contract + items + implantation + proposal + units JOIN company_units unit_name/city + responsibles + documents
- PATCH: suporta title/responsible_id/name/starts_on/ends_on/service_summary/origin_details/total_price/cost/status/notes
- `handleContractUnits` GET list JOIN unit_name/city, POST unit_id UUID role/notes ON CONFLICT (contract_id,unit_id) DO NOTHING idempotente, DELETE unit_id
- `handleContractResponsibles` GET list, POST responsible_name 120 role 100 is_primary ON CONFLICT DO NOTHING, DELETE id
- `handleContractDocuments` GET list, POST title 200 category file_url description uploaded_by

- `server.mjs` rotas `/api/crm/contracts/:id/units`, `/:id/responsibles`, `/:id/documents`

### UI
- `src/app/admin/ti/ContractClient.tsx` enhanced CON-01
- Form manual: company_id/title/responsible_name/starts_on/ends_on/total_price/origin_details/service_summary, nota origem identificada
- Lista contratos com empresa/responsável/vigência/origem detalhes
- Detalhe: unidades (add unit_id/role), responsáveis (add name/role/primary), documentos (add title/category/file_url), serviços, implantação

## Origem identificada manual
- origin enum manual/crm_proposal_acceptance/importacao
- origin_details 500 obrigatório para manual: "Cadastro manual origem identificada: administração cadastrou manualmente dados reais, sem dados de demonstração"
- Criação de proposta dummy rascunho para vincular contrato manual, garantindo FK e snapshot preservado, com note "Dummy para contrato manual CON-01"
- Audit com created_by/by_id

## Validação
- npm test 46 pass 4 skipped
- npx next build ok 59 páginas (Next 16.3.6)
- migrate-site-visual 001-032

## Próximo
CON-02..CON-11 contratos e implantação, PLT-05..18
