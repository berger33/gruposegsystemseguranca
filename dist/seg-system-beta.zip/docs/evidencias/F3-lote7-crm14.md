# F3 lote 7 — CRM-14 orçamento mão de obra

Data: 2026-09-28T08:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: 2fa17c7 (CRM-13) -> novo com CRM-14

## Objetivo
CRM-14: orçamento de mão de obra com composição de cobertura, salários e custos aplicáveis, benefícios, provisões, substituição, supervisão, uniforme/EPI, deslocamento, materiais e indiretos.

## Implementação

### Migração 019-crm14-labor-budget.sql
- `crm_labor_budgets`: id UUID PK, company_id FK CASCADE, opportunity_id FK SET NULL, inspection_id FK SET NULL, title 200, status rascunho/em_revisao/aprovado/arquivado, coverage JSONB (ex: postos, turnos, horas), total_cost numeric 12,2, total_price numeric 12,2, margin_percent numeric 5,2 -100..100, notes 2000, created_by, created_by_id FK, approved_by FK, approved_at, created_at/updated_at, índices company/opportunity/status, trigger updated_at
- `crm_labor_budget_items`: id UUID PK, budget_id FK CASCADE, role_name 100 (ex: vigilante, porteiro), function_name 100, quantity int >=1, shift_type 100 (12x36, 44h), salary numeric 12,2 >=0, benefits JSONB (ex: vale transporte, alimentação), provisions JSONB (13o, férias, FGTS), substitution_cost numeric 12,2, supervision_cost numeric 12,2, uniform_cost numeric 12,2, displacement_cost numeric 12,2, materials_cost numeric 12,2, indirect_cost numeric 12,2, other_costs JSONB, total_cost numeric 12,2, unit_price numeric 12,2, total_price numeric 12,2, notes 500, índice budget, trigger updated_at
- Auditoria: crm_labor_budget_create/update/status/item_create/item_update

### labor-budget-api.mjs
- `calcItemTotals(item)`: benefits = sum values benefits object, provisions sum, other sum, totalCostPerUnit = salary + benefits + provisions + substitution + supervision + uniform + displacement + materials + indirect + other, totalCost = perUnit * qty, unitPrice = item.unit_price || perUnit, totalPrice = unitPrice * qty
- `handleBudgets` GET: filtros companyId/opportunityId/status, limit/offset, count/list; POST: company_id UUID obrigatório, title 200, opportunity_id/inspection_id opcionais, coverage JSONB, notes, INSERT RETURNING *, audit create
- `handleBudgetById` GET: budget + items; PATCH: status rascunho/em_revisao/aprovado/arquivado, title, notes, coverage JSONB, margin_percent -100..100, recalcula totais se itens existem (SUM total_cost/price), se aprovado set approved_by/at, UPDATE RETURNING *, audit status/update
- `handleItems` POST: budget_id, role_name 100 obrigatório, function_name 100, quantity >=1, shift_type 100, salary >=0, benefits/provisions/other_costs JSONB, substitution/supervision/uniform/displacement/materials/indirect numeric, unit_price, notes 500, calcula totais via calcItemTotals, INSERT RETURNING *, UPDATE crm_labor_budgets total_cost/price = SUM items, audit item_create; GET: lista items

### server.mjs
- Importa createLaborBudgetApi, instancia laborBudgetApi, rotas /api/crm/labor-budgets GET/POST, /:id GET/PATCH, /:id/items GET/POST, API_PATH_MATCH expandido

### LaborBudgetClient.tsx (/admin/ti)
- Form criar orçamento com companyId UUID, title, coverage JSON (ex: {"postos":2,"turnos":"12x36"})
- Lista orçamentos com título/status/custo total/preço total/cobertura JSON, botão Ver itens
- Form adicionar item com role (cargo/função), quantity, salary, shift, substitution, supervision, uniform/EPI, displacement, materials, indirect — todos numeric
- Lista itens com cargo/qtd/turno/salário/custo total/preço total, recalcula totais orçamento após adicionar item
- Texto explica tabelas, composição, cálculo totais

### scripts/migrate-site-visual.mjs
- 001-019, log All schemas (001-019)

## Validação
- npm test 46 pass 0 fail 4 skipped
- next build ok Next 16.3.6 54 páginas incluindo /admin/ti com LaborBudgetClient
- Cálculo totais validado: por unidade + qty

## Aceite CRM-14
- Orçamento mão de obra: sim, crm_labor_budgets
- Composição cobertura: coverage JSONB (postos, turnos, horas)
- Salários e custos aplicáveis: salary
- Benefícios: benefits JSONB
- Provisões: provisions JSONB
- Substituição: substitution_cost
- Supervisão: supervision_cost
- Uniforme/EPI: uniform_cost
- Deslocamento: displacement_cost
- Materiais: materials_cost
- Indiretos: indirect_cost
- Outros: other_costs JSONB
- Total custo/preço por item e orçamento: total_cost, unit_price, total_price com cálculo automático

## Bloqueios
- PG real ausente sandbox: migração idempotente
- Parâmetros custos/salários/benefícios/provisões dependem de D-06 tabela custos/preços, impostos e alçadas pendente, sem alíquota inventada
- Margem e preço dependem de aprovação contábil D-06

## Próxima ação
- CRM-15 orçamento técnico com materiais, equipamentos, mão de obra, instalação, deslocamento, infraestrutura, licenças, garantia, manutenção
- CRM-16 parâmetros tributos/custos/jornada versionados
- CRM-17 cenários preço/margem
- CRM-18 alçadas desconto
- CON-01..11 contratos e implantação
