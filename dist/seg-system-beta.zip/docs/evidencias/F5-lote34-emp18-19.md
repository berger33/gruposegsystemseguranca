# Evidência F5 Lote 34 — EMP-18/19 PWA offline FAQ acessibilidade

Data: 2026-09-29T22:00Z
Branch: arena/01a0e621-gruposegsystemseguranca
Commit base: c89d1f0
Objetivo: EMP-18 PWA instalável fila offline limitada idempotência conflito explícito horários separados não cachear médicos/salariais, EMP-19 FAQ interna acessibilidade teclado/leitor linguagem simples baixo consumo.

## Migração 069
- Arquivo: db/migrations/069-emp18-19-pwa-faq-acessibilidade.sql
- Enums 8: pwa_display 4 standalone/minimal-ui/browser/fullscreen, offline_task_type 8 occurrence/handover/absence_notice/shift_swap/procedure_ack/journey_proof/absence_followup/occurrence_action, offline_queue_status 6 pendente/sincronizando/sincronizado/conflito/falha/cancelado, offline_conflict_type 6 duplicate/version_conflict/stale_data/permission_denied/expired/already_resolved, offline_conflict_resolution 4 pendente/manual_resolvido/auto_resolvido/ignorado, faq_category 10 geral/escala/ponto/beneficios/uniformes/seguranca/procedimentos/rh/tecnico/outro, faq_status 4 rascunho/em_revisao/publicado/arquivado, font_size 4 pequeno/medio/grande/extra_grande
- Tabelas 6:
  - emp_pwa_configs id PK name 3..100 short_name 2..20 description 10..500 theme_color #hex background_color display scope start_url icons JSONB screenshots shortcuts offline_enabled true offline_cache_strategy network_first approved_offline_tasks task_type[] default occurrence/handover/absence_notice/procedure_ack max_queue_size 1..200 default 50 max_retries 1..20 do_not_cache_patterns TEXT[] default payroll-documents/own-doc-access-logs/occupational/medical/salary/holerite is_active version trigger índice active WHERE true seed 1 config Grupo SEG System Portal Funcionário standalone scope / start_url /funcionario icons 192/512 approved occurrence/handover/absence_notice/procedure_ack/journey_proof max 50 do_not_cache payroll/own-doc/occupational/medical/salary/holerite
  - emp_offline_queue id PK employee_id FK hr_employees task_type payload JSONB idempotency_key UNIQUE 10..200 device_timestamp TIMESTAMPTZ device_timezone America/Sao_Paulo server_received_at TIMESTAMPTZ status conflict_details JSONB retry_count last_error synced_at created_at trigger índices employee/task_type/status/idempotency/device_ts/server_recv/created
  - emp_offline_conflicts id PK queue_id FK CASCADE conflict_type server_data device_data resolution resolved_by/at notes 2000 trigger índices queue/type/resolution
  - emp_faq_internal id PK category question 10..500 answer 20..5000 status is_simple_language true reading_level simples/medio/tecnico is_low_data true baixo consumo has_keyboard_support true has_screen_reader_support true tags view_count is_published published_at/by created_by trigger índices category/status/published/simple/low_data seed 5 FAQ simples baixo consumo teclado/leitor plantão escala ocorrência procedimentos ponto
  - emp_faq_access_logs id PK faq_id FK CASCADE employee_id FK accessed_at device_type mobile/desktop/tablet/outro is_keyboard_navigation is_screen_reader data_saver ip_hash trigger índices faq/employee/date/keyboard
  - emp_accessibility_preferences id PK employee_id UNIQUE FK hr_employees prefers_keyboard/screen_reader/simple_language true/low_data font_size pequeno/medio/grande/extra_grande high_contrast reduced_motion trigger índices employee/keyboard
- Auditoria: emp_pwa_config_create/update, offline_queue_create/update/conflict/resolve, faq_internal_create/update/access, accessibility_pref_update

## API src/server/emp-pwa-api.mjs
- Handlers 8: pwaConfigs, manifest (public), serviceWorker (public), offlinePage, offlineQueue, offlineConflicts, faqInternal, faqAccessLogs, accessibilityPreferences
- PWA:
  - handlePwaConfigs GET list POST name 3..100 short_name 2..20 description 10..500 theme_color #hex background_color display scope start_url icons approved_offline_tasks max_queue_size 1..200 max_retries do_not_cache_patterns is_active version MAX+1 INSERT audit create PATCH name short_name description is_active approved_offline_tasks max_queue_size do_not_cache_patterns
  - handleManifest GET public sem auth SELECT active config ORDER version DESC LIMIT 1 fallback default, retorna manifest.json com name short_name description theme_color background_color display scope start_url icons shortcuts screenshots categories orientation lang pt-BR dir ltr
  - handleServiceWorker GET public JS com CACHE_NAME seg-system-v1 OFFLINE_URL /offline.html DO_NOT_CACHE from config shouldNotCache(url) includes pattern, install cache offline.html skipWaiting activate delete old claim, fetch handler shouldNotCache -> fetch catch 403 Documento restrito não disponível offline, offline-queue POST network_first fallback 202 queued_offline device_timestamp separado server, navigate network_first cache fallback offline.html, assets cache_first, sync tag offline-queue-sync postMessage SYNC_OFFLINE_QUEUE device_timestamp server_received_will_be_set
  - handleOfflinePage GET HTML explica idempotência horários separados conflito explícito não cachear médicos/salariais
- Offline Queue:
  - GET filtros employee_id status task_type
  - POST employee_id task_type occurrence/handover/absence_notice/shift_swap/procedure_ack/journey_proof payload idempotency_key 10..200 device_timestamp required device_timezone server_received_at NOW() separado approved_offline_tasks check config 400 task_not_approved_offline max_queue_size check 429 queue_limit_exceeded idempotência existing key payload igual retorna 200 dedup true payload diferente gera conflito explícito duplicate INSERT conflict status conflito 409 idempotency_conflict verifica employee exists INSERT pendente audit create
  - PATCH status pendente/sincronizando/sincronizado/conflito/falha/cancelado last_error retry_count synced_at
  - handleOfflineConflicts GET queue_id resolution PATCH resolution pendente/manual_resolvido/auto_resolvido/ignorado notes se resolvido atualiza queue sincronizado audit resolve
- FAQ Interna:
  - handleFaqInternal GET filtros category status is_published is_simple_language search ILIKE question/answer POST question 10..500 answer 20..5000 category status is_simple_language reading_level simples/medio/tecnico is_low_data has_keyboard_support has_screen_reader_support tags is_published published_at/by audit create PATCH question answer category status is_simple_language reading_level is_low_data has_keyboard_support has_screen_reader_support tags is_published
  - handleFaqAccessLogs GET faq_id filter POST faq_id employee_id device_type mobile/desktop/tablet/outro is_keyboard_navigation is_screen_reader data_saver ip_hash sha256 increment view_count audit access
  - handleAccessibilityPreferences GET employee_id filter POST employee_id prefers_keyboard/screen_reader/simple_language true/low_data font_size pequeno/medio/grande/extra_grande high_contrast reduced_motion ON CONFLICT employee_id DO UPDATE upsert audit update

## UI src/app/admin/ti/EmpPwaClient.tsx
- PWA config criar name short_name description theme_color scope start_url max_queue_size, lista configs version name short_name display maxQueue approved active doNotCache manifest link sw.js link
- Fila offline: employee_id task_type occurrence/handover/absence_notice/shift_swap/procedure_ack/journey_proof idempotency_key auto device_timestamp payload JSON criar enfileirar idempotente device_timestamp vs server_received_at separados, lista queues employee type status idem device server_recv retry synced conflict botão sincronizar server_received_at separado
- Conflitos explícitos: lista conflicts queue type resolution server_data device_data botões manual_resolvido auto_resolvido ignorado
- FAQ interna: category status pergunta resposta linguagem simples baixo consumo tags reading_level criar FAQ acessível, lista faqs category question answer status simples low_data leitura teclado leitor views publicado
- Log acesso FAQ: faq_id employee_id device_type mobile/desktop/tablet is_keyboard_navigation is_screen_reader data_saver registrar acesso
- Preferências acessibilidade: employee_id teclado leitor linguagem simples baixo consumo font_size pequeno/medio/grande/extra_grande alto contraste salvar, lista prefs

## Server.mjs integração
- Import createEmpPwaApi, instancia empPwaApi com pool auditLog sameOrigin requireSession requireRole
- Rotas routeApi: /api/pwa/manifest.json /manifest.json /api/hr/pwa-manifest -> handleManifest, /api/pwa/sw.js /sw.js /api/hr/pwa-sw -> handleServiceWorker, /api/pwa/offline /offline.html -> handleOfflinePage, /api/admin/hr/pwa-configs /api/hr/pwa-configs -> handlePwaConfigs, /api/hr/offline-queue -> handleOfflineQueue, /api/hr/offline-conflicts -> handleOfflineConflicts, /api/hr/faq-internal /api/employee/faq -> handleFaqInternal, /api/hr/faq-access-logs -> handleFaqAccessLogs, /api/hr/accessibility-preferences /api/employee/accessibility -> handleAccessibilityPreferences
- API_PATH_MATCH expandido 30 novas entradas

## Page.tsx
- Import EmpPwaClient, render após EmpAdvanced2Client

## Layout.tsx
- metadata manifest /api/pwa/manifest.json themeColor movido para viewport export viewport themeColor #0f172a appleWebApp icons icon-192, head link manifest theme-color apple-mobile-web-app-capable, body script serviceWorker registration /api/pwa/sw.js scope /

## Public
- public/icons/icon-192.png placeholder 1x1 PNG 68 bytes, icon-512.png idem, public/offline.html fallback static

## Migrate script
- scripts/migrate-site-visual.mjs atualizado 001-069 idempotente

## Build/Testes
- Build: Next 16.3.6 59 páginas ok (warnings themeColor movido para viewport corrigido)
- Tests: 46 pass 0 fail 4 skipped

## Decisões DT-185..186
- DT-185 EMP-18 PWA instalável fila offline limitada idempotência conflito explícito horários separados não cachear médicos/salariais
- DT-186 EMP-19 FAQ interna linguagem simples baixo consumo acessibilidade teclado/leitor

## Próximo passo
- F5 concluída (EMP-01..19), iniciar F6 OPS-01..16 operação postos escalas supervisão + CLI portal cliente + FIN + ADM + PLT verificação final + homologação usuários
- Não marcar telas demonstrativas como concluídas, continuar implementação concreta
- Não publicar produção nem contratar serviços automaticamente
