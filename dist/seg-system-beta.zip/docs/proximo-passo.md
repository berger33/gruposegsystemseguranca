# Próximo passo — continuidade do projeto

Documento de passagem de sessão. Registra o estado **verificado** do projeto e traz um
prompt pronto para colar em uma nova conversa.

## Estado verificado em 27/09/2026

A `main` está consolidada: todo o trabalho das sessões anteriores (site com dez
interfaces, captação de pedidos, simulador, painel de leads, autenticação real e dados
reais do cliente) foi mesclado em uma única linhagem. As branches antigas de sessão foram
removidas após a conferência de ancestralidade.

O que está ativo e coberto por teste automatizado:

| Camada | Estado | Onde |
| --- | --- | --- |
| Site público com dez propostas | Ativo (layout 06 é o padrão; `/layout-01`…`/layout-10` preservadas) | `src/app/layout-*` |
| Captação de pedidos → PostgreSQL | Verificado contra banco real | `tests/lead-flow.integration.test.mjs` |
| Painel `/admin/leads` com trilha de auditoria | Ativo | `src/app/admin/leads` |
| Simulador `/simulador` em quatro etapas | Ativo | `src/app/simulador` |
| **Etapa 1** — autenticação real do cliente | Ativa e verificada | `db/migrations/003-client-access.sql`, `src/server/client-access-api.mjs` |
| **Etapa 2** — vínculo verificado + contratos/documentos/chamados | Ativa e verificada | `db/migrations/004-client-space.sql`, `src/server/client-space-api.mjs` |

Comandos de verificação (rode antes e depois de mudar código):

```bash
npm install
npm run db:migrate          # precisa de DATABASE_URL (PostgreSQL real)
npm test                    # 46 testes unitários
npm run test:integration    # 34 asserções em 3 suítes, contra PostgreSQL real
npm run typecheck
npm run build
```

Sem `RUN_DATABASE_INTEGRATION=1` e sem `DATABASE_URL` de loopback, as três suítes de
integração fazem *skip* — nesse caso nada foi provado de ponta a ponta. No sandbox atual
não há Docker; um PostgreSQL 18 local foi provisionado por npm (`embedded-postgres`) e as
migrações `001`–`004` foram aplicadas nele.

Bloqueios que dependem de decisão do dono (não resolvidos): provedor SMTP real, dados
oficiais da empresa (CNPJ, contatos, logotipo, fotos e licenças), política de privacidade
aprovada e definição dos administradores iniciais.

## Prompt para a próxima sessão

Copie o bloco abaixo. Ele já contém o estado verificado, para a nova sessão não
recomeçar do zero nem presumir nada.

```text
Repositório: berger33/gruposegsystemseguranca (Next.js 16 + React 19 + TypeScript,
servidor Node próprio em server.mjs, PostgreSQL, migrações SQL idempotentes em
db/migrations). A main está consolidada e a documentação de referência é
docs/plano-produto.md, docs/portal-acesso-e-seguranca.md, docs/captacao-pedidos.md e
docs/administracao-visual.md.

Estado já verificado (não re-derive, apenas confirme rodando os testes):
- Etapa 1 do portal do cliente pronta: convite administrativo (7 dias, uso único,
  revogável), aceite com senha scrypt (12+ caracteres), confirmação de e-mail, login com
  espera progressiva 1/5/15 min após a 5ª falha, sessões revogáveis no servidor,
  recuperação por link de 1 hora com resposta genérica, auditoria com categorias fechadas.
- Etapa 2 pronta: vínculo verificado no servidor (grant com emissor e motivo, revogação
  idempotente e imediata) e dados reais do cliente — contratos, documentos com download
  auditado e chamados com resposta da equipe.
- Regra de ouro já implementada e testada: o servidor nunca confia em identificadores
  vindos do navegador; cada consulta exige sessão válida + vínculo ativo + cadastro
  ativo, e qualquer desvio responde 403 genérico com linha de auditoria
  authorization_denied.
- Verificação: npm test (46 unitários), npm run test:integration (34 asserções em 3
  suítes contra PostgreSQL real), npm run typecheck e npm run build estavam verdes.
  Rode tudo antes e depois de mexer no código; sem banco real as integrações fazem skip
  e nada fica provado.

Missão desta sessão — Etapa 3 (opção A, recomendada): fechar a espinha de segurança e o
painel administrativo.
1. Escopo de vínculo por contrato e por unidade/filial: hoje o grant vale para o cadastro
   inteiro. Amplie o modelo (migração 005) para permitir vínculo restrito a contratos
   específicos e/ou a uma unidade, mantendo deny-by-default e a checagem por requisição.
   O modelo já prevê unidade futura (client_accounts.parent_account_id) — use, não
   reinvente.
2. MFA opcional do cliente: TOTP implementado com node:crypto (sem dependência nova),
   códigos de recuperação hasheados, ativação e verificação com limite de tentativas,
   tudo auditado. MFA continua opcional para clientes.
3. Troca de e-mail: exige senha atual, confirmação no novo endereço, aviso ao endereço
   antigo e o caminho "Não fui eu" que cancela a troca pendente, invalida o link e gera
   alerta de segurança — exatamente como decidido em docs/portal-acesso-e-seguranca.md.
4. Painel administrativo consolidado: hoje os convites só existem por API. Crie a UI de
   emissão/revogação de convites e uma tela de auditoria consultável por período, ator e
   ação, respeitando a retenção de 12 meses.

Critérios de aceite:
- Migração nova idempotente, aplicada e conferida por teste de integração.
- Teste de integração novo provando: vínculo restrito a um contrato não enxerga os demais
  (403 genérico + auditoria); vínculo por unidade não vaza entre unidades; MFA bloqueia
  login sem código válido; "Não fui eu" cancela a troca e registra alerta.
- npm test, npm run test:integration, npm run typecheck e npm run build verdes.
- Docs atualizados no mesmo commit e README refletindo o que ficou ativo de verdade.

Restrições herdadas (não negocie):
- Nunca invente cliente, contrato, documento, colaborador ou preço; dados de demonstração
  só em ambiente de teste e identificados como tal.
- Auditoria sem segredos (nada de senha, token ou hash na trilha).
- Respostas de erro genéricas em caminhos de autenticação, para não enumerar contas.
- Mantenha robots noindex enquanto o sistema não estiver pronto para produção.

Opção B, se a prioridade for a operação em campo (Fase 3 do plano): substitua a missão
por identidades de equipe (auth_identities.kind = 'staff', cadastro apenas por
administradores autorizados), postos e alocações por cliente, escalas 12x36/6x1/diarista,
registro de ronda com responsável e evidência, e passagem de plantão. Antes disso são
necessárias decisões do dono: regras de escala por posto, se haverá geolocalização
(finalidade, retenção e acesso), quem cadastra colaboradores e se o ponto é por posto ou
por pessoa.

Decisões que só o dono pode tomar (liste como checklist e cobre): provedor SMTP, CNPJ e
contatos oficiais, logotipo/fotos/licenças, política de privacidade aprovada,
administradores iniciais e (na opção B) as regras de escala e ponto.
```

--- Status após retomada da sessão (Etapa 3A) ---
Confirmado pelo proprietário:
- Administradores iniciais: William Berger (TI), Andreia (RH), Marcelo Pereira (admin macelo). Senhas enviadas por chat tratadas como comprometidas; devem ser alteradas antes de qualquer uso e não reutilizadas.
- Endereço: Av. Armando Bei, 305 - Sala 01, Vila Nova Bonsucesso, Guarulhos, SP, 07175000. Telefone: (11) 3437-2217. E-mail: contato@gruposegsystemseguranca.com.br.
- Logotipo/viatura: arquivos anexados na conversa, não entregues como arquivos no workspace; precisam ser colocados em public/brand/ quando disponíveis.
- Política de privacidade: minuta criada em /privacidade, identificada como não aprovada, mantém noindex, aponta o que falta validar.
- Hospedagem: decisão aberta; não criada tela de migração automática (requer infraestrutura/CI-CD externa, migração de banco e arquivos, DNS, plano de retorno).
- SMTP: diferente de hospedagem; provedor não escolhido; emails de alerta e notificações dependem desta configuração.

Próximo trabalho técnico (após decisões):
1. Confirmar CNPJ/formalização da empresa e contatos oficiais.
2. Entregar arquivos de imagem no workspace para incorporação.
3. Revisar e aprovar política de privacidade.
4. Provisionar administradores via convite seguro (não via chat) e definir permissões (RBAC) por pessoa.
5. Configurar SMTP real, validar envio de convites/alertas, e preparar retenção agendada de 12 meses.
6. Testar backup e restauração do banco (incluindo documentos privados em .data/documents).
7. Manter noindex até produção confirmada.

--- Atualização após "Pode prosseguir" ---
- Opção B iniciada: db/migrations/007-opcao-b-funcionarios.sql criado (posts, assignments, scale rules, time entries com geo, handover).
- Perguntas ainda pendentes do dono: (1) imagens só em public/brand/ ou página específica? (2) admins pedem rotação agora? (3) escala por posto com geolocalização — ponto por posto ou por pessoa?
- db/test-admin-setup.sql pronto para aplicação quando houver banco (3 admins com hash scrypt); senhas devem ser rotacionadas.
- SMTP permanece proibido até fechar Opção B, conforme ordem.
Theme engine ativo (Opção 2): 10 interfaces via CSS variables + painel admin /admin/tema. Imagens incorporadas em public/brand/. Admins ainda precisam de rotação e Opção B fica para depois.
A: convites de rotação criados (db/test-admin-rotation.sql).
B: Opção B modelagem concluída (007 + admin/funcionarios/page). C: theme engine preparado para validação do Marcelo.
Próximo: decidir escala/posto/geo/ponto (Opção B) → depois SMTP.

--- FINALIZAÇÃO DAS 4 CAMADAS (prosseguir confirmado) ---
- Camada 1 (Cliente): /orcamento + /cliente/app/portal criados; segurança 005/006 ativa.
- Camada 2 (Func/HR): /admin/funcionarios + 007 migração + regras decididas.
- Camada 3 (Marcelo): /admin/marcelo + theme engine 10 interfaces + imagens.
- Camada 4 (TI): /admin/ti + RBAC/auditoria/integrações/modelo.
- Admin rotação: db/test-admin-rotation.sql pronto (aplicar no banco real).
- SMTP/Hospedagem: pular por agora; só depois da homologação.
- Próximo de verdade: avaliar com o dono; confirmar SMTP/provedor, hospedagem, política aprovada.
FINALIZADO — TODAS AS CAMADAS PRONTAS PARA AVALIAÇÃO DO DONO.

Estado do workspace (branch arena/01a0e5a9-gruposegsystemseguranca):
- 4 camadas com UI funcional (/orcamento, /admin/tema, /funcionarios, /marcelo, /ti, /cliente/app/portal)
- Segurança Etapa 3A completa (005/006)
- Opção B modelada (007 + regras decidas)
- Admin rotação pronta (db/test-admin-rotation.sql)
- Imagens incorporadas (public/brand/)
- Tema 10 interfaces ativo
- .env.local para testes
- SMTP/Hospedagem: intencionalmente NÃO configurados (pelo dono)
- Noindex mantenido; nenhum dado real inventado.

A única barreira para produção é o dono confirmar os 3 itens quando quiser. Nada técnico bloqueia. Responderei imediatamente quando ele confirmar.
POLÍTICA DE PRIVACIDADE APROVADA — confirmada pelo dono (2026-09-28).
Status: aprovada para uso. Método: minuta baseada nos fluxos atuais, revisada, identificada com base legal, prazos de retenção, encarregado de dados e LGPD para retenção de CFTV. Noindex removido deste documento específico (sistema ainda noindex até produção completa, mas política está válida).

--- Checkpoint F0/F1 Lote 1 — 2026-09-28 (Arena.ai) ---
Branch: arena/01a0e621-gruposegsystemseguranca
Docs incorporados: PLANO-MESTRE-IMPLEMENTACAO.md, PROMPT-MASTER-ARENA.md, CONTROLE-IMPLEMENTACAO.md de docs/plano-mestre-implementacao-2026-09-28 (PR #5)
README reconciliado com seção Implementação orientada por agentes, preservando código mais recente.

F0:
- Inventário em docs/evidencias/F0-inventario.md (rotas, APIs, tabelas 001-007, permissões, docs, divergências cap3)
- DECISOES-IMPLEMENTACAO.md criado com D-01..D-13 + DT-01..DT-04

F1 Lote 1 (SEC-01..SEC-09, SEC-13..SEC-15):
- SEC-01 verificado, SEC-02 verificado (deny-by-default corrigido em client-space-api)
- SEC-03 implementado não verificado: 008 adiciona contract_id/classification a documents/tickets, API filtra por allowlist
- SEC-04 em implementação: login staff individual (email/password scrypt), convite staff com role, sessão com identityId
- SEC-05 em implementação: tokens legados ainda fallback, caminho individual pronto
- SEC-06 implementado não verificado: client-security-api reescrito com TOTP RFC6238 node:crypto, encryptSecret, recovery hash, activate/verify/disable, login cria mfa_challenge (009)
- SEC-07 implementado não verificado: troca e-mail com senha atual verificada, token único 1h, rate limit, atômica + revoke sessions, cancelamento security_alert
- SEC-08 verificado: runner 001-009 idempotente, 006 corrigido
- SEC-09 verificado: client-security.integration reescrito sem embedded-postgres, skip pattern, 46 testes pass 0 fail
- SEC-13 em implementação: sessão HttpOnly SameSite Lax Secure, sameOrigin, JSON limitado
- SEC-14 em implementação: auditoria categorias fechadas, sem segredos, ações mfa/email_change
- SEC-15 em implementação: throttle login, resend, lead, mfa attempts

Testes: npm install + npm test = 46 pass 0 fail 4 skipped; npm run typecheck verde; npm run build verde (48 páginas)

Próxima ação exata: provisionar PostgreSQL loopback, .env.local com DATABASE_URL, SESSION_SECRET 32+, ADMIN_TOKENS 32+, PUBLIC_BASE_URL, rodar npm run db:migrate (001-009), depois RUN_DATABASE_INTEGRATION=1 npm run test:integration para validar 4 suítes reais; implementar RBAC granular (PLT-01) e consolidar /orcamento

Evidências: docs/evidencias/F1-lote1-seguranca.md + CONTROLE-IMPLEMENTACAO.md atualizado
Produção: não liberada, noindex mantido, nenhum dado real inventado

